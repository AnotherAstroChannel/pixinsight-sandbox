/*
 ****************************************************************************
 * Blind Plate Solver
 *
 * BlindPlateSolver.js
 *
 * Finds where an image sits on the sky and writes the astrometric solution
 * to it. Uses ASTAP, installed by the user with one of its star databases,
 * or the Astrometry.net web service with the user's own API key.
 * Hints from the image's header, a typed target name and the camera's focal
 * length and pixel size make the solve faster; none of them is required.
 * The solution is corrected for the optics' distortion against the user's
 * Gaia catalogue when one is installed, or by ASTAP's own fit.
 *
 * The image's pixels are never modified: the solver reads a temporary copy,
 * and only the solution's keywords and properties are written to the image.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    BlindPlateSolver : Another Astro Channel > Blind Plate Solver
#feature-icon  @script_icons_dir/BlindPlateSolver.svg


#feature-info  Finds where an image sits on the sky with ASTAP or Astrometry.net and writes the astrometric solution to it, using header hints or a typed target name when there are any.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Report the version and warn if it looks old; never abort. The astrometry
 * library this script uses ships with PixInsight 1.8.9-2 and later.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;
      if ( major === undefined || major === null )
         return false;
      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;
   }
}

/*
 * -----------------------------------------------------------------------------
 * PIXINSIGHT'S IMAGE SOLVER, loaded as the library it is built to be
 * (USE_SOLVER_LIBRARY leaves its own main() out), for the optional refine
 * step after a solve. The <...> path is found from PixInsight's include
 * folder, which sits beside its scripts folder in every installation, so it
 * works wherever this script is run from. It shares Image Solver's own
 * settings -- the user's catalogue choices -- through SETTINGS_MODULE. It
 * defines TITLE and VERSION for itself; they are replaced by this script's
 * below, after its code has been read with its own.
 * -----------------------------------------------------------------------------
 */
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "ImageSolver"
#include <../src/scripts/ImageSolver/ImageSolver.js>
#undef TITLE
#undef VERSION

/*
 * -----------------------------------------------------------------------------
 * IDENTITY
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Blind Plate Solver"
#define VERSION     "1.13"
#define SCRIPT_ID   "BlindPlateSolver"
#define KEYPREFIX   "BlindPlateSolver"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Finds where the image sits on the sky and writes an astrometric solution to it, ready for annotation, mosaics and Image Solver. A target name or the camera's focal length and pixel size make it faster but are optional. The image's pixels are never changed."

/*
 * The dialog: the width of the label column, the rows of the name
 * suggestion list, and the search radius around a target in degrees.
 */
#define DIALOG_LABEL_WIDTH     140
#define SUGGESTION_ROWS        8
#define DEFAULT_SEARCH_RADIUS  5

/*
 * Where the solver's copy puts the sky, as a fraction of full scale: the
 * level of a raw camera frame's sky. A stretched image is brought down to
 * it; a linear image already sits below it and is left linear (lib/Astap.js,
 * writeSolverCopy).
 */
#define SOLVER_COPY_SKY        0.002

/*
 * Astrometry.net: the service, the longest side of the copy that is
 * uploaded (binned down to it), how long to wait for an answer in seconds,
 * and how often to ask.
 */
#define ASTROMETRY_NET_URL          "https://nova.astrometry.net"
#define ASTROMETRY_NET_MAX_SIDE     2048
#define ASTROMETRY_NET_TIMEOUT      600
#define ASTROMETRY_NET_POLL_SECONDS 5
#define ASTROMETRY_NET_NO_JOB_GRACE 60

/*
 * Completing the header after a solve (Solution.instrumentFor): how close a
 * focal length and pixel size must come to the measured scale, as a
 * fraction, and the drizzle factors they may imply.
 */
#define SOLVER_INSTRUMENT_TOLERANCE 0.08

/*
 * The distortion fit: control points per row across the image when ASTAP's
 * SIP terms become PixInsight's spline (Solution.addDistortion).
 */
#define SOLUTION_GRID_COLUMNS 40

/*
 * The Gaia refinement (lib/GaiaRefine.js). The catalogue stars aimed for on
 * the image: fewer leave sparse corners loosely fitted, more cost PSF fits
 * (about 0.25 s per thousand on a 70-megapixel frame). At most this many are
 * measured, the brightest first.
 */
#define GAIA_TARGET_STARS 6000
#define GAIA_MAX_STARS    8000

/*
 * The pairs the spline is fitted through, the brightest first: more cost
 * time for no accuracy -- on the Iris, 2500 gave the same held-out median
 * (0.11 px) as 4627, in 1.1 s instead of 4. Fewer than GAIA_MIN_PAIRS
 * agreeing pairs and the refinement gives up.
 */
#define GAIA_MAX_PAIRS    2500
#define GAIA_MIN_PAIRS    30

/*
 * The coarse pass from a straight-line start: the brightest stars, in boxes
 * of this half-size in pixels. Wider boxes reach worse corners but take in
 * more neighbours; 16 px found the stars of an Iris corner 11 px out.
 */
#define GAIA_COARSE_STARS 800
#define GAIA_COARSE_BOX   16

/*
 * The comment XPIXSZ carries when the drizzle factor is divided into it.
 */
#define SOLUTION_DRIZZLE_COMMENT "Effective pixel size (um), drizzle included"

#include <pjsr/UndoFlag.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/astrometry/AstrometricMetadata.js>

#include "lib/Compat.js"
#include "lib/Theme.js"
#include "lib/ObjectNicknames.js"
#include "lib/ObjectNames.js"
#include "lib/Hints.js"
#include "lib/Astap.js"
#include "lib/Solution.js"
#include "lib/GaiaRefine.js"
#include "lib/AstrometryNet.js"
#include "lib/Solver.js"
#include "lib/Refine.js"
#include "lib/LightFrame.js"
#include "lib/SolverDialog.js"

/*
 * An environment variable, or "" when it is not set. PixInsight 1.9 reads
 * them through System; the older global function still works there but
 * prints a deprecation warning, so it is only the fallback for older cores.
 */
function environmentValue( name )
{
   try
   {
      if ( typeof System != "undefined" && typeof System.getEnvironmentVariable == "function" )
         return String( System.getEnvironmentVariable( name ) || "" );
   }
   catch ( x )
   {
   }
   try
   {
      return String( getEnvironmentVariable( name ) || "" );
   }
   catch ( x )
   {
      return "";
   }
}

/*
 * Keep the dialog responsive during a long wait, and pause. PixInsight 1.9
 * moved both (CoreApplication.processEvents, System.msleep) and prints a
 * deprecation warning for the old globals, which stay as the fallback.
 */
function pumpEvents()
{
   if ( typeof CoreApplication != "undefined" && typeof CoreApplication.processEvents == "function" )
      CoreApplication.processEvents();
   else
      processEvents();
}

function pauseMilliseconds( ms )
{
   if ( typeof System != "undefined" && typeof System.msleep == "function" )
      System.msleep( ms );
   else
      msleep( ms );
}

function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      let text = String( x );
      return ( text != "" && text != "[object Object]" ) ? text : "an error with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against. Continuing anyway." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION + " on core version " + coreVersionText() );

   try
   {
      ( new SolverDialog() ).execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
}

/*
 * A test harness that includes this file defines BLIND_PLATE_SOLVER_HARNESS
 * first and calls the solver itself; nothing waits for a dialog then.
 */
if ( typeof BLIND_PLATE_SOLVER_HARNESS == "undefined" )
   main();
