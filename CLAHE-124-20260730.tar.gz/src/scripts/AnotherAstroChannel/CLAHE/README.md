# CLAHE for PixInsight

Copyright (c) 2026 Bill Blanshan. Released under the GNU General Public License
version 3.

Local contrast enhancement by Contrast Limited Adaptive Histogram Equalization.

Built on the PixInsight Script Template. The maths lives in `lib/Methods.js`;
everything else is the template's generic machinery.

## What it does

Ordinary histogram equalisation flattens the histogram of the whole image. That
maximises global contrast and destroys local contrast: a faint dust lane against
a bright core occupies a handful of adjacent levels, and a single global mapping
cannot spread those apart without wrecking everything else.

Adaptive equalisation computes a separate mapping for each tile of a grid, so a
region is equalised against its own neighbourhood. Two problems follow, and CLAHE
solves both:

**Noise amplification, solved by clipping.** A tile of near-empty sky has almost
all its pixels in a few bins, so equalisation stretches those bins enormously and
the noise with them. Clipping caps any bin at a multiple of the mean bin height
and redistributes the excess evenly, which bounds the slope of the mapping and
therefore bounds how far noise can be amplified.

**Tile seams, solved by interpolation.** Applying each tile's mapping to its own
pixels leaves a visible grid. Every pixel is instead mapped by bilinear
interpolation between the four nearest tile centres.

## Controls

| control | effect |
|---|---|
| **Tiles** | grid divisions across and down. More tiles equalises against a smaller neighbourhood, bringing out finer structure but risking unevenness in large smooth areas. Fewer behaves more like global equalisation. |
| **Contrast Limit** | how much contrast gain a tile is allowed. Bounds the steepness of that tile's curve, and so bounds how far the noise under the signal is stretched with it. **No image data is clipped** — the limit applies to the internal histogram, not to pixel values. |
| **Amount** | blend between the original and the equalised result. Zero is an exact no-op. |
| **Show Tiles** | draws the tile grid and centre marks over the preview. Display only — it is painted after the image and never touches sample data, so nothing it draws can reach the output. |
| **Preserve Colour** | derive the transform from luminance and apply it as a ratio, so pixels change brightness but not colour. Unchecked, each channel is equalised separately, which is stronger but shifts hue. Ignored for mono. |

### Defaults, and why they are conservative

`24 tiles, contrast limit 1.0, amount 0.5`.

CLAHE gives the most contrast where the histogram is densest. On a photograph
that is usually the subject; on an astronomical frame it is the **background
sky**, because that is where most pixels are. So the default behaviour of the
algorithm is to enhance the thing you least want enhanced.

Measured on a synthetic frame with real filamentary structure in a faint arm,
using a high-pass filter so gradients do not mask the result:

| tiles | limit | amount | sky noise | filaments | structure-to-noise vs baseline |
|---|---|---|---|---|---|
| — | — | — | 2.89e-3 | 4.72e-3 | 1.000 |
| 24 | 1.0 | 0.5 | 4.29e-3 | 6.58e-3 | 0.937 |
| 24 | 2.0 | 1.0 | 8.52e-3 | 1.22e-2 | 0.875 |
| 8 | 3.0 | 1.0 | 1.13e-2 | 1.38e-2 | 0.745 |

Every setting lifts the sky faster than the structure. The defaults are simply
the gentlest useful point on that curve. More tiles helps a little; a higher clip
limit hurts a lot.

### Use a mask

The measurement above says plainly what to do: keep CLAHE off the background.

| configuration | sky noise | filaments | structure-to-noise |
|---|---|---|---|
| baseline | 2.89e-3 | 4.72e-3 | 1.000 |
| defaults, no mask | 4.29e-3 | 6.58e-3 | 0.937 |
| defaults, masked to signal | 2.89e-3 | 6.59e-3 | **1.394** |

With the background protected, the filaments gain exactly as much while the sky
gains nothing — the ratio goes from slightly worse than baseline to 39% better.
That is the difference between a tool that costs you noise and one that does not.

### Choosing a contrast limit

Measured on a synthetic frame with a bright core, faint outer nebulosity and
noise, in a flat sky region:

| contrast limit | sky noise sigma | contrast in the faint region |
|---|---|---|
| 1.0 | 2.4e-3 | 2.7e-2 |
| 2.0 | 3.6e-3 | 3.3e-2 |
| 3.0 | 4.7e-3 | 4.0e-2 |
| 5.0 | 7.1e-3 | 5.5e-2 |
| 10.0 | 1.3e-2 | 8.5e-2 |

Both rise together — that is the trade the control exists to make. Judge it on
the sky, not on the nebula.

## Why this needed a change to the template

CLAHE is not a point transform. No pixel can be mapped until every tile histogram
is complete, so the template's pixelwise interface could not express it.

The engine now offers an optional **two-pass protocol**. A method may supply
`analyse()`, which streams the image read-only, and `finalise()`, which runs once
between the passes to turn what was gathered into the mapping `apply()` uses.

Memory stays bounded: only what the method chooses to accumulate persists, never
the image. CLAHE holds `tiles x tiles x 1024` floats — four megabytes at the
largest grid, against roughly 300 MB for a full-resolution colour frame.

`ctx.y0` and `ctx.rows` were added so a method can tell where its block sits,
which anything spatially varying needs.

The transfer curve plot was removed. CLAHE has no single transfer curve — the
mapping varies across the frame, which is the whole point.

## Does the contrast limit clip my data?

No. The control is named for what it limits: contrast gain. Internally it caps
the **histogram** — the counting table used to derive the curve — not pixel
values. Capping a bin at, say, three times the average and
redistributing the excess limits how *steep* the mapping can become, and a steep
mapping is what amplifies noise.

Measured on a 512x512 synthetic frame:

| contrast limit | output range | pixels at 0 | pixels at 1 | distinct values in / out |
|---|---|---|---|---|
| 1.0 | 0.05989 - 0.73104 | 0 | 0 | 255,697 / 255,778 |
| 3.0 | 0.06175 - 0.91807 | 0 | 0 | 255,697 / 258,105 |
| 10.0 | 0.06845 - 1.00000 | 0 | 11 | 255,697 / 260,104 |

Nothing is driven to black. At clip 10 eleven pixels out of 262,144 arrive at
exactly 1.0 — those are the brightest pixels reaching the top of the range, which
is what equalisation does, not values being cut off.

The mapping is strictly order preserving: swept over all 65,536 16-bit levels at
a fixed pixel, **zero decreasing steps and 65,536 distinct outputs**. Nothing
brighter ever becomes darker, and no two input levels collapse onto one.

### One thing that did lose data, and was fixed

The first build looked up the nearest of 1024 histogram bins, so 64 adjacent
16-bit levels produced the identical output — 1024 distinct outputs from 65,536
inputs, which would band on a smooth gradient. The mapping is now read by
interpolating between the two neighbouring bins, restoring full resolution at the
cost of four extra array reads per pixel.

## How many tiles?

The **Tiles** control is the number of divisions across and down, so the grid is
that number squared:

| tiles | grid | mappings held |
|---|---|---|
| 2 | 4 | 16 KB |
| 8 (default) | 64 | 256 KB |
| 16 | 256 | 1 MB |
| 32 (maximum) | 1024 | 4 MB |

Each tile holds 1024 float bins. Even at maximum that is four megabytes, against
roughly 300 MB for a full-resolution colour frame.

On a 6000 x 4000 image, 8 tiles makes each one 750 x 1000 pixels; 32 tiles makes
each 187 x 125.

### Reading the overlay

The **centre marks** matter more than the boundary lines. Every pixel is mapped
by a weighted blend of the four nearest tile centres, so a pixel sitting on a
centre takes that tile's mapping alone, and one on a boundary is an even mix of
two. The spacing of the centres is the real scale of the effect.

If structure you care about is smaller than one tile, the tile is being asked to
equalise it against its own surroundings, which is the intent. If it spans
several tiles, each part is being equalised against a different neighbourhood,
which is where large smooth regions can start to look uneven.

## Verified

| check | result |
|---|---|
| Amount 0 is an exact no-op | max difference 0.00e+0 |
| Streaming gives the same answer as a single block | identical at 16, 64 and 256 rows |
| Output in range, no NaN, four configurations | 0 out of range, 0 non-finite |
| Contrast limit controls noise amplification | monotonic, see the table above |
| No tile seams | boundary/elsewhere gradient ratio 0.51 |
| Colour preserved below saturation | max ratio change 8.9e-8 |

The seam test was validated against a deliberately seamed build — nearest-tile
mapping with no interpolation — which it scores at 9.46 against the shipped
path's 0.51. A test that cannot detect the fault it checks for is worthless.

Colour is preserved exactly except where a channel reaches 1.0 and has nowhere
left to go, which is unavoidable for any ratio-based method. On the test frame
that was 115 pixels out of 65,536.

## Editing the header text

The paragraph block at the top of the dialog is `METHOD_INFO` at the top of
`lib/Methods.js`. It is HTML: `<p>` starts a paragraph, `<b>` makes text bold. Set
it to `""` for an empty panel, or delete the variable and the dialog falls back to
the method's own one-line description.

It sits beside the maths deliberately, so replacing the method and rewriting what
the dialog says about it are the same edit.

## Requirements

PixInsight 1.8.9 or later, V8 engine.

## Provenance

Built on the PixInsight Script Template. The conventions this code follows, and
the PJSR traps it works around, are documented in `DEVELOPMENT_RULES.md` in the
template, not here — one copy, so it cannot go stale in a clone.

Changes this script made to the template, worth folding back:

- **A two-pass streaming protocol.** `analyse()` and `finalise()`, plus `ctx.y0`
  and `ctx.rows`, so a method whose mapping depends on the whole image can be
  expressed without holding the image.
- **A preview overlay hook.** `PreviewControl.onOverlay`, so a method can draw
  over the preview — the tile grid here — without the generic control knowing
  what is being drawn.
- **Lazily measured statistics.** `ctx.stats` is now a getter, so a method that
  never reads the full-image median and MAD does not pay for measuring them.
