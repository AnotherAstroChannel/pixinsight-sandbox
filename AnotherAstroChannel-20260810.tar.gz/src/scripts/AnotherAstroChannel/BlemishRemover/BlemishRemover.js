/*
 ****************************************************************************
 * PixInsight Script Template
 *
 * Template.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.34  WHITE ARROWS AND WHITE-EDGED ICON BUTTONS -- his call, asked
 *        for three times while grey after grey was offered instead,
 *        and approved from a drawing before this was built. The
 *        drop-down arrow is drawn as a CSS triangle in #ffffff
 *        rather than loaded from a resource, so there is no asset
 *        path left to fail; the platform's own arrow art is dark,
 *        for light panels. The per-row reset buttons and the
 *        dialog's own icon buttons -- new instance, execute,
 *        cancel, real-time, documentation, diagnostics and the
 *        preview's zoom trio -- carry a white edge on a dark chip.
 *        The chip stays dark deliberately: the glyphs are light,
 *        and a white FILL would erase them. The diagnostic build's
 *        magenta and orange are gone; its counting line is gone
 *        too, but a refusal still warns to the console, because
 *        four silent try/catch blocks are how a fix shipped four
 *        times and changed nothing.
 * 1.33  DIAGNOSTIC BUILD -- THE COLOURS ARE DELIBERATELY WRONG, and
 *        the next build takes them out again. Four attempts to shade
 *        the icon buttons have come back from PixInsight looking
 *        identical, and the pixels cannot say WHY: refused,
 *        ignored, or applied and invisible all look the same. So
 *        the reset buttons are screaming magenta, the dialog's own
 *        icon buttons orange, and themePolish now COUNTS what it
 *        did and prints it -- four silent try/catch blocks in a row
 *        is how a fix ships four times and changes nothing. Three
 *        outcomes, each pointing somewhere different: solid colour
 *        means the sheet reaches the control and only the colour
 *        was ever wrong; a thin coloured RING around the icon means
 *        the icon is drawn over the whole button and no fill can
 *        ever show (the borders have always rendered -- that is the
 *        clue); no colour at all means no style sheet reaches a PCL
 *        ToolButton and the answer is a different mechanism. The
 *        console line reports the counts independently of the
 *        pixels. Rule 82's method, which ended the confetti in one
 *        screenshot after six plausible fixes had failed.
 * 1.32  THE ICON BUTTONS, ON THE ONE FORM PROVEN TO REACH A PCL
 *        CONTROL. Three builds tried to shade the per-row reset
 *        buttons and each left them sunk into the panel in his
 *        screenshots: a dialog-level QToolButton rule, the same
 *        rule with the background shorthand, then a widget-local
 *        sheet wrapped in `*`. Meanwhile the section panels have
 *        been correctly shaded since the pilot -- by a widget-local
 *        sheet of BARE DECLARATIONS. That form is now copied
 *        exactly instead of a fourth variation being invented, and
 *        the verifier asserts the chip sheet carries no selector so
 *        the failing form cannot come back. Accepted cost: bare
 *        declarations cannot express :hover, so these buttons lose
 *        their hover lift -- a button that can be SEEN beats one
 *        that lights up once the pointer is already on it.
 *        THE DIALOG'S OWN ICON BUTTONS get the same chip (his
 *        second report: the row along the bottom "blending into
 *        the dark background") -- new instance, execute, cancel,
 *        real-time, documentation, diagnostics and the preview's
 *        three zoom buttons. The platform paints them transparent,
 *        so on this floor they were icons floating on nothing.
 * 1.31  THE RESET BUTTONS AND THE DROP-DOWN ARROW, ON THE ROUTE THAT
 *        ACTUALLY REACHES THEM (his report on the last build: "I
 *        dont see any of the changes" -- the package carried them,
 *        the controls ignored them). Both were styled by
 *        DIALOG-LEVEL class rules, QToolButton and
 *        QComboBox::drop-down, and those do not reach PCL's
 *        controls -- the same lesson this theme learned twice
 *        before, for the section panels and the popup lists, and
 *        the reason both of those are set WIDGET-LOCALLY. They are
 *        now set the same way: themePolish puts a chip sheet on
 *        every reset button it finds on the dialog, and the arrow
 *        compartment sheet on every picker AND every schema-built
 *        combo (recognised by what it can do, since the method and
 *        Show dropdowns are declared in Config and appear in no
 *        script's picker list). The lift shade goes from one step
 *        above the panel to clearly above it -- the previous value
 *        would have been near-invisible even had it applied.
 *        verify_theme_wiring.js now asserts the sheets ON THE
 *        OBJECTS, not merely that the rules exist: a rule assigned
 *        to nothing is exactly what shipped last time.
 * 1.30  THE BLUE GRID, AND TWO CONTRAST FIXES HE ASKED FOR. The grid
 *        in a value box was never our focus handling: PixInsight's
 *        OWN style sheet (rsc/qss/core-standard.qss) paints these
 *        controls with TILED 9-slice images -- QLineEdit:focus gets
 *        border-image: url(:/qss/border-focus.png) 33% repeat -- and
 *        a light-theme frame repeated across a 20-pixel box renders
 *        as a blue checkerboard over the value. border-image is a
 *        separate property from border, so setting a border never
 *        displaced it. Now turned off by name on every state the
 *        platform sets it on, for line edits, spin boxes, combos,
 *        push buttons and tool buttons; a focused edit takes a plain
 *        accent outline instead. This also retires the "hatched
 *        button" seen in the earliest theme screenshots.
 *        THE DROP-DOWN NOW LOOKS LIKE ONE (his report): the arrow's
 *        compartment is a step lighter than the field with a divider
 *        down its left edge, and the arrow is the platform's LIGHT
 *        glyph -- its own combobox arrow art is drawn dark, for light
 *        panels, and was invisible here. THE RESET BUTTONS (his
 *        report) sit on a chip above the panel with a defined edge:
 *        the platform paints QToolButton transparent, which put them
 *        into the panel. verify_theme_wiring.js asserts all of it.
 * 1.29  THE FOCUS GRID IN A VALUE BOX, root cause found in the
 *        platform's own header (his UnsharpMaskPro screenshot: the
 *        Star detection value box filled with a blue dither).
 *        Shared Compat.js resolved FOCUS_CLICK to 0x01 -- and
 *        pjsr/FocusStyle.jsh says 0x01 is FocusStyle_Tab; Click is
 *        0x02. PJSR declares these as preprocessor defines, so the
 *        runtime probes never resolve and the fallback IS the
 *        value. Every value edit the theme made "click-only" was
 *        therefore made the dialog's FIRST TAB STOP, so the
 *        opening focus landed on one and painted its focus marks
 *        over the number -- the artifact rule 82 part 3 exists to
 *        prevent, delivered inverted. The constant now comes from
 *        the header, with FOCUS_NONE and FOCUS_WHEEL checked
 *        against it too, and verify_theme_wiring.js asserts all
 *        three so the value cannot drift back. The preview's
 *        FOCUS_CLICK|FOCUS_WHEEL becomes click+wheel as intended
 *        (it was tab+wheel), which also takes it out of the tab
 *        chain.
 * 1.28  THE DARK THEME, suite-wide (rule 82; StarMask 0.39-0.53
 *        piloted it): Theme.js is included, applyTheme skins the
 *        dialog before any control constructs, and the themePolish
 *        one-shot names this script's hand-built controls
 *        (the three placement buttons). The shared Target view picker is now the
 *        themed combo -- ViewList's closed face is core-painted past
 *        any style sheet (Template 2.59). Also inherited from
 *        Part-2, recorded here per rule 65: the wheel-zoom stand-in
 *        holds through the rebuild instead of snapping back to the
 *        stale view (shared PreviewControl, Template 2.58).
 *        Shared ParamControls now lists every per-row reset button
 *        on the dialog as it creates them, so the polish reaches
 *        controls no script names -- they were the one focusable
 *        class the recipe could not see.
 * 1.27  Shared PreviewControl: a rebuild finishing during an open drag
 *        parks its result and publishes at gesture end -- the in-flight
 *        rebuild can no longer eat the zoom box. Template 2.57.
 * 1.26  Shared PreviewControl: the wheel-zoom feedback anchors on the
 *        rendered selection (the 1.25 anchor jumped the view by the pan
 *        margin), and the gesture guard moved into rebuild() itself --
 *        no caller can steal a drag. Template 2.56.
 * 1.25  Shared PreviewControl: wheel zoom commits on wheel-quiet --
 *        notches accumulate with live scaled feedback, one rebuild 0.3 s
 *        after the last notch, mouse press commits first. Armed-mode
 *        wheel circle sizing untouched. Template 2.55.
 * 1.24  Shared MainDialog: the default per-control layout is callable
 *        (layoutGeneratedControls), so a section builder can compose
 *        schema rows around a hand-built one (UnsharpMaskPro 2.00's
 *        Masks section). No behaviour change here. Template 2.54.
 * 1.23  Shared Engine: Execute writes any displayed view -- the guard
 *        that blocked executing a diagnostic view is removed (the run is
 *        one undoable process step; the console notes a diagnostic
 *        output). Template 2.52 carries the mechanism.
 * 1.22  Shared AutoStretch: computeAutoStretch reads the native
 *        median/MAD first, keeping the JS histogram as the fallback --
 *        the derivation cost twelve full-frame JS passes on a color
 *        frame, most of a 49-second stars-only mask build (StarMask
 *        0.24). The screen stretch pays milliseconds now.
 * 1.21  Shared PreviewControl: the screen stretch always applies to the
 *        untransformed picture; only a diagnostic-map TRANSFORM skips its
 *        stretched copy. The old guard nulled the stretch for the whole
 *        preview, so a map view with Show transformed off displayed the
 *        plain image unstretched beside a ticked box (reported on
 *        StarMask 0.23; structural everywhere). Template 2.50 carries the
 *        mechanism.
 * 1.20  THE WHEEL SIZES THE CIRCLE while Place circles is armed -- 12%
 *        per notch, clamped to the Radius schema limits, the ghost
 *        updating at the pointer so the size is seen before the click;
 *        wheel zoom is deliberately locked out in that mode (the user's
 *        spec). Disarm to zoom again. Shared hook in PreviewControl,
 *        Template 2.49.
 * 1.19  Shared MainDialog: the preview debounce defers while a zoom or
 *        pan drag is active, so a queued refresh can no longer eat
 *        the drag (reported on StarMask; structural everywhere).
 *        The mechanism is the Template 2.48 changelog entry.
 * 1.18  REMOVALS HEAL IN PLACEMENT ORDER -- Bill's report, from his own
 *        screenshots: two adjacent removals each read the OTHER's
 *        still-present star from the pristine image, and one bled into the
 *        other's patch. Every patch used to be built independently from
 *        the original view; now the chain builds SEQUENTIALLY: each
 *        patch's target, ring, donor probes and donor read the image with
 *        every EARLIER patch composited over it, donors are excluded from
 *        ground any LATER circle marks, and -- the part ordering alone
 *        could not fix, found when the fixture matched his overlapping
 *        geometry -- a later circle's territory never pins the membrane:
 *        those pixels are interpolated across instead (the StarMask
 *        fill's answer to neighbouring masked ground), then overwritten
 *        by their own patch, which apply's placement order guarantees.
 *        solveHarmonic carries the three amendments StarMask's port
 *        earned (boundary-mean init, full-grid sweep with reflective
 *        edges, no-boundary returns false), each reducing to the original
 *        on interior discs. The per-circle cache became one CHAIN cache
 *        keyed by view + circle list: a click rebuilds the chain once --
 *        each patch is small, so per-click updating is the CHEAP
 *        direction -- and every zoom or slider refresh between clicks is
 *        a hit. verify_sequential_patches.js is the user's case as an
 *        assertion, on the SHIPPED Methods.js: overlapping circles over
 *        two planted stars, both patches clean at 3.6 sigma, and the old
 *        independent build failing the same gauge at 191 sigma as the
 *        built-in red case.
 * 1.17  THE PLACEMENT GHOST (Bill's request, worded by him: see the circle
 *        size on screen BEFORE clicking, adjust it with the slider in real
 *        time). While Place circles is armed, the preview draws a circle
 *        at the current Radius under the pointer, following every move and
 *        every slider change live; a click then commits exactly what was
 *        shown. Display-only overlay in the shared PreviewControl
 *        (cursorCircleRadius hook, null for every script that does not
 *        set it); this script wires it to engine.radius in
 *        updateExtraControls. Right-click removal is unchanged.
 * 1.16  Per-parameter reset button at the end of every slider row (shared
 *        ParamControls), matching PixInsight's own convention: click
 *        restores the schema default and refreshes the preview.
 * 1.15     The screen stretch target is labelled "Background target", which is
 *          what the number is: the background level the stretch aims for.
 * 1.14     TARGET BACKGROUND FOR THE SCREEN STRETCH, beside the mode in the
 *          preview header, default 0.20 (the old fixed constant was 0.25).
 *          Shared change: the target is a parameter of computeAutoStretch,
 *          part of the stretch cache key, and a NumericEdit in the shared
 *          dialog. View STF ignores it, as that mode uses the view's own
 *          transfer function. Verified: on a real frame the midtone moves
 *          monotonically with the target and nothing else changes.
 * 1.13     THE PATCH IS WRITTEN BY A BACKWARD MAP. It used to walk the
 *          patch and push each image pixel to the buffer pixel it lands on,
 *          which only fills the target while the view is SHRINKING. Zoomed
 *          in, each image pixel lands on one buffer pixel of several and the
 *          rest were never written, so they kept the blemish underneath --
 *          a dither pattern inside every circle. Measured share of the
 *          circle actually written:
 *
 *             1:1.7 out   forward 100%   backward 100%
 *             1:1         forward 100%   backward 100%
 *             1.7:1 in    forward  35%   backward 100%
 *             2.3:1 in    forward  19%   backward 100%
 *             4:1 in      forward   6%   backward 100%
 *
 *          Walking the DESTINATION cannot leave holes: every pixel in range
 *          is visited once and asks where it came from, which is why image
 *          resampling is always written this way round. Execute never saw it
 *          because Execute runs at scale 1
 * 1.12     Output options and Preview dimensions start folded away
 * 1.11     Custom process icon and its own README
 * 1.10     Vertical pan travel matches horizontal. The render margin was sized from
 *          the selection, so wherever the selection was shorter than the control
 *          the margin went on covering that inset instead of giving travel -- 44%
 *          of a view on a 1600x900 selection, none at all on an extreme aspect.
 *          Sized from the control it is 75% in both axes at every aspect
 * 1.09     Pan clamped to the control rather than to viewPort(), which is the
 *          selection centred in the control and therefore inset wherever the
 *          selection is smaller than the control. That inset was the strip of
 *          empty canvas at the end of a drag -- 30 px on a full frame -- and it
 *          appeared in whichever axis had the slack
 * 1.08     The end of a pan showed empty canvas. The clamp measured the rendered
 *          margin in image coordinates, which exceeds what the bitmap covers by
 *          the slack between the fitted selection and the viewport -- 192 px for
 *          a 1600x900 selection in a 1024x768 preview. It now clamps to the
 *          bitmap's own extent
 * 1.07     Pan margin 0.75; header text down to two paragraphs
 * 1.06     Pan travel doubled. A drag is clamped to the rendered margin, which was a
 *          quarter of a view and now is half, so it stops to rebuild half as often
 * 1.05     Twelve times faster. Donor scoring sorted the whole ring once per
 *          candidate; patches are now cached by circle; and the radius no
 *          longer rebuilds anything, since it only sizes the next circle
 * 1.04     Real content, not synthetic noise. A donor patch is chosen from
 *          nearby and blended so it meets the circle edge exactly. The old
 *          fill added white noise, which has no structure at any scale and
 *          read as a smooth disc however well its amplitude was matched
 * 1.03     The fill was flat at any real radius -- 120 averaging sweeps cannot
 *          cross a large patch. It now solves on a decimated grid with
 *          over-relaxation, correct to about 2% at every radius and costing
 *          the same at all of them. Radius to 800. Show circles now repaints
 * 1.02     Placement buttons moved into Method parameters. They were in the
 *          preview bar, which is for things about the view, not the method
 * 1.01     The preview was blank: the crop scale passed to the method was
 *          declared inside a branch that had already closed, so the call
 *          threw into the enclosing catch and nothing rendered
 * 1.0      First release. Derived from the script template.
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    BlemishRemover : Another Astro Channel > Blemish Remover
#feature-icon  @script_icons_dir/BlemishRemover.svg


#feature-info  Removes small blemishes -- dust motes, satellite trails, stray stars -- by filling a placed circle from the pixels around it.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder, and it is the author's to decide:
 *
 *    ASSISTANTS -- ASK, DO NOT ASSUME. The person you are building for owns
 *    this line. Ask them what name and year they want, or whether they want no
 *    attribution at all, in which case set it to "" and the panel simply starts
 *    with the description. Do not copy a name out of an example, another
 *    script, or this file's history. Guessing here puts someone else's name on
 *    the user's work.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Blemish Remover"
#define VERSION     "1.34"
#define SCRIPT_ID   "BlemishRemover"
#define KEYPREFIX   "BlemishRemover"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Removes small blemishes by filling a placed circle from the pixels around it."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
#define PAN_MARGIN               0.75

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304


#define STATISTICS_BINS          1048576


/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define CURVE_PLOT_HEIGHT        200
#define READOUT_HEIGHT           32
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
