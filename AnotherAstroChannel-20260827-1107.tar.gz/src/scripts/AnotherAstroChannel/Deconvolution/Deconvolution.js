/*
 ****************************************************************************
 * PixInsight Script Template
 *
 * Template.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    Deconvolution : Another Astro Channel > Deconvolution


#feature-icon  @script_icons_dir/Deconvolution.svg




#feature-info  Deconvolution using the image's own measured star profile, with regularization that keeps noise and ringing down. For linear data.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder that belongs to whoever authors the
 * script: set it to the name and year that should appear, or to "" for no
 * attribution, in which case the panel simply starts with the description.
 * It must never be carried across from an example, another file, or this
 * file's history -- an inherited value credits the wrong author.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Deconvolution"
#define VERSION     "1.46"
#define SCRIPT_ID   "Deconvolution"
#define KEYPREFIX   "Deconvolution"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Deconvolution using the image's own measured star profile, with regularization that keeps noise and ringing down. For linear data."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
/*
 * 0.75 IS FIXED. Cutting the margin buys rebuild time by spending pan
 * reach, and a value low enough to matter clamped the pan at 8% of the
 * view. The margin is never the lever again: the rendered buffer is 3.06x
 * the canvas at 0.75 and a parameter change re-transforms all of it, so
 * the cost lever is CACHING the transform result (the LRU here, and a
 * full-resolution result cache where a method can hold one) -- a pan then
 * samples, it does not recompute.
 */
#define PAN_MARGIN               0.75

/*
 * HOW MANY PROCESSING LEVELS PER FACTOR OF TWO.
 *
 * The preview used to process at the DISPLAY scale, which is continuous: every
 * zoom produced a uniquely sized buffer, so no two zooms could share a single
 * computed pixel and caching was impossible in principle. It now processes at
 * a quantised LEVEL at or above the display scale and resamples that to the
 * canvas, which is what Photoshop, Lightroom, Capture One, darktable and GEGL
 * all do, and for the same reason.
 *
 * ONE CONSTANT, TWO COSTS:
 *
 *   1 -- powers of two (1, 1/2, 1/4, 1/8). What the other tools use. One
 *        level covers a 2x zoom range, so reuse is widest; a zoom sitting
 *        just under a level pays up to 4x the pixels the display strictly
 *        needs, about 2.1x on average.
 *   2 -- half-octave steps (1, 1/1.41, 1/2, ...). One level covers 1.41x, so
 *        reuse is narrower; the worst case falls to 2x and the average to
 *        about 1.44x.
 *
 * Powers of two are what the other tools use and give the widest reuse across
 * a zoom range; half-octave steps trade that reuse for a lower worst case.
 * The trade is entirely in this number and it is measurable, not a matter of
 * taste.
 */
#define PREVIEW_SCALE_OCTAVE_STEPS   2

/*
 * HOW FAR THIS METHOD'S RESULT TRAVELS, in buffer pixels at the processing
 * level. The preview renders what is on screen plus this, publishes it, and
 * fills the pan margin afterwards -- so the wait to a correct picture is set
 * by this number rather than by the margin.
 *
 * MEASURED, not assumed. tools/measure_decon_halo.js and
 * tools/verify_tile_agreement.js both put it at 24 px: a region computed with
 * that overlap agrees with the untiled result to 0.00 sigma, stars on the
 * boundary included. Richardson-Lucy's WORST case is twice the kernel radius
 * per iteration -- 720 px at 20 iterations -- and the practical reach is
 * nothing like it, because damping and the TV term kill the far field. That
 * gap is the whole reason this design is possible.
 *
 * TOO SMALL shows as a wrong edge around the visible area that changes when
 * the margin lands. TOO LARGE merely costs a little; on a 1024x768 canvas 24
 * px of halo is 1.13x the visible pixels, against 6.25x for the margin. Re-run
 * the two tools if the iteration count or the regularization changes a lot.
 */
#define PREVIEW_METHOD_HALO          24


/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304


#define STATISTICS_BINS          1048576


/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
/*
 * The blur radius, in image pixels, that separates detail from base.
 *
 * This is the one number that decides what the script IS. At a small radius the
 * detail layer is edges and grain, and scaling it sharpens; at a large one it is
 * structure several tens of pixels across, and scaling it is what other software
 * calls clarity. Same filter, same control.
 */
/*
 * The smallest radius, in BUFFER pixels, the preview can honestly draw. Three
 * box passes are a running sum over 2r+1 pixels, so there is no window below
 * one. Under this the preview leaves the image alone and says the radius is
 * not visible at that zoom, rather than drawing a coarser operation than
 * Execute will apply.
 */
#define DETAIL_MIN_BUFFER_RADIUS 1.0

/*
 * How far Rescale keeps the result from black and white, as a fraction.
 *
 * Rescaling to exactly 0 and 1 leaves nothing at either end: the darkest pixel
 * is then unrecoverably black and the brightest unrecoverably white, and any
 * later curve has nothing to pull back. 0.2% of the range costs nothing
 * visible and leaves both ends intact.
 *
 * Hardcoded rather than exposed. It is not a creative decision and a control
 * for it would be one more thing to explain.
 */

/*
 * How far short of black and white the headroom limiter stops, as an ABSOLUTE
 * value.
 *
 * The limiter approaches the boundary asymptotically, but float32 has a step of
 * 1.19e-7 next to 1.0, so anything closer than that rounds onto it. A margin
 * proportional to the headroom shrinks below the representable step exactly
 * where it matters -- at pixels already near white -- and the guarantee fails
 * silently. 1e-6 is representable at both ends and invisible.
 */



/*
 * Rows per streamed band, and the halo each band reads beyond its own rows.
 *
 * The blur is three box passes, so it reaches three times the radius, and a
 * fractional radius applies it twice, once at each of the two integer radii
 * either side. Six times the radius is what makes a band self-contained.
 * Measured: 512 rows with a 120 pixel halo is 235 MB resident for a 24
 * megapixel colour frame, against 1960 MB for the whole image, and that
 * figure does not grow with the image.
 */
#define DETAIL_HALO_FACTOR       6


/*
 * Rec. 709 luminance, the same weights every mask here uses. Consistency
 * matters more than the choice: two masks disagreeing about what brightness
 * means would select differently on the same pixel.
 */
/*
 * STAR DETECTION AND PSF MEASUREMENT
 *
 * STAR_DETECT_SIGMA is above the SKY in units of the noise. The measured PSF is
 * insensitive to it: on a real frame the median FWHM moved 3% across thresholds
 * from 10 to 40 sigma, so it is set high enough that faint candidates do not
 * dominate the sort rather than tuned.
 *
 * STAR_FIT_MAX is 150 because 50 stars already give the median FWHM to within
 * 0.3% of what 487 give. Beyond that it is cost with no accuracy.
 *
 * STAR_SAMPLE_ROWS bounds the statistics pass. 400 rows spread over the frame
 * gives the noise to well within 1% and does not grow with the image.
 *
 * STAR_BLEND_FRACTION is applied to a genuine second MAXIMUM, never to a bright
 * pixel. A star of sigma 1.9 has 28% of its peak at radius 3, so testing bright
 * pixels at 30% rejects stars for their own wings -- 93% of them, measured.
 */
#define STAR_WINDOW              8

/*
 * The radius of the local background window used for star DETECTION, in pixels.
 *
 * A star must stand above its own surroundings, not above the frame's median.
 * Measured: thresholding against the global sky found 6070 candidates on a real
 * frame against 2499 with a local background, and the extra ones were nebula
 * texture -- a mask painted from them covered the nebula in a solid blob.
 *
 * 20 is comfortably wider than any star and far narrower than the nebulosity it
 * has to follow. It sets the halo the detection pass reads, so raising it costs
 * memory as well as time.
 */
#define STAR_BACKGROUND_RADIUS  20
#define STAR_NOISE_BINS          16

/*
 * The width cap, as a multiple of the frame's own median core width. A star's
 * width is the seeing and every star shares it; anything much wider is not one.
 */
#define STAR_ALPHA_FACTOR        1.4

/* Below this many detections the median is not worth trusting, so no cap. */
#define STAR_ALPHA_SAMPLE_MIN    50

/*
 * The seeing median is taken over detections at least this bright, in local
 * sigma. Above it a detection is almost always a real star at any threshold,
 * so the cap cannot be poisoned by a low detection setting.
 */
#define STAR_SEEING_AMP_MIN      30

/*
 * The walk level's narrow reference, a box radius in pixels. Wide enough to sit
 * under a star, narrow enough to follow a nebula ridge.
 */
#define STAR_WALK_RADIUS         3

/*
 * How much of the detection threshold the narrow amplitude must also clear.
 * A half, because the narrow reference sits partly on a real star's own wings.
 */
/*
 * The radius of the reference the noise is measured against. Small enough that
 * an object's structure survives it and only pixel-to-pixel scatter is left.
 */
#define STAR_NOISE_SCALE         2
#define STAR_ELLIPSE_ARMS        16

/*
 * How far the profile may rise above its lowest point before the walk decides
 * the star has ended, in units of the local noise. Grain alone must not end it.
 */
#define STAR_TURN_TOLERANCE      2.0

#define STAR_SAMPLE_ROWS         400
#define STAR_NOISE_SAMPLES       50000
#define STAR_DETECT_SIGMA        20
#define STAR_FIT_MIN             8
#define STAR_FIT_MAX             150
#define STAR_CANDIDATE_SLACK     20
#define STAR_SATURATION          0.999
#define STAR_CORE_RADIUS         3
#define STAR_BLEND_FRACTION      0.30
#define STAR_PROFILE_BINS        32
#define STAR_BIN_MIN             5

/*
 * The adaptive moment weight. STAR_MOMENT_CUTOFF is in squared Mahalanobis
 * radius, so 9 is three sigma of the current estimate -- past that the weight
 * is under 0.011 and the pixel is noise.
 */
#define STAR_MOMENT_SEED         2.0
#define STAR_MOMENT_ITERATIONS   12
#define STAR_MOMENT_CUTOFF       9

/*
 * The Moffat grid. beta is the wing weight: 4.765 is pure Kolmogorov seeing and
 * real data sits lower. Measured 3.1 to 3.5 on a real frame, so the range is
 * wide enough to be a measurement rather than a confirmation of the default.
 */
#define MOFFAT_BETA_MIN          1.2
#define MOFFAT_BETA_MAX          9.0
#define MOFFAT_BETA_STEP         0.02
#define MOFFAT_BETA_COARSE       0.20
#define MOFFAT_FWHM_MIN          1.2
#define MOFFAT_FWHM_MAX          12.0
#define MOFFAT_FWHM_STEP         0.01
#define MOFFAT_FWHM_COARSE       0.10

#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define CURVE_PLOT_HEIGHT        200
#define READOUT_HEIGHT           32
// 0.25 was right when a rebuild cost a fraction of a second. This method's
// rebuild costs seconds and BLOCKS the event loop, so a quarter-second
// hesitation mid-drag froze the slider under the finger. 0.8 only fires on a
// deliberate hold.
#define PREVIEW_DEBOUNCE_SECONDS 0.8

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/Luminance.js"
#include "lib/StarMeasurement.js"
#include "lib/StarDetect.js"
#include "lib/AutoStretch.js"
#include "lib/EdgeMap.js"
#include "lib/MethodRegistry.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamSchema.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
/*
 * THE PREVIEW CONTROL IS SHARED, and it stays shared.
 *
 * This file uses the copy in shared/lib, not a local one. That copy is what
 * gives the preview its behaviour: the processing level is never coarser
 * than the display, the visible region publishes before the pan margin, the
 * drag is bounded by the frame rather than the buffer, and a gesture can
 * abandon a render in flight.
 *
 * A private copy drifts silently, which is the failure the shared library
 * exists to prevent: one library here once stood as eight copies, one of
 * them 92 lines behind the rest and nothing reporting it. check_workspace.py
 * fails on a duplicate that carries no declared reason, so a fork cannot be
 * taken quietly -- if one is ever genuinely needed, declare it there and
 * fold it back.
 */
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      /*
       * TIMED. Opening this script cost thirty seconds against three for a
       * tool that does not transform at full resolution, and the cost was not
       * where it appeared to be. The stages report their own times so a
       * regression here is attributable rather than guessed at.
       */
      let t0 = Date.now();
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();
      let tTarget = Date.now();

      let dialog = new MainDialog( engine );
      let tDialog = Date.now();

      console.noteln( "<end><cbr>open: target " + ( tTarget - t0 ) + "ms" +
                      "   dialog built in " + ( tDialog - tTarget ) + "ms" );

      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
