/*
 ****************************************************************************
 * Star Mask -- the suite's star mask, as its own script
 *
 * StarMask.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
  */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    StarMask : Another Astro Channel > Star Mask


#feature-icon  @script_icons_dir/StarMask.svg


#feature-info  The suite's star mask as its own script, for building and debugging it.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder, and it is the author's to decide:
 *
 *    ASSISTANTS -- ASK, DO NOT ASSUME. The person you are building for owns
 *    this line. Ask them what name and year they want, or whether they want no
 *    attribution at all, in which case set it to "" and the panel simply starts
 *    with the description. Do not copy a name out of an example, another
 *    script, or this file's history. Guessing here puts someone else's name on
 *    the user's work.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Star Mask"
#define VERSION     "2.01"
#define SCRIPT_ID   "StarMask"
#define KEYPREFIX   "StarMask"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan"
#define DESCRIPTION "Builds, shows and debugs the star mask the suite shares: local-background detection in noise sigma, painted from each star's own measured profile."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
// Halo sizing and luminance weights -- carried with the star machinery.
#define DETAIL_HALO_FACTOR       6
#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

// Star profile fit search space -- carried with lib/StarMeasurement.js.
#define STAR_WINDOW              8
#define STAR_BACKGROUND_RADIUS  20
#define STAR_NOISE_BINS          16
#define STAR_ALPHA_FACTOR        1.4
#define STAR_ALPHA_SAMPLE_MIN    50
#define STAR_SEEING_AMP_MIN      30
#define STAR_WALK_RADIUS         3
// The texture gate's bar, ABSOLUTE in noise sigma -- 7.5 is the swept-good
// 1.5 x the old default threshold of 5, frozen so the bar no longer rides
// the user's Star detection slider: it used to, and raising the slider
// silently deleted BRIGHT stars (rule 48's non-monotonic control; measured
// on Test_2, two 76-sigma stars gone at detect 6.58).
// A candidate this significant on the MATCHED map, with this much raw
// amplitude, is a star regardless of the texture gate -- the gate's narrow
// 3 px reference rides a bright compact star's own profile, so a 77-sigma
// star can read 7 sigma against it and die (rule 59's degenerate end,
// measured at (1342,876) on Test_2: raw 77.5, matched 144.6, wAmp 7.1).
// Both bounds must hold: matched certainty alone would readmit the
// broad-bump class whose raw amplitude is under two sigma.
// The SOLO certainty bar: raw amplitude alone at this level is a star, no
// second opinion needed. Exists for NEAR-saturated giants (Test_5's core
// peaks at 0.9972 -- brilliantly bright, no exact float ties, so no flatTop
// exemption), whose broad cores read near zero against BOTH the narrow
// reference and the matched filter: every shape instrument degenerates at
// once (rule 59), and only raw amplitude still speaks. Well above the
// measured knot false class (Test_3 core knots: median 64 sigma).
#define STAR_NOISE_SCALE         2
#define STAR_ELLIPSE_ARMS        16
#define STAR_TURN_TOLERANCE      2.0
#define STAR_SAMPLE_ROWS         400
#define STAR_NOISE_SAMPLES       50000
#define STAR_DETECT_SIGMA        20
#define STAR_FIT_MIN             8
#define STAR_FIT_MAX             150
#define STAR_CANDIDATE_SLACK     20
#define STAR_SATURATION          0.999
#define STAR_CORE_RADIUS         3
#define STAR_BLEND_FRACTION      0.30
#define STAR_PROFILE_BINS        32
#define STAR_BIN_MIN             5

#define STAR_MOMENT_SEED         2.0
#define STAR_MOMENT_ITERATIONS   12
#define STAR_MOMENT_CUTOFF       9
#define MOFFAT_BETA_MIN          1.2
#define MOFFAT_BETA_MAX          9.0
#define MOFFAT_BETA_STEP         0.02
#define MOFFAT_BETA_COARSE       0.20
#define MOFFAT_FWHM_MIN          1.2
#define MOFFAT_FWHM_MAX          12.0
#define MOFFAT_FWHM_STEP         0.01
#define MOFFAT_FWHM_COARSE       0.10

// RULE 62, applied in 0.12 after the user reported the slowness it predicts:
// the rendered buffer is the canvas plus this margin on every side, so the
// Template's 0.75 is a 5.2x PIXEL BUDGET -- right for its trivial example
// method, wrong from the moment this script's transform grew the fill and
// the gate. It is also exactly why zooming in did not feel faster: the
// buffer is canvas x 5.2 whatever the zoom. 0.10 is a 1.44x budget, in line
// with Deconvolution's 0.08 and UnsharpMaskPro's 0.15.
// Restored to the generous Template value in 0.14: the result caches broke
// the pan-vs-zoom trade (rule 72) -- a rebuild now samples cached results
// instead of re-running detection or the fill, so the 5.2x pixel budget
// buys full pan travel at trivial cost. If a future method change makes
// rebuilds expensive again, this is the constant that must move with it.
#define PAN_MARGIN               0.75

/*
 * The reach of this script's method, in BUFFER pixels at the processing level.
 *
 * The preview renders the visible region PLUS this, publishes it, and fills the
 * pan margin afterwards -- so it is what makes the visible pixels correct
 * without waiting for the margin. Too small shows as a SEAM; too large only
 * costs a few pixels, so the safe direction is up.
 *
 * 64 is the conservative default, and deliberately generous: it covers a
 * method whose kernel reaches much further than this example's does. For
 * comparison, a twenty-iteration Richardson-Lucy deconvolution measures its
 * true reach at 24, with 0.00 sigma of error against an untiled result.
 * Measure it for your own method and lower it when there is a reason to.
 */
#define PREVIEW_METHOD_HALO          64

/*
 * How many processing levels per factor of two. ONE CONSTANT, TWO COSTS
 * (rule 72).
 *
 * The preview processes at a fixed ladder of scales and takes the coarsest rung
 * that is still at least as fine as the display, so what is shown is never
 * softer than the panel it is drawn on. This sets how far apart the rungs are:
 *
 *    1  full octaves   a zoom landing just under a rung pays up to 4x the
 *                      display pixel count, about 2.04x on average
 *    2  half octaves   at most 2x, about 1.44x on average
 *
 * 2, measured on a 9032x6028 frame: an open and two zooms processed at 1.10x,
 * 1.02x and 1.31x the display size per axis. Full octaves were tried and cost
 * 3.26x the AREA at a zoom just under a rung.
 */
#define PREVIEW_SCALE_OCTAVE_STEPS   2

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
/*
 * The highlight stage is a pure function of one value, so it is tabulated once and
 * read back per pixel rather than recomputed. Math.pow costs a factor of nine on
 * the whole transform: 16.5 Msamples/s computing it against 147 with the table.
 *
 * ROLLOFF_DIRECT_BELOW exists because r^H has an infinite derivative at zero, so
 * interpolation is poor near black -- a uniform table over [0,1] is out by 1.0e-4
 * there, which is 1600 times float32 resolution. Below the cut the value is
 * computed exactly instead. At 0.01 the worst error over the whole range falls to
 * 1.9e-9, and almost nothing in a stretched frame sits that low, so the speed is
 * kept.
 */

#define STATISTICS_BINS          1048576

/*
 * How close the target background must be to the image median before the
 * proportional method treats the request as "leave it alone". Measured as a
 * fraction in log ratio: 0.10 means a 10 percent move already gets about 60
 * percent of the full stretch, and a 25 percent move about 90 percent.
 */

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
#define CURVE_PLOT_HEIGHT        200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
// RULE 62. 0.25 is right for a method whose rebuild costs a fraction of a
// second, like this Template's example. If YOUR method's rebuild costs more,
// raise it in proportion: a rebuild of a second or more wants about 0.8. Put
// commitOnRelease: true on the heavy parameters' descriptors, or the preview
// fires mid-drag, blocks the event loop, and the slider freezes under the
// user's finger. Reported once as "it detaches as soon as I pull it".
#define PREVIEW_DEBOUNCE_SECONDS 0.6

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/StarMeasurement.js"
#include "lib/StarDetect.js"
#include "lib/Circles.js"
#include "lib/MethodRegistry.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamSchema.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
