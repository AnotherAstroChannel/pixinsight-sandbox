/*
 ****************************************************************************
 * Star Mask -- the suite's star mask, as its own script
 *
 * StarMask.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 0.38  Shared PreviewControl: a rebuild finishing during an open drag
 *        parks its result and publishes at gesture end -- the in-flight
 *        rebuild can no longer eat the zoom box. Template 2.57.
 * 0.37  Shared PreviewControl: the wheel-zoom feedback anchors on the
 *        rendered selection (the 0.36 anchor jumped the view by the pan
 *        margin), and the gesture guard moved into rebuild() itself --
 *        no caller can steal a drag. Template 2.56.
 * 0.36  Shared PreviewControl: wheel zoom commits on wheel-quiet --
 *        notches accumulate with live scaled feedback, one rebuild 0.3 s
 *        after the last notch, mouse press commits first. Template 2.55.
 * 0.35  Shared MainDialog: the default per-control layout is callable
 *        (layoutGeneratedControls), so a section builder can compose
 *        schema rows around a hand-built one (UnsharpMaskPro 2.00's
 *        Masks section). No behaviour change here. Template 2.54.
 * 0.34  OUTPUT DEFAULTS INVERTED (his call): a fresh open creates a new
 *        image named "Starmask" instead of applying to the target -- the
 *        product is a mask, and writing it INTO the astro image is
 *        almost never the intent. Apply to target stays available as the
 *        deliberate choice. Persisted settings and saved instances are
 *        untouched; the defaults govern fresh installs and Reset.
 * 0.33  THE ICON REDRAWN TO THE SUITE CONVENTION Bill caught 0.32
 *        breaking: two-letter initials on the rounded tile, one shared
 *        typeface -- "SM", composed from the suite's OWN S and M
 *        outlines (SimpleStretch's S, UnsharpMaskPro's M), sky-blue
 *        tile. Rule 79 written from the mistake: one example is not a
 *        convention; read the whole family first.
 * 0.32  SHIPS IN THE REPOSITORY (his call: "I just want to test them by
 *        adding them in for now"): an icon (star and companions on the
 *        suite's rounded tile), #feature-icon, and the #feature-id moves
 *        from Utilities to Another Astro Channel > Star Mask so it
 *        installs beside its siblings. No behaviour change.
 * 0.31  Show star circles moves onto the Show row's right (his call:
 *        "make a little more room") -- the schema order swaps and the
 *        check box declares inlineWithPrevious, the shared mechanism
 *        other scripts' mask check boxes already use. One row saved,
 *        nothing else changes.
 * 0.30  TWO OF BILL'S CALLS. (1) "Image" leaves the Show dropdown: the
 *        untouched image is one un-tick of Show transformed away, and
 *        two doors to the same room confuse. Stale persisted or instance
 *        values coerce back to Result. (2) EXECUTE WRITES ANY DISPLAYED
 *        VIEW, suite-wide (shared Engine, Template 2.52): the guard that
 *        blocked executing a diagnostic view -- and the
 *        executableMapViews exemption this script motivated -- are gone.
 *        Viewing UnsharpMaskPro's edge map and wanting an image of it is
 *        a legitimate ask ("we do not need a restriction", his words);
 *        the run is one undoable process step, and the console notes
 *        when the output is a diagnostic view.
 * 0.29  THE SIZE SLIDERS GET THEIR OWN SECTION -- "Star size filter",
 *        below the Stars-only source (his call): inside Method
 *        parameters they read as detection settings, and the stars-only
 *        user would never find a control that works in that mode too.
 *        Placement below both sources says it applies to both. Schema
 *        group change only; behaviour identical.
 * 0.28  THE STAR SIZE RANGE (his feature, his mock approved) and the
 *        rule-56 tool tip sweep (his approved wordings). Two sliders --
 *        Smallest star / Largest star, in the same pixel radii the
 *        circle overlay draws and the fill clears (starReach1, one home,
 *        extracted from starsListForFill) -- give all stars, large only,
 *        small only, or a middle band, where the original
 *        slider-plus-invert idea could not say "medium". Defaults keep
 *        everything; MANUAL circles are exempt (placed deliberately).
 *        applySizeRange thins the cached catalogue on the way out --
 *        milliseconds, no re-detection -- in the method's prepare AND in
 *        starsRemovedResult (both modes, keys carry the range), so the
 *        fill removes exactly what the mask shows. A stars-only mask has
 *        no painted stars to thin, so an active range gates the toned
 *        mask by the derived circles (starsOnlyToneGated): kept
 *        footprints carry mask, manual adds gate in, removals drop out;
 *        at the defaults the whole-image path is untouched. Verifier:
 *        thinning monotone, manual exempt under a tight range, gated
 *        mask inside the plain mask with identical values. Tool tips:
 *        every control now says what it does and nothing else -- the
 *        armed-button paragraphs, the mechanism-laden Stars stretch and
 *        Stars image texts all cut to one sentence each.
 * 0.27  THE HEADER SAYS WHAT THE SCRIPT DOES, in Bill's approved wording:
 *        plain language, three paragraphs, every control named exactly as
 *        its label reads (the old text said "Mask" where the dropdown
 *        says Result, spoke in noise sigma, and named sibling scripts the
 *        user cannot act on from here). Rule 78 written from his call:
 *        three paragraphs is the ceiling, suite-wide. The rule-56 tool
 *        tip sweep is drafted and awaiting his sign-off for the next
 *        build.
 * 0.26  SHOW OPENS ON RESULT, always (his call, from his own console
 *        read): showWhat persisted as "Stars removed" once, and the
 *        script then spent 25 seconds AT LAUNCH building a
 *        full-resolution detection fill for a debug view nobody had
 *        asked for yet -- then threw it away when the stars image was
 *        selected. The Show dropdown is session-fresh now (persist:
 *        false, the 0.23 mechanism): every open starts on the product,
 *        the expensive debug view is a deliberate switch, and its fill
 *        still caches for pans, zooms and Execute once chosen. Saved
 *        process icons still replay a Stars-removed state deliberately.
 *        With this, opening on a fresh target costs the catalogue
 *        measure (~4 s), and the stars-only mask itself is ~1 s (his
 *        0.25 console: read 0.1, stats 0.8, prepare 0.1) -- stars-only
 *        is now the FASTER mode like for like, as he said it should be
 *        (fill 15.7 s over 7086 stars vs detection's 19.7 s over 5711).
 * 0.25  THE 34-SECOND MASK, second pass (Bill: still too long, "it just
 *        needs the mask created from the stars" -- right again). Two
 *        stars-only costs remained. (1) starsOnlyPrepLuminance still ran
 *        a midtoneTransfer FUNCTION CALL per pixel -- 6.9M of them once
 *        per build; 0.24 hoisted the mask sampling and missed the prep
 *        pass sitting one function above it. Hoisted to the same
 *        rational form. (2) The Result view recomputed the slider
 *        transfer per pixel on EVERY Execute and preview rebuild, for a
 *        result that only changes with the source or the slider. The
 *        engine now caches the TONED mask whole-frame per (source,
 *        stretch) -- built through the pure starsOnlyToneInto, which the
 *        verifier holds identical to starsOnlyMaskValue -- and Execute
 *        copies rows natively; a slider commit rebuilds it once, and its
 *        console note reports the cost. What remains after this build is
 *        the engine's shared fixed cost (full-frame read, write, undo,
 *        blocks) that detection Executes pay identically; if the console
 *        phases show stars-only at detection parity now, that shared
 *        machinery is the next -- separate -- lever. verify equality
 *        checks: prep pass and toneInto both worst-diff 0 on the real
 *        pair; all chain checks green, numbers unchanged.
 * 0.24  THE 49-SECOND MASK, run down (Bill: detection took 23 s, and the
 *        stars are ALREADY FOUND in this mode -- he is right). Two
 *        whales, both stars-only-mode-only. (1) TWELVE FULL-FRAME JS
 *        STATISTICS PASSES per build: the linearity verdict called the
 *        JS histogramStatistics three times, and computeAutoStretch
 *        three more INTERNALLY -- while engineSourceStatistics, in the
 *        same codebase, already documents that native image.median()/
 *        image.MAD() do this in milliseconds and caches the answer per
 *        view. The verdict now reads that cache; computeAutoStretch
 *        reads native first with the histogram as fallback (shared, so
 *        every script's screen stretch gains it). Rule 77 written.
 *        (2) A PER-PIXEL CLOSURE in the mask and removal sampling: a
 *        closure dispatch, two function calls and two roundings per
 *        pixel, 6.9M of each at Execute -- measured at 5x a plain loop
 *        even under a modern JIT, and PJSR is far crueller. Replaced by
 *        buildSampleMaps (row and column maps computed once per block)
 *        with tight per-branch loops: the slider transfer hoisted to
 *        its rational form (verify_starsonly_fill holds it identical to
 *        starsOnlyMaskValue -- worst diff 0), the other channels take
 *        native copies of the first, and the 1:1 unpanned case copies
 *        whole rows natively. The build's console note now carries
 *        per-phase times (read / stats / prepare), so if any frame is
 *        still slow, the console names the phase instead of leaving it
 *        to archaeology. All chain checks re-run green, numbers
 *        unchanged from 0.23.
 * 0.23  THREE BUGS, ONE FEATURE -- all four from Bill's live session.
 *        (1) THE MASK WAS NEVER STRETCHED: computeAutoStretch returns the
 *        5-row HistogramTransformation shape, and a LINKED stretch lives
 *        in row 3 (RGB/K) with rows 0-2 identity; the engine plucked
 *        H[0] -- the red channel's identity row, midtone 0.5, a no-op --
 *        so every part of 0.22's derivation was right and the result was
 *        thrown away by one index. Now stretchLinkedRow (AutoStretch,
 *        Template 2.50) returns the row by its MEANING; the console note
 *        reports the midtone used, so a wrong baseline can never hide
 *        behind a right verdict again. Measured on Test_5: midtone
 *        0.0178, neutral coverage 6.8%% against 0.36%% under identity.
 *        (2) SCREEN STRETCH DIED WITH SHOW TRANSFORMED OFF: the map
 *        guard nulled the stretch for the WHOLE preview while the Show
 *        enum said Result -- but the untransformed image under it is a
 *        picture. Per-buffer guard now (shared PreviewControl).
 *        (3) SESSION-FRESH stars-only state: starsOnlyViewId, the manual
 *        circle lists and starsStretch no longer persist to Settings --
 *        a reopened dialog silently resumed the previous session's mode
 *        with the previous mask ("I have to completely reset every
 *        single control", his report). Saved process icons still replay
 *        them; that is what icons are for.
 *        (4) STARS REMOVED IN STARS-ONLY MODE IS THE CONTENT-AWARE FILL,
 *        as he expected all along: circles derived from the TONED mask
 *        (peaks and reach walked at the slider's own transfer inverted,
 *        STARSONLY_FILL_FLOOR 0.02), manual circles applied, and the
 *        SAME full-resolution fill detection mode uses -- subtraction is
 *        gone (0.21 measured it inherently cratering: StarX pairs are
 *        not additive). The slider now sizes mask AND removal together:
 *        what the mask shows is what the fill removes (commitOnRelease,
 *        rule 62 -- the fill costs ~35 s at 10.7k circles). Removal
 *        cache keys on stars view, target, stretch and manual lists.
 *        verify_starsonly_fill.js gauges the whole chain on the real
 *        Test_5 pair: level median 0.96 sigma, p95 4.23; pit p95 2.60
 *        (subtraction red-cases at pit p95 817 -- his black holes, made
 *        a number); 14 of 3121 strong stars retain over a quarter of
 *        their contrast, all in the dense core, the known fill limit.
 * 0.22  BILL'S MTF FORMULA, literally: the target's STF midtone (the
 *        double-MTF derivation from median plus deviation to the display
 *        background) applied DIRECTLY to the stars-only flux --
 *        mask = mtf( m_target, flux ) -- no shadows clip, no prominence
 *        normalisation (which muted every star; he pushed the slider to
 *        0.95 to compensate). Measured on the Test_5 pair with its real
 *        midtone 0.0204: neutral-slider coverage 6.2%% at mask > 0.05,
 *        fifteen times the prominence baseline; the slider tones from
 *        there in both directions.
 * 0.21  STARS-ONLY REMOVAL AT ONE RESOLUTION, and the honest verdict on
 *        subtraction. Bill's checkerboard screenshot: the removal
 *        subtracted FULL-RES star values from the preview's RESAMPLED
 *        target pixels, and the resolution mismatch moired every star.
 *        The removal now computes once at full resolution when the
 *        stars-only source is prepared (starsOnlyRemoveInto in Methods,
 *        a pure function the tools can run on the real pair) and every
 *        view samples the finished result; a dimension-mismatched pair
 *        warns and shows the image. MEASURED against his own AI starless
 *        truth: plain subtraction disagrees with it by a median 5 sigma
 *        and p95 99 sigma at star sites, and 51%% of star pixels crater
 *        below it -- his black-spots report is the PAIR's non-additivity,
 *        not an arithmetic bug: StarX reconstructs background under
 *        stars; its stars image does not sum back to the target. So
 *        subtraction can never be clean here, and the NEXT build replaces
 *        it with what he expected all along: the content-aware fill,
 *        driven by circles derived from the stars-only mask -- Stars
 *        removed becomes the same fill everywhere, with the source only
 *        deciding where the stars are.
 * 0.20  THE LINEARITY VERDICT COMES FROM DISPERSION, and the stretch is
 *        PEDESTAL-ALIGNED -- Bill's Test_5 run showed the 0.19 baseline
 *        never firing: his frame is LINEAR WITH A RAISED PEDESTAL (median
 *        0.10), the median-based heuristic (linear iff median <= 0.02)
 *        called it stretched, the identity baseline was chosen, and the
 *        mask's stars came out the size of the unstretched originals --
 *        his report, verbatim. Linearity now reads the SCATTER, which a
 *        pedestal cannot fake: measured across the test set, linear MAD
 *        8.6e-5 to 2e-3 against stretched 0.043; the verdict is
 *        mad < 0.01. And the transfer is applied where the star actually
 *        sits: base = (T(bkg + flux) - T(bkg))/(1 - T(bkg)) -- the star's
 *        DISPLAYED prominence over the target's sky -- because the STF's
 *        shadow clip lives at that sky level and, applied to the stars
 *        image's near-zero pedestal, decapitated every faint star. The
 *        sky comes from the engine's backgroundEstimate where it carries
 *        one, the median otherwise. Buttons renamed at Bill's request:
 *        Add to mask / Remove from mask (armed: "press to apply").
 *        verify_starsonly_mask's baseline check now asserts the pedestal
 *        alignment: zero detectable stars decapitated, monotone
 *        throughout.
 * 0.19  THE STARS-ONLY BASELINE IS THE TARGET'S OWN SCREEN TRANSFER --
 *        Bill's spec, stated twice before it was implemented right, and
 *        his screenshots showed why: the 0.17 log ramp anchored at the
 *        STARS image's own noise floor, a millionth of full scale on a
 *        StarX separation, so the mask blew out binary-white at every
 *        slider setting. Now: a LINEAR target's linked autostretch (the
 *        same computeAutoStretch the display uses) is applied identically
 *        to the stars-only image -- its stars enter the mask looking
 *        exactly as they look on screen -- and the Stars stretch slider
 *        adjusts from that baseline (0.50 neutral, higher into the
 *        skirts, lower toward the cores). A stretched target displays
 *        as-is, so its stars image passes through unchanged. Also
 *        CONFIRMED against his suspicion: in stars-only mode the Result
 *        view writes only the stars-only mask -- detection is bypassed in
 *        prepare, nothing composites. verify_starsonly_mask gained the
 *        baseline-application check (shadows-point clipping) alongside
 *        the floor, monotonicity and endpoint properties.
 * 0.18  TWO 0.16/0.17 REGRESSIONS, both Bill's reports. (1) Placed
 *        circles were invisible while placing: batching removed the
 *        per-click refresh (by design), but the overlay only drew with
 *        Show star circles ON -- an armed mode with the box off gave no
 *        feedback at all. The manual circles now draw whenever placement
 *        is armed, adds green, removals orange, whatever the check box
 *        says; the catalogue circles stay behind it. (2) Reopening the
 *        script with a persisted stars-only selection showed an empty
 *        dropdown while the mask still used the saved view -- the engine
 *        restored the id, the UI never did, and the two disagreed until a
 *        reset. The dropdown now restores the saved selection truthfully,
 *        and a saved view that no longer exists clears the setting back
 *        to detection instead of silently acting.
 * 0.17  THE STARS-ONLY MODE GROWN UP, from Bill's two design calls. (1)
 *        THE STRETCH IS HIS: a stars-only image has no background, so no
 *        stretch can be derived from it -- the Stars stretch slider under
 *        the dropdown stretches it AND thereby sizes the mask, one knob.
 *        The transfer is a log-domain smoothstep from the image's own
 *        noise floor to a full level the slider sets (2x to ~5000x the
 *        floor): measured on the Test_5 pair, a plain midtone transfer at
 *        its strongest masked 0.4%% of a frame whose stars truly cover
 *        43%% -- star flux spans decades, rule 6b's log knee applies. At
 *        the default the masked fraction reads 0.443 against the 0.43
 *        truth. The engine caches the prepared luminance (pedestal off,
 *        noise floor clipped to exact zero), so the slider is live. (2)
 *        STARS REMOVED IS REAL in this mode, not synthesized: the
 *        separation knows what the stars are, so they are subtracted from
 *        a linear target and unscreened from a stretched one (decided by
 *        the suite's own linearity heuristic on the target); any star
 *        still visible is one the stars-only image missed -- the debug
 *        view kept working, as he required. sampleFullRes extracted as
 *        the one full-res sampling loop after the audit flagged the
 *        triplication. verify_starsonly_mask.js rewritten for the new
 *        maths: floor sealed at zero, coverage against the measured
 *        truth, monotone in stretch and luminance, endpoints pinned.
 * 0.16  PLACE EVERYTHING, THEN PROCESS ONCE -- Bill's design ("allow us to
 *        add multiple circles without it processing... deselect the add
 *        stars, and that will make the processing happen"), plus the
 *        layering bug that made every click slow in the first place: the
 *        catalogue cache keyed on the manual circle lists, so each placed
 *        circle re-ran DETECTION AND THE PSF GATE for an automatic
 *        catalogue that cannot depend on them. The cache now holds the
 *        automatic catalogue only and the manual layer is applied on the
 *        way out (milliseconds); only the full-resolution fill cache,
 *        whose result really does change with the circles, keys on them.
 *        While Add stars or Remove areas is armed, a click updates the
 *        lists and repaints the overlay -- the new circle is visible at
 *        once, the wheel and the ghost stay live -- and the single
 *        transform rebuild runs at DISARM (pressing the armed button
 *        again, or switching modes). Tooltips say so. Remove last and
 *        Clear all remain immediate.
 * 0.15  THE STARS-ONLY SECTION ACTUALLY APPEARS NOW -- Bill asked for the
 *        dropdown a second time because it had never existed on screen:
 *        the shared dialog skipped any section with no schema-generated
 *        controls, and Stars-only source is entirely hand-built (its
 *        params are internal). Fixed in the shared MainDialog (Template
 *        2.49): a section with an `extra` builder earns its place with
 *        zero generated controls. AND THE WHEEL SIZES THE CIRCLE while
 *        Add stars / Remove areas is armed -- 12% per notch, clamped to
 *        the schema's limits, ghost updating at the pointer, wheel zoom
 *        deliberately locked out in that mode (his spec, verbatim).
 * 0.14  NOTHING CHANGED, SO NOTHING REPROCESSES -- Bill's diagnosis, made
 *        architecture ("it has already processed everything... unless we
 *        add or remove areas we should not be processing every move").
 *        Two engine caches, both invalidated with the view: (1) THE
 *        FULL-RESOLUTION STARS-REMOVED RESULT -- built once per view and
 *        catalogue (console reports the one-time cost), then every pan,
 *        zoom and Show toggle just samples it, and the preview shows the
 *        true Execute result; the streaming fill remains as the fallback
 *        and the runner's path, so the tools measure the same maths.
 *        starsListForFill extracted as the ONE copy serving both paths.
 *        The fill pumps events every 64 stars so the long first build
 *        keeps the interface alive. (2) THE NOISE PROFILE, cached per
 *        view: it is a property of the pixels, not of the threshold, so
 *        a Star detection change now skips the measuring pass (about
 *        half the rebuild) and re-runs only detection and the gates.
 *        AND THE PAN IS GENEROUS AGAIN: PAN_MARGIN back to 0.75, because
 *        the caches broke the pan-vs-zoom trade (rule 72's prescription)
 *        -- a rebuild samples cached results now, so the full margin
 *        costs what it did on the Template's trivial method.
 *        Rules 66-72 written into DEVELOPMENT_RULES.md at Bill's
 *        direction, from this session's mistakes: the input-referenced
 *        gauge, verifying at the user's scale, red cases that rot, the
 *        sparse-class inversion, unjudgeable-is-not-guilty, deferred
 *        work vs gestures, and one-constant-two-experiences.
 * 0.13  TWO GESTURE FIXES from Bill's live testing. (1) Shared MainDialog:
 *        the preview debounce defers while a drag is active, so a queued
 *        refresh can no longer fire mid-zoom-box and eat the drag ("it
 *        wants to process before I can finish the drag") -- structural in
 *        every script, felt here because the rebuild is slow; Template
 *        2.48 carries the mechanism. (2) PAN_MARGIN 0.10 -> 0.30: the
 *        0.12 speed pass over-corrected -- the pan clamp is tied to the
 *        same constant, and at 0.10 a drag hit the wall almost at once
 *        (Bill: "I'm limited... I could have swore we fixed this"; the
 *        0.75 he remembers IS the generous-pan fix, and it is also the
 *        5.2x zoom cost -- one constant, one trade). 0.30 is a 2.6x
 *        budget: zoom roughly twice as fast as 0.75, pan reach usable.
 *        The real resolution is making rebuilds cheap enough to afford
 *        0.75 again -- the noise-profile cache on the roadmap.
 * 0.12  RULE 62, APPLIED -- from Bill's report ("very slow... if I zoom
 *        into an area, it seems like it would run faster, but it
 *        doesn't... double check that we're not skipping any rules"). We
 *        were: this script still carried the Template's cheap-method
 *        constants while its transform grew detection, the PSF gate and
 *        the sequential fill. PAN_MARGIN 0.75 -> 0.10: the rendered
 *        buffer was canvas x 5.2 at ANY zoomed view -- the exact
 *        mechanism of Deconvolution's measured 33-second zoom, and why
 *        zooming did not feel faster; it is ~1.4x now.
 *        PREVIEW_DEBOUNCE_SECONDS 0.25 -> 0.6 and commitOnRelease on
 *        Star detection (a change rebuilds the full-frame catalogue) and
 *        Star mask size (in Stars removed it reruns the fill), so
 *        neither fires mid-drag. Checked across the suite while here:
 *        Deconvolution (0.08/0.8) and UnsharpMaskPro (0.15/0.5) had
 *        their rule-62 pass already; the cheap scripts keep 0.75/0.25
 *        correctly; the placement ghost repaints only while armed and
 *        only where a script sets its hook, so no display change reaches
 *        the others. The remaining big lever is caching the noise
 *        profile and matched map per view so a threshold change re-runs
 *        only the band detection pass -- measured next.
 * 0.11  MANUAL CORRECTIONS AND THE STARS-ONLY SOURCE, per the layout mock
 *        Bill approved. Manual corrections: Circle radius (suite row
 *        convention), Add stars / Remove areas as armed modes, Remove last
 *        / Clear all. While armed, the shared preview draws the PLACEMENT
 *        GHOST -- the circle a click would commit, at the current radius,
 *        under the pointer, resizing live with the slider (Bill's
 *        requirement, verbatim; the same ghost shipped to BlemishRemover
 *        1.17). Left click commits the armed mode's circle; right click
 *        deletes the smallest placed circle under the cursor from either
 *        list. Circles persist in BlemishRemover's proven "x,y,r;"
 *        encoding (manualAdd / manualRemove, group internal), replay in
 *        saved instances, and are applied LAST -- after every automatic
 *        gate, by the engine and the runner identically: removals drop any
 *        detection whose centre they contain, additions paint at EXACTLY
 *        the ghost's radius (Star mask size deliberately does not inflate
 *        a manually sized circle). The catalogue cache keys on both lists.
 *        Stars-only source: a ViewList (plus Use detection to clear)
 *        writes starsOnlyViewId; when set, detection is bypassed and the
 *        mask is built from that view directly -- mono as-is, color via
 *        luminance -- through buildStarsOnlyMask: the image's own pedestal
 *        and noise (stride sample, one-sided quantile), then the suite's
 *        log-smoothstep from 1.5 sigma to 30 sigma above it, so linear
 *        and stretched stars-only images both work untouched. Cached at
 *        full resolution per view id; a missing view warns and falls back
 *        to detection. Stars removed is a detection-debug view and is a
 *        deliberate no-op in stars-only mode. verify_starsonly_mask.js
 *        asserts range, floor, coverage and monotonicity on the real
 *        Test_5 StarXTerminator separation (measured coverage 0.43; the
 *        red case is a coverage band the truth cannot meet).
 * 0.10  THE PSF-FIT GATE (psfFitFilter, applied last over the catalogue by
 *        the engine, the runner and the truth harness): fit the frame's own
 *        empirical star template at every candidate and gate on the trimmed
 *        misfit -- a star IS the point-spread function, and neither a
 *        nebula knot nor a skirt speckle can fake it. Built and calibrated
 *        against real-profile ground truth manufactured from Bill's own
 *        frames (tools/build_real_truth.py: stars destroyed, 240 REAL
 *        harvested stamps replanted, plus a fully starless variant), after
 *        his Test_5 report (micro-circles in a bright star, nebulosity
 *        removed again). THE FIXTURES EARNED THEIR KEEP TWICE: (1) the
 *        first template (mean of bright unclipped stamps) learned the
 *        KNOT class on the Test_3 fixture -- bright detections there ARE
 *        the false class -- and rejected all 240 planted stars; template
 *        stamps are now seeing-width-consistent only (within 25%% of the
 *        bright-detection median width) and median-combined, so a polluted
 *        minority cannot steer it. (2) an untrimmed fit convicted genuine
 *        bright close-pair members (truth harness's pair check went red);
 *        the fit drops its worst quarter of residual pixels -- one
 *        companion-polluted sector forgiven, a knot's everywhere-misfit
 *        not. And the REAL frame corrected the fixtures twice more: every
 *        star within a stamp radius of the frame border was silently
 *        rejected (unreadable stamp read as guilty; fixtures plant away
 *        from edges) -- unjudgeable now abstains while anti-correlated
 *        still convicts -- and one quadrant's 50-70 sigma stars fell to a
 *        floor of 0.12 because real optics vary the PSF across the field;
 *        the floor ships at 0.15 and the spatially varying template is the
 *        recorded known limit. Frozen at Q_FLOOR 0.15 + Q_NOISE 1.5
 *        sigma/A (the noise allowance recovers faint stars a fixed bar
 *        kills): Test_2 fixture keeps 223/240 real stars, falses
 *        1762 -> 343; Test_3 fixture 203/240, 1593 -> 368. On the real
 *        frames: Test_3 core falses 60 -> 41; Test_5's brightest star
 *        carries 3 catalogue entries instead of the micro-circle cluster
 *        Bill photographed; Test_2's removal gauge reads 18 strong
 *        leftovers of 993 (12 at 0.09 -- the extra are corner-PSF and
 *        border cases, the known limit above). Saturated cores exempt
 *        (clipped tops fit no template and are stars by definition).
 *        AND THE NEAR-SATURATED GIANT, Bill's Test_5 report, root-caused
 *        by probe: its core peaks at 0.9972 -- sensor-flat but never
 *        float-equal, so the exact-tie plateau machinery never engaged,
 *        the core's only representatives were 5x5 speckle maxima (his
 *        micro-circles), and the gate rightly killed those, leaving the
 *        brightest star in the frame uncatalogued. Fixes, each forced by
 *        a measurement: a SOLO certainty bar (STAR_CERTAIN_SOLO_SIGMA
 *        300 -- raw amplitude alone at 300 sigma is a star; every shape
 *        instrument degenerates on a broad near-saturated core at once,
 *        and the measured knot false class tops out far below); near-ties
 *        within 1.5 sigma count as flat ABOVE that bar only; and the
 *        plateau election defers only to earlier pixels that are
 *        themselves 5x5 maxima -- deferring to every near-tie pixel
 *        elected nobody on a dense near-tie plateau, the inversion of the
 *        exact-tie sparseness assumption. The giant now catalogues at
 *        3818 sigma with plateau-scale width; it carries ~4 owners rather
 *        than 1 (overlapping circles, one mask blob) -- recorded as
 *        polish. Final fixture state at the shipped constants: Test_2
 *        fixture 223/240 real stars kept, falses 1762 -> 436; Test_3
 *        fixture 203/240, 1593 -> 444; Test_3 real-core falses 60 -> 41.
 *        Truth harness runs the gate as the engine does; TRUTH_POISON now
 *        also disables it, because the gate alone survives the noise
 *        poison and the red case must stay red.
 * 0.09  THE TEXTURE GATE NO LONGER EATS BRIGHT STARS -- from Bill's 0.08
 *        test ("you're still leaving stars", Test_2), and the instrument
 *        lesson that found it: the survivor census had been reporting
 *        clean while his eyes found leftovers, so the gauge was replaced
 *        by an INPUT-REFERENCED scan (every strong input peak checked at
 *        the same output position -- nothing can hide from it). It read:
 *        993 strong stars in, 14 left, and the two worst (76 sigma,
 *        untouched) were NEVER DETECTED. The per-point probe convicted
 *        the narrow-amplitude texture gate twice over: (1) its bar rode
 *        the Star detection slider (1.5 x detectSigma), so RAISING the
 *        threshold deleted BRIGHT stars -- rule 48's non-monotonic
 *        control; the bar is now absolute, STAR_WALK_AMP_SIGMA 7.5, the
 *        swept-good value frozen; (2) the narrow 3 px reference rides a
 *        bright compact star's own profile -- a 77.5-sigma star with
 *        matched significance 144.6 read wAmp 7.1 against the 7.5 bar
 *        and shipped undetected (rule 59's degenerate end). The
 *        CERTAINTY BYPASS admits a candidate with matched significance
 *        over STAR_CERTAIN_MSIGMA (100) AND raw amplitude over
 *        STAR_CERTAIN_RAWSIGMA (30): both bounds required, because the
 *        broad-bump false class gathers high matched significance from
 *        sub-2-sigma raw amplitude and must stay dead. Verified: truth
 *        harness green with poison red, detection subset/monotonic green,
 *        the removal gauge on all four frames, and the Test_3 core false
 *        count checked unchanged before shipping.
 * 0.08  THE REMOVAL FOOTPRINT IS THE STAR, NOT THE PROTECTION MASK --
 *        from Bill's 0.07 test ("you can see the circles... more
 *        convoluted vs content aware"). At Star mask size 1.71 every fill
 *        circle was 1.71x the star's own extent, and on the stretched
 *        Trifid core that resurfaced MOST of the bright nebula with
 *        synthetic fill: his zoomed screenshot showed a collage of pale
 *        discs. The crop-level verification renders missed it because no
 *        wide field was rendered at his viewing scale -- recorded here so
 *        the next session renders wide, not just at defect positions.
 *        Changed: the fill's footprints AND its working mask are the
 *        painter's reach at sizeScale 1 (the star ends where its profile
 *        meets the floor); Star mask size no longer inflates the removal,
 *        and the generous mask keeps its real jobs -- the Result view and
 *        sharpening protection -- untouched. Tighter circles also pull
 *        every donor search closer (2.2-4x a smaller r), onto ground that
 *        matches, and collapse most engulfed/merged-complex cases.
 *        KNOWN, from the same test, for the next sessions: Test_3's bright
 *        reflection-nebula core draws false detections (circles on knots,
 *        Bill: "we are removing nebula and not stars") -- the shape-gate
 *        calibration owed since 0.05, plus the detect sweep, are the open
 *        detection work; the fill is not the tool that fixes those.
 * 0.07  THE FILL IS PER-CIRCLE SEAMLESS CLONING -- Bill's specification
 *        ("only within the circle, like the blemish tool"), and the probe
 *        that proved it right. The 0.06 square-walk fill was convicted by
 *        instrumenting the SHIPPED code on Test_2 (rule 39, no restatement):
 *        a 70-sigma star's blob was three-quarters cleared by a smaller
 *        neighbour's square, its own footprint walk then stopped at radius 1
 *        on the cleared ground, and 66 masked pixels of its top crescent
 *        kept 0.56 of star flux untouched -- the "needle" residues. The same
 *        star run in ISOLATION through the same code filled perfectly, which
 *        convicted the interaction, not the star. The same square mechanism
 *        pasted one donor across merged mask unions: the straight-edged tone
 *        slabs in Bill's screenshot. One cause, both his complaints.
 *        Rebuilt: BlemishRemover's donor + harmonic-membrane seamless clone
 *        (solveHarmonic ported verbatim, over-relaxed coarse-grid solve),
 *        applied per star to ITS OWN CIRCLE only -- the painter's reach,
 *        measured extent honoured. The membrane equals the surrounding image
 *        exactly at the circle's edge, so there is no seam by construction;
 *        masked pixels elsewhere in the window are interpolated across, not
 *        copied, so a neighbour's flux cannot print into the membrane.
 *        Donors validated over everything read from them (disc + ring)
 *        against the CURRENT mask; smallest-first order kept, each star
 *        clearing only its own circle -- no star can orphan a neighbour's
 *        masked pixels. The star-excluded blur, its DC machinery and the
 *        degenerate-core patches are deleted with the mechanism that needed
 *        them; fallback with no clean donor is the harmonic fill of the
 *        target (BlemishRemover's own). verify_stars_removed gained the
 *        tight-pair red case: every masked pixel must be clean after the
 *        fill, which the 0.06 code fails on the crescent it leaves
 *        (measured red at 16.7 sigma; 0.07 passes at 5.2).
 *        TWO FAULTS THE FIXTURES FORCED OUT of the first port, both
 *        traced with the shipped code before believing anything: (1) an
 *        ENGULFED star -- ring entirely inside a neighbour's blob, ringN 0
 *        -- fell back to a harmonic solve with no boundary anywhere and
 *        painted a near-black disc at 178 sigma; it now writes nothing and
 *        clears nothing, and the enclosing star, processed later because
 *        it is larger, fills that ground as part of its own circle.
 *        (2) solveHarmonic, ported verbatim, assumes the solve region is
 *        strictly interior to the window; here other stars' masked
 *        territory reaches the window edge on a dense field, and edge
 *        cells marked solved kept their zero init because the original
 *        sweep never visits them -- Test_4 grew black blobs at its 275
 *        no-donor fallbacks. Three solver amendments, each reducing to
 *        the original on interior regions (boundary-mean init, all-cells
 *        sweep with reflective edges, no-boundary returns false), plus a
 *        skip-before-clear guard so an unwritten star is never unmasked.
 *        Four-frame result, judged on renders viewed at the same defect
 *        positions as 0.06: Test_2 needles all clean, the (993,555) slab
 *        patchwork now flows, Test_4's straight-edge slabs gone -- its
 *        remaining class is soft round tone scallops where a giant found
 *        no clean donor (harmonic fallback: level-correct, textureless),
 *        recorded as a known limit for the seamless-clone-with-texture
 *        follow-up. Deleted with the old mechanism: the star-excluded
 *        blur, blurRound/blurRoundInteger and BLUR_ROUND_PASSES (the fill
 *        was their last caller); audit No findings.
 * 0.06  Bill's ordering directive, built and measured: the fill now
 *        processes stars SMALLEST FIRST, and each filled star's mask is
 *        cleared behind it (only the pixels it owned -- an overlapping
 *        neighbour's mask is not its to clear), so the giants, processed
 *        last, search a field the small stars have already left clean:
 *        donors exist for them where a busy field never offered any, and
 *        their border rings and level targets are measured on cleaned
 *        ground. Restructured stars-outer/channels-inner on the way: the
 *        old shape chose a donor PER CHANNEL, which was a latent colour
 *        seam and would have become a real one the moment masks started
 *        clearing mid-pass; one donor per star now, scored across all
 *        channels together. The sort key is the star's PAINTED size (the
 *        painter's own reach, measured extent honoured), ties broken by
 *        position for determinism. Measured on Test_2 at detect 5:
 *        interior straight-edge artifacts 453 -> 105, block invariance
 *        0 samples, all verifiers green including the rows=37 bitwise
 *        assertion. The remaining 105 are the donor-boundary class the
 *        agreed BlemishRemover-style seamless cloning will address.
 * 0.05  Bill's live test of 0.04 (two screenshots) plus the session's own
 *        measurements, one version. THE FILL: rebuilt frame-deterministic
 *        (analyse assembles owned rows, finalise paints and fills ONCE,
 *        apply copies rows out) after the rows= override showed 2.1
 *        million samples moving with the blocking -- donors were chosen
 *        per block, and a star straddling a boundary was filled twice
 *        differently: his squares. Block invariance (rows=37 bitwise) is
 *        a verifier assertion now. Replacement is HARD inside the star,
 *        feathered only at the rim (his question answered by measurement:
 *        blending inside mixes the star back; a hard edge at the boundary
 *        seams). MICRO-CIRCLES on bright cores, three causes, all fixed:
 *        the texture-gate certainty exemption waved skirt noise-bumps
 *        through (deleted -- at detect 5 the giant it served passes on
 *        its own numbers, 11.8 > 7.5); wide clipped plateaus elected
 *        several 5x5 tie-owners (one owner per plateau now, 15 px reach);
 *        and the matched and raw paths catalogued the same star twice one
 *        pixel apart (dedupeStarCatalogue keeps the brightest within
 *        3 px; Test_2 catalogue 2366 -> 1966). ROUNDNESS, his criterion
 *        ("stars are all circular unless we have a double star"): eight
 *        background-corrected drops, one direction forgiven, measured
 *        inline and judged at CATALOGUE level against the frame's own
 *        certainty-class stars -- because the fixed fraction the planted
 *        Moffats justified (0.30) killed 362 genuine stars on the real
 *        stretched frame, whose profiles are flatter than the model.
 *        DEFAULT OFF (STAR_ROUND_SELF_FRACTION 0) until calibrated on
 *        real datasets; the machinery, the sweep tables and the
 *        self-calibration ship. Four-frame proof renders produced and
 *        inspected: proof_test1_linear, proof_test1_mono,
 *        proof_test2_stretched, proof_synthetic. AGREED NEXT, from Bill:
 *        the donor fill still seams under a hard stretch -- replace the
 *        clone operation with BlemishRemover-style seamless cloning.
 * 0.04  Bill's standard applied: nothing ships until every star on every
 *        test frame is removed, judged by eye and by census. Five faults
 *        found and fixed, each measured on the real frames: (1) the texture
 *        gate rejected a 77 sigma giant whose 7 px reference rode its own
 *        skirt -- above STAR_SEEING_AMP_MIN the gate stands aside (rule
 *        58's certainty class); (2) the fitted width understates stretched
 *        profiles, so every removed star wore a ring of surviving skirt --
 *        each entry now carries its extent WALKED ON THE IMAGE (radius at
 *        two sigma over its background) and the painter stretches the
 *        profile to whichever is larger, model or measurement; (3) deep
 *        inside a giant the excluded blur's denominator is zero and the
 *        fallback returned the pixel itself -- 2920 sigma giants filled
 *        themselves with themselves (rule 59); the border-ring mean is the
 *        degenerate-core level now; (4) donor DC-matching targeted the
 *        border ring, which sits on the removed star's sub-floor skirt --
 *        under a deep stretch every fill came back as a pale disc; the
 *        target is the star-excluded blur at the centre, which contains no
 *        star flux by construction; (5) the 2 px scan standoff made every
 *        border row and column undetectable -- the strongest survivors of a
 *        full pass all sat at x=1632 or y=1272; the scan covers the whole
 *        frame with neighbourhood tests clamped at true frame edges.
 *        Default Star detection 8 -> 5, from the sweep. Final state,
 *        detect 5, all four frames: synthetic 6/6 removed; Test_1 linear
 *        2528/2538 with 10 strong residues; Test_2 stretched 2857/2863
 *        with 4; the luminance mono matches its color twin. Full-frame
 *        renders viewed before shipping.
 * 0.03  The sliders un-greyed: their enabledIf still tested the ancestor's
 *        starMask switch, which this script does not have (Bill's screenshot).
 *        DETECTION REBUILT AROUND A MATCHED FILTER -- Bill's "stretch until
 *        the points show", made quantitative: the residual convolved with a
 *        separable Gaussian at the frame's own measured FWHM, minus its own
 *        rough floor (box, min, box -- a plain mean drowned eight cluster
 *        members of 102-188 sigma), thresholded against the filtered map's
 *        own per-brightness noise measured from the fine-referenced residual
 *        through the same kernel (the map itself carries structure; the 41x
 *        lesson again). Two ways in: the matched peak, or the old raw test
 *        kept whole for close pairs the filter merges and for the frame-edge
 *        margin where its support runs out (an exclusion in the gate -- map
 *        blanking made every cliff neighbour a maximum). Measured on the
 *        manufactured stretched hybrid (builder now shipped as
 *        tools/build_hybrid_truth.py, removal sites recorded): faint
 *        planted found 55-56/60 against ~50 for the raw detector, mid 56/60,
 *        bright 119-120/120 at every threshold, clusters and edges clean,
 *        all five truth-harness properties green. Open, measured and
 *        classified rather than guessed: a visible-texture false class (46
 *        at detect 8) and a sub-visible broad-bump class that amplitude
 *        floors provably do not touch -- shape discrimination is the next
 *        measured step, informed by testing on real frames.
 * 0.02  Rule 32 obeyed after shipping in violation of it, caught by Bill:
 *        "Result" is a MAP and is no longer screen-stretched -- it sits in
 *        diagnosticViews, and stays executable through executableMapViews,
 *        the engine facility this mistake motivated. "Stars removed" rebuilt
 *        as the content-aware fill Bill specified: each star cloned from a
 *        scored donor patch whose footprint lies entirely outside every
 *        circle (checked against the painted mask itself), DC-matched at the
 *        border, blended by the mask's own profile; star-excluded normalised
 *        blur only where no clean donor exists. The old fill blurred the
 *        star into its own replacement -- pale blobs under any stretch.
 *        verify_stars_removed.js: planted stars leave 2.0 sigma, mask-zero
 *        pixels bit-identical, and the old polluted fill fails the same
 *        gauge at 11.3 sigma (the built-in red case).
 * 0.01  Cloned from the Template; the star machinery -- catalogue, PSF
 *        measurement, detection, painting -- carried VERBATIM from the
 *        tested Deconvolution copies. The method is the mask itself:
 *        Show = Image, Mask, or Stars removed (masked regions filled with
 *        local background so every star still visible is a miss), plus the
 *        star-circle overlay. Execute writes the mask. Built to iterate
 *        the mask cheaply and carry it back into UnsharpMaskPro and
 *        Deconvolution when right. Not for release.
  */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    StarMask : Another Astro Channel > Star Mask


#feature-icon  @script_icons_dir/StarMask.svg


#feature-info  The suite's star mask as its own script, for building and debugging it.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder, and it is the author's to decide:
 *
 *    ASSISTANTS -- ASK, DO NOT ASSUME. The person you are building for owns
 *    this line. Ask them what name and year they want, or whether they want no
 *    attribution at all, in which case set it to "" and the panel simply starts
 *    with the description. Do not copy a name out of an example, another
 *    script, or this file's history. Guessing here puts someone else's name on
 *    the user's work.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Star Mask"
#define VERSION     "0.38"
#define SCRIPT_ID   "StarMask"
#define KEYPREFIX   "StarMask"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan"
#define DESCRIPTION "Builds, shows and debugs the star mask the suite shares: local-background detection in noise sigma, painted from each star's own measured profile."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
// Halo sizing and luminance weights -- carried with the star machinery.
#define DETAIL_HALO_FACTOR       6
#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

// Star profile fit search space -- carried with lib/StarMeasurement.js.
#define STAR_WINDOW              8
#define STAR_BACKGROUND_RADIUS  20
#define STAR_NOISE_BINS          16
#define STAR_ALPHA_FACTOR        2.0
#define STAR_ALPHA_SAMPLE_MIN    50
#define STAR_SEEING_AMP_MIN      30
#define STAR_WALK_RADIUS         3
// The texture gate's bar, ABSOLUTE in noise sigma -- 7.5 is the swept-good
// 1.5 x the old default threshold of 5, frozen so the bar no longer rides
// the user's Star detection slider: it used to, and raising the slider
// silently deleted BRIGHT stars (rule 48's non-monotonic control; measured
// on Test_2, two 76-sigma stars gone at detect 6.58).
#define STAR_WALK_AMP_SIGMA      7.5
// A candidate this significant on the MATCHED map, with this much raw
// amplitude, is a star regardless of the texture gate -- the gate's narrow
// 3 px reference rides a bright compact star's own profile, so a 77-sigma
// star can read 7 sigma against it and die (rule 59's degenerate end,
// measured at (1342,876) on Test_2: raw 77.5, matched 144.6, wAmp 7.1).
// Both bounds must hold: matched certainty alone would readmit the
// broad-bump class whose raw amplitude is under two sigma.
#define STAR_CERTAIN_MSIGMA      100
#define STAR_CERTAIN_RAWSIGMA    30
// The SOLO certainty bar: raw amplitude alone at this level is a star, no
// second opinion needed. Exists for NEAR-saturated giants (Test_5's core
// peaks at 0.9972 -- brilliantly bright, no exact float ties, so no flatTop
// exemption), whose broad cores read near zero against BOTH the narrow
// reference and the matched filter: every shape instrument degenerates at
// once (rule 59), and only raw amplitude still speaks. Well above the
// measured knot false class (Test_3 core knots: median 64 sigma).
#define STAR_CERTAIN_SOLO_SIGMA  300
#define STAR_NOISE_SCALE         2
#define STAR_ELLIPSE_ARMS        16
#define STAR_TURN_TOLERANCE      2.0
#define STAR_SAMPLE_ROWS         400
#define STAR_NOISE_SAMPLES       50000
#define STAR_DETECT_SIGMA        20
#define STAR_FIT_MIN             8
#define STAR_FIT_MAX             150
#define STAR_CANDIDATE_SLACK     20
#define STAR_SATURATION          0.999
#define STAR_CORE_RADIUS         3
#define STAR_BLEND_FRACTION      0.30
#define STAR_PROFILE_BINS        32
#define STAR_BIN_MIN             5

#define STAR_MOMENT_SEED         2.0
#define STAR_MOMENT_ITERATIONS   12
#define STAR_MOMENT_CUTOFF       9
#define MOFFAT_BETA_MIN          1.2
#define MOFFAT_BETA_MAX          9.0
#define MOFFAT_BETA_STEP         0.02
#define MOFFAT_BETA_COARSE       0.20
#define MOFFAT_FWHM_MIN          1.2
#define MOFFAT_FWHM_MAX          12.0
#define MOFFAT_FWHM_STEP         0.01
#define MOFFAT_FWHM_COARSE       0.10

// RULE 62, applied in 0.12 after the user reported the slowness it predicts:
// the rendered buffer is the canvas plus this margin on every side, so the
// Template's 0.75 is a 5.2x PIXEL BUDGET -- right for its trivial example
// method, wrong from the moment this script's transform grew the fill and
// the gate. It is also exactly why zooming in did not feel faster: the
// buffer is canvas x 5.2 whatever the zoom. 0.10 is a 1.44x budget, in line
// with Deconvolution's 0.08 and UnsharpMaskPro's 0.15.
// Restored to the generous Template value in 0.14: the result caches broke
// the pan-vs-zoom trade (rule 72) -- a rebuild now samples cached results
// instead of re-running detection or the fill, so the 5.2x pixel budget
// buys full pan travel at trivial cost. If a future method change makes
// rebuilds expensive again, this is the constant that must move with it.
#define PAN_MARGIN               0.75

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
/*
 * The highlight stage is a pure function of one value, so it is tabulated once and
 * read back per pixel rather than recomputed. Math.pow costs a factor of nine on
 * the whole transform: 16.5 Msamples/s computing it against 147 with the table.
 *
 * ROLLOFF_DIRECT_BELOW exists because r^H has an infinite derivative at zero, so
 * interpolation is poor near black -- a uniform table over [0,1] is out by 1.0e-4
 * there, which is 1600 times float32 resolution. Below the cut the value is
 * computed exactly instead. At 0.01 the worst error over the whole range falls to
 * 1.9e-9, and almost nothing in a stretched frame sits that low, so the speed is
 * kept.
 */

#define STATISTICS_BINS          1048576

/*
 * How close the target background must be to the image median before the
 * proportional method treats the request as "leave it alone". Measured as a
 * fraction in log ratio: 0.10 means a 10 percent move already gets about 60
 * percent of the full stretch, and a 25 percent move about 90 percent.
 */

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
#define CURVE_PLOT_HEIGHT        200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
// RULE 62. 0.25 is right for a method whose rebuild costs a fraction of a
// second, like this Template's example. If YOUR method's rebuild costs more,
// raise this beyond hesitation length (Deconvolution runs at 0.8) and put
// commitOnRelease: true on the heavy parameters' descriptors, or the preview
// fires mid-drag, blocks the event loop, and the slider freezes under the
// user's finger. Reported once as "it detaches as soon as I pull it".
#define PREVIEW_DEBOUNCE_SECONDS 0.6

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/StarMeasurement.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
