/*
 ****************************************************************************
 * ZoneContrast
 *
 * ZoneContrast.js
 *
 * Adds or removes contrast within a chosen zone of brightness. The zone is
 * positioned in units of noise sigma above the measured sky level, so one setting
 * means much the same thing on different images.
 *
 * The name is deliberate: this works on a tonal zone, not a spatial one. A
 * pixel's fate depends only on how bright it is, never on what is next to it,
 * which is the opposite of what "local contrast" means in this field.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.56  THE FOCUS GRID IN A VALUE BOX, root cause found in the
 *        platform's own header (his UnsharpMaskPro screenshot: the
 *        Star detection value box filled with a blue dither).
 *        Shared Compat.js resolved FOCUS_CLICK to 0x01 -- and
 *        pjsr/FocusStyle.jsh says 0x01 is FocusStyle_Tab; Click is
 *        0x02. PJSR declares these as preprocessor defines, so the
 *        runtime probes never resolve and the fallback IS the
 *        value. Every value edit the theme made "click-only" was
 *        therefore made the dialog's FIRST TAB STOP, so the
 *        opening focus landed on one and painted its focus marks
 *        over the number -- the artifact rule 82 part 3 exists to
 *        prevent, delivered inverted. The constant now comes from
 *        the header, with FOCUS_NONE and FOCUS_WHEEL checked
 *        against it too, and verify_theme_wiring.js asserts all
 *        three so the value cannot drift back. The preview's
 *        FOCUS_CLICK|FOCUS_WHEEL becomes click+wheel as intended
 *        (it was tab+wheel), which also takes it out of the tab
 *        chain.
 * 1.55  THE DARK THEME, suite-wide (rule 82; StarMask 0.39-0.53
 *        piloted it): Theme.js is included, applyTheme skins the
 *        dialog before any control constructs, and the themePolish
 *        one-shot names this script's hand-built controls
 *        (the slope check box). The shared Target view picker is now the
 *        themed combo -- ViewList's closed face is core-painted past
 *        any style sheet (Template 2.59). Also inherited from
 *        Part-2, recorded here per rule 65: the wheel-zoom stand-in
 *        holds through the rebuild instead of snapping back to the
 *        stale view (shared PreviewControl, Template 2.58).
 *        Shared ParamControls now lists every per-row reset button
 *        on the dialog as it creates them, so the polish reaches
 *        controls no script names -- they were the one focusable
 *        class the recipe could not see.
 * 1.54  Shared PreviewControl: a rebuild finishing during an open drag
 *        parks its result and publishes at gesture end -- the in-flight
 *        rebuild can no longer eat the zoom box. Template 2.57.
 * 1.53  Shared PreviewControl: the wheel-zoom feedback anchors on the
 *        rendered selection (the 1.52 anchor jumped the view by the pan
 *        margin), and the gesture guard moved into rebuild() itself --
 *        no caller can steal a drag. Template 2.56.
 * 1.52  Shared PreviewControl: wheel zoom commits on wheel-quiet --
 *        notches accumulate with live scaled feedback, one rebuild 0.3 s
 *        after the last notch, mouse press commits first. Template 2.55.
 * 1.51  Shared MainDialog: the default per-control layout is callable
 *        (layoutGeneratedControls), so a section builder can compose
 *        schema rows around a hand-built one (UnsharpMaskPro 2.00's
 *        Masks section). No behaviour change here. Template 2.54.
 * 1.50  Shared Engine: Execute writes any displayed view -- the guard
 *        that blocked executing a diagnostic view is removed (the run is
 *        one undoable process step; the console notes a diagnostic
 *        output). Template 2.52 carries the mechanism.
 * 1.49  Shared AutoStretch: computeAutoStretch reads the native
 *        median/MAD first, keeping the JS histogram as the fallback --
 *        the derivation cost twelve full-frame JS passes on a color
 *        frame, most of a 49-second stars-only mask build (StarMask
 *        0.24). The screen stretch pays milliseconds now.
 * 1.48  Shared PreviewControl: the screen stretch always applies to the
 *        untransformed picture; only a diagnostic-map TRANSFORM skips its
 *        stretched copy. The old guard nulled the stretch for the whole
 *        preview, so a map view with Show transformed off displayed the
 *        plain image unstretched beside a ticked box (reported on
 *        StarMask 0.23; structural everywhere). Template 2.50 carries the
 *        mechanism.
 * 1.47  Shared MainDialog: the preview debounce defers while a zoom or
 *        pan drag is active, so a queued refresh can no longer eat
 *        the drag (reported on StarMask; structural everywhere).
 *        The mechanism is the Template 2.48 changelog entry.
 * 1.46  Per-parameter reset button at the end of every slider row (shared
 *        ParamControls), matching PixInsight's own convention: click
 *        restores the schema default and refreshes the preview.
 * 1.45     The screen stretch target is labelled "Background target", which is
 *          what the number is: the background level the stretch aims for.
 * 1.44     TARGET BACKGROUND FOR THE SCREEN STRETCH, beside the mode in the
 *          preview header, default 0.20 (the old fixed constant was 0.25).
 *          Shared change: the target is a parameter of computeAutoStretch,
 *          part of the stretch cache key, and a NumericEdit in the shared
 *          dialog. View STF ignores it, as that mode uses the view's own
 *          transfer function. Verified: on a real frame the midtone moves
 *          monotonically with the target and nothing else changes.
 * 1.43     Transfer curve moved above Output options; Output options and Preview
 *          dimensions start folded away
 * 1.42     Vertical pan travel matches horizontal. The render margin was sized from
 *          the selection, so wherever the selection was shorter than the control
 *          the margin went on covering that inset instead of giving travel -- 44%
 *          of a view on a 1600x900 selection, none at all on an extreme aspect.
 *          Sized from the control it is 75% in both axes at every aspect
 * 1.41     Pan clamped to the control rather than to viewPort(), which is the
 *          selection centred in the control and therefore inset wherever the
 *          selection is smaller than the control. That inset was the strip of
 *          empty canvas at the end of a drag -- 30 px on a full frame -- and it
 *          appeared in whichever axis had the slack
 * 1.40     The end of a pan showed empty canvas. The clamp measured the rendered
 *          margin in image coordinates, which exceeds what the bitmap covers by
 *          the slack between the fitted selection and the viewport -- 192 px for
 *          a 1600x900 selection in a 1024x768 preview. It now clamps to the
 *          bitmap's own extent
 * 1.39     Pan margin 0.75, so a drag from anywhere but hard against an edge runs its
 *          full length without stopping to rebuild
 * 1.38     Pan travel doubled. A drag is clamped to the rendered margin, which was a
 *          quarter of a view and now is half, so it stops to rebuild half as often
 * 1.37     Boost, Band Center and Band Width use a curved slider. At 0 to 60 sigma a
 *          value of 0.33 sat at 0.6% of the travel and one pixel nearly doubled
 *          it; it now sits at 7.4% and one step moves it by 0.008
 * 1.36     Opening with the screen stretch on showed an unstretched image beside a
 *          ticked box: setImage discarded the stretched copies and nothing
 *          rebuilt them, so only toggling the box made the two agree
 * 1.35     Temporal dead zone check now sees nested blocks. A `let` used inside an
 *          `if` above its own declaration parsed, passed the check, and threw
 * 1.34     A parameter key passed as a string was Americanised by the spelling pass,
 *          silently disabling a control. Audit now checks every key-string lookup
 * 1.33     US spelling in everything a user reads, matching PixInsight's own UI.
 *          Parameter keys keep the British spelling on purpose: renaming one
 *          would make saved instances fall back to defaults without an error
 * 1.32     Dead mask machinery removed: the ProtectionMask subsystem and the per-view
 *          mask registry, ~250 lines that could never run. The preview now honours
 *          a user's mask, which a flag that was always false had prevented
 * 1.31     Stale ctx.p example in the file header; ancestor string removed
 * 1.30     Label column measured from the schema instead of a hardcoded sample
 *          string, so a long label no longer pushes its own control out of line
 * 1.29     Audit gains a check for a parameter group with no matching section
 * 1.28     Preview size labels share one column; audit gains a check for an
 *          object used but never declared, which a clone had lost
 * 1.27     Audit gains a class-method check
 * 1.26     tools/build_update_package.py builds an update package for a repository
 * 1.25     Attribution moved to the dialog header and declared once, as a define
 * 1.24     Menu group: Another Astro Channel, out of Utilities
 * 1.23     Custom process icon: #feature-icon and icons/<name>.svg
 * 1.22     Audit reads the #feature-* directives
 * 1.21     Feature-info corrected: it still described the script as a template
 * 1.20     Dead __histogram cache invalidation removed; three new audit checks
 * 1.19     Audit gains a nineteenth check: members assigned but never called
 * 1.18     The preview publishes its state atomically, so no paint can see a
 *          half-finished rebuild
 * 1.17     The screen stretch appeared to switch itself off after a zoom
 * 1.16     The preview was one rebuild behind whenever the screen stretch
 *          was on: a stale bitmap cache
 * 1.15     A drawn bug icon for the diagnostics button, moved to the right
 * 1.14     Diagnostic maps skip the screen stretch; labelWidth restored
 * 1.13     Preview rendered before the layout had applied the new size
 * 1.12     Custom width and height sit together instead of at opposite ends
 * 1.11     The preview is rebuilt after an in-place Execute
 * 1.10     Preview size as a dropdown, custom width and height on one row
 * 1.09     Defaults 2.5 / 2.5 / 2.5
 * 1.08     Band Center and Band Width; header text and attribution
 * 1.07     Apply to target image is the default; Create new image is not
 * 1.0      First build, from the template at v2.01
 * 1.01     Histogram behind the curve, and the slope drawn as its own line
 * 1.02     Sky level from a quantile with a one-sided noise scale, both
 *          corrected for the quantile; the plot says why it has no curve
 * 1.03     Restored suppressWarnings; diagnostics read the schema instead of
 *          naming parameters; two new audit checks that would have caught both
 * 1.04     Show sigma map; the plot marks the quantile sky level, not the
 *          whole-image median, and captions it with the numbers
 * 1.05     Quantile fixed at 0.25 rather than exposed; carry screen stretch
 *          removed, with the engine and AutoStretch code it alone used
 * 1.06     Sigma map removed; header text moved to METHOD_INFO in Methods.js
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    ZoneContrast : Another Astro Channel > ZoneContrast
#feature-icon  @script_icons_dir/ZoneContrast.svg


#feature-info  Adds or removes contrast within a chosen zone of brightness.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "ZoneContrast"
#define VERSION     "1.56"
#define SCRIPT_ID   "ZoneContrast"
#define KEYPREFIX   "ZoneContrast"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Adds or removes contrast within a chosen zone of brightness."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
#define PAN_MARGIN               0.75

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
/*
 * Resolution of the band curve lookup table. The curve is the normalised
 * integral of a gain function, which has no closed form, so it is integrated
 * once in prepare() and read back per pixel.
 *
 * 65536 entries is 256 KB and matches 16-bit input exactly, so nothing is lost
 * to quantisation. Entries are interpolated on read regardless: taking the
 * nearest entry of a 1024-entry table cost a related script most of its output
 * levels before it was noticed.
 */
/*
 * Which quantile of the pixel distribution is taken as the sky level.
 *
 * Not a user control. Centre and Width can reach any absolute band whatever this
 * is -- it is a reparameterisation, not extra reach -- so exposing it only asks
 * the user to tune a number with no visible effect on the frame in front of them.
 *
 * What it does buy is that a setting means the same thing on the next image, and
 * that only holds if the noise estimate is sound. 0.25 holds to within 40% of the
 * true sigma on a field half filled with nebulosity, where the median is already
 * three times out.
 */
#define BACKGROUND_QUANTILE      0.25

#define BAND_LUT_SIZE            65536

#define STATISTICS_BINS          1048576

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
#define CURVE_PLOT_HEIGHT        200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/CurvePlot.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
