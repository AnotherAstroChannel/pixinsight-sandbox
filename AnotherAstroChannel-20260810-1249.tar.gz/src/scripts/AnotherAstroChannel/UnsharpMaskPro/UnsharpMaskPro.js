/*
 ****************************************************************************
 * PixInsight Script Template
 *
 * Template.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 2.16  THE ZOOMED PREVIEW RENDERS WHAT YOU ARE LOOKING AT (his call,
 *        and his expectation all along: "when we zoom in, we are only
 *        looking at the areas in which we zoom").
 *        The preview has always rendered the visible selection PLUS
 *        a pan margin of 0.75 on every side, so a pan reveals real
 *        data without a rebuild. That margin is 2.5x the canvas in
 *        each axis -- SIX AND A QUARTER TIMES the pixels on screen --
 *        and all of them go through the method. Measured here: 540 ms
 *        per megapixel per RL iteration, so a zoomed 1024x768 canvas
 *        deconvolves 4.9 MP to show 0.79 MP and about 84% of the
 *        wait buys pixels nobody sees. His thirty seconds.
 *        Now the first pass after an expensive rebuild renders the
 *        VISIBLE selection alone and publishes it, and the margin is
 *        filled by a second pass a moment later, once the result is
 *        already on screen -- so panning returns to instant. The
 *        split is decided by MEASUREMENT (milliseconds per visible
 *        megapixel, recorded by the control itself), not by a
 *        per-script constant: rule 81 exists because tuning the
 *        margin per script produced three pan-clamp reports. A cheap
 *        transform measures under the threshold and behaves exactly
 *        as before, in one pass.
 *        EXECUTE IS UNTOUCHED and always was: it runs the method over
 *        the target view itself, never over a preview buffer, so the
 *        output is the full image at full resolution whatever the
 *        preview happens to be showing.
 * 2.15  THE ZOOM FLASH, fixed at the right moment this time (his
 *        report, from video, twice: wheel to zoom, stop, and the
 *        preview SNAPS BACK to where it was, waits out the
 *        transform, then arrives at the zoomed view).
 *        A wheel notch only queues a selection -- the rebuild waits
 *        for wheel-quiet -- so between notch and render the painter
 *        draws the current bitmap SCALED to the queued zoom. That
 *        stand-in is the entire gesture's feedback, and it was being
 *        cancelled at the START of a transform that then runs for
 *        seconds, repainting a busy indicator over whatever the
 *        painter could draw: the old buffer, at the old zoom. The
 *        earlier fix moved that cancellation from the wheel commit
 *        to where rebuildOnce consumes the queued selection -- still
 *        the start of the transform, so the flash survived and was
 *        reported again. The painter now reads standInSelection, a
 *        field of its own that no rebuild touches, and applyPublish
 *        clears it: the one moment the render that replaces it
 *        actually exists. Dropped too when the target changes or a
 *        queued zoom is abandoned, so a stand-in cannot outlive its
 *        image. New check, shared/tools/verify_wheel_standin.js,
 *        asserts the ORDER on the shipped source and goes red on the
 *        exact form that shipped twice.
 * 2.14  NO MORE BOXES AROUND THE LABELS (his report: "all of these
 *        text boxes, whether they're blank or not, have outlines
 *        around them"). The section panel's sheet is set on the box
 *        with BARE declarations -- the form that reliably reaches a
 *        PCL control -- but Qt matches those declarations against
 *        every DESCENDANT too, so `border: 1px solid` was drawing a
 *        rounded rectangle around every label and every empty cell
 *        in the section. The fill still reaches the children, which
 *        was always right; the border is confined to a class
 *        selector, and no border is declared for the rest, since
 *        saying `border: none` there would strip the value boxes and
 *        buttons of the borders the dialog sheet gives them.
 *        US SPELLING THROUGHOUT THE INTERFACE (his report, raised
 *        before): color, not colour, and the same for neutralize,
 *        normalize, center, gray and their relatives. TEXT ONLY --
 *        `colourProtection` and `colour` are PERSISTED SETTINGS KEYS
 *        and keep their spelling, because renaming one orphans every
 *        saved setting and process icon; "centre" is also a drag
 *        state and a property name in the hue wheel.
 * 2.13  THE GLOBAL RESET BUTTON, the one button in the dialog still
 *        wearing the stock look (his screenshot). It is
 *        dialog.resetButton -- one letter from dialog.resetButtons,
 *        the per-row list declared beside it -- and a hand-written
 *        list of the dialog's buttons simply skipped it.
 *        verify_theme_wiring.js now DERIVES that list from
 *        MainDialog's own source, matching every
 *        `this.<name>Button = new ToolButton`, so a button added
 *        there and not styled fails a check instead of a
 *        screenshot; poisoned, it names the missing button.
 * 2.12  THE ICON BUTTONS GET A LIGHT FACE -- the point behind every
 *        "I can barely see the reset buttons" report, finally heard.
 *        PixInsight's icons are drawn DARK, for its light stock
 *        theme; on a dark chip a dark glyph is an EMPTY SQUARE, and
 *        outlining that square in white changes nothing, because the
 *        glyph inside is still dark on dark. His words: stop
 *        outlining things in white, make the thing itself contrast.
 *        So every icon button now has a light face and a quiet grey
 *        edge -- the per-row reset buttons, the dialog's own row
 *        (new instance, execute, cancel, real-time, documentation,
 *        diagnostics), the preview's zoom trio, and THE SECTION BAR
 *        COLLAPSE TOGGLES, which had never been styled at all: PJSR
 *        builds that button inside SectionBar, so nothing in this
 *        codebase held a reference to one until it was reached
 *        through bar.button.
 *        Also: 0.23's drop-down arrow was a CSS border-triangle,
 *        chosen to force it white. On the web that draws a triangle;
 *        Qt fills ::down-arrow as a BOX, so every dropdown showed a
 *        solid white SQUARE -- a regression on an arrow that had
 *        rendered correctly since 0.21. The platform's light arrow
 *        image is back, the compartment's divider is quiet grey
 *        again, and the verifier FAILS if the triangle form returns.
 * 2.11  WHITE ARROWS AND WHITE-EDGED ICON BUTTONS -- his call, asked
 *        for three times while grey after grey was offered instead,
 *        and approved from a drawing before this was built. The
 *        drop-down arrow is drawn as a CSS triangle in #ffffff
 *        rather than loaded from a resource, so there is no asset
 *        path left to fail; the platform's own arrow art is dark,
 *        for light panels. The per-row reset buttons and the
 *        dialog's own icon buttons -- new instance, execute,
 *        cancel, real-time, documentation, diagnostics and the
 *        preview's zoom trio -- carry a white edge on a dark chip.
 *        The chip stays dark deliberately: the glyphs are light,
 *        and a white FILL would erase them. The diagnostic build's
 *        magenta and orange are gone; its counting line is gone
 *        too, but a refusal still warns to the console, because
 *        four silent try/catch blocks are how a fix shipped four
 *        times and changed nothing.
 * 2.10  DIAGNOSTIC BUILD -- THE COLOURS ARE DELIBERATELY WRONG, and
 *        the next build takes them out again. Four attempts to shade
 *        the icon buttons have come back from PixInsight looking
 *        identical, and the pixels cannot say WHY: refused,
 *        ignored, or applied and invisible all look the same. So
 *        the reset buttons are screaming magenta, the dialog's own
 *        icon buttons orange, and themePolish now COUNTS what it
 *        did and prints it -- four silent try/catch blocks in a row
 *        is how a fix ships four times and changes nothing. Three
 *        outcomes, each pointing somewhere different: solid colour
 *        means the sheet reaches the control and only the colour
 *        was ever wrong; a thin coloured RING around the icon means
 *        the icon is drawn over the whole button and no fill can
 *        ever show (the borders have always rendered -- that is the
 *        clue); no colour at all means no style sheet reaches a PCL
 *        ToolButton and the answer is a different mechanism. The
 *        console line reports the counts independently of the
 *        pixels. Rule 82's method, which ended the confetti in one
 *        screenshot after six plausible fixes had failed.
 * 2.09  THE ICON BUTTONS, ON THE ONE FORM PROVEN TO REACH A PCL
 *        CONTROL. Three builds tried to shade the per-row reset
 *        buttons and each left them sunk into the panel in his
 *        screenshots: a dialog-level QToolButton rule, the same
 *        rule with the background shorthand, then a widget-local
 *        sheet wrapped in `*`. Meanwhile the section panels have
 *        been correctly shaded since the pilot -- by a widget-local
 *        sheet of BARE DECLARATIONS. That form is now copied
 *        exactly instead of a fourth variation being invented, and
 *        the verifier asserts the chip sheet carries no selector so
 *        the failing form cannot come back. Accepted cost: bare
 *        declarations cannot express :hover, so these buttons lose
 *        their hover lift -- a button that can be SEEN beats one
 *        that lights up once the pointer is already on it.
 *        THE DIALOG'S OWN ICON BUTTONS get the same chip (his
 *        second report: the row along the bottom "blending into
 *        the dark background") -- new instance, execute, cancel,
 *        real-time, documentation, diagnostics and the preview's
 *        three zoom buttons. The platform paints them transparent,
 *        so on this floor they were icons floating on nothing.
 * 2.08  THE RESET BUTTONS AND THE DROP-DOWN ARROW, ON THE ROUTE THAT
 *        ACTUALLY REACHES THEM (his report on the last build: "I
 *        dont see any of the changes" -- the package carried them,
 *        the controls ignored them). Both were styled by
 *        DIALOG-LEVEL class rules, QToolButton and
 *        QComboBox::drop-down, and those do not reach PCL's
 *        controls -- the same lesson this theme learned twice
 *        before, for the section panels and the popup lists, and
 *        the reason both of those are set WIDGET-LOCALLY. They are
 *        now set the same way: themePolish puts a chip sheet on
 *        every reset button it finds on the dialog, and the arrow
 *        compartment sheet on every picker AND every schema-built
 *        combo (recognised by what it can do, since the method and
 *        Show dropdowns are declared in Config and appear in no
 *        script's picker list). The lift shade goes from one step
 *        above the panel to clearly above it -- the previous value
 *        would have been near-invisible even had it applied.
 *        verify_theme_wiring.js now asserts the sheets ON THE
 *        OBJECTS, not merely that the rules exist: a rule assigned
 *        to nothing is exactly what shipped last time.
 * 2.07  THE BLUE GRID, AND TWO CONTRAST FIXES HE ASKED FOR. The grid
 *        in a value box was never our focus handling: PixInsight's
 *        OWN style sheet (rsc/qss/core-standard.qss) paints these
 *        controls with TILED 9-slice images -- QLineEdit:focus gets
 *        border-image: url(:/qss/border-focus.png) 33% repeat -- and
 *        a light-theme frame repeated across a 20-pixel box renders
 *        as a blue checkerboard over the value. border-image is a
 *        separate property from border, so setting a border never
 *        displaced it. Now turned off by name on every state the
 *        platform sets it on, for line edits, spin boxes, combos,
 *        push buttons and tool buttons; a focused edit takes a plain
 *        accent outline instead. This also retires the "hatched
 *        button" seen in the earliest theme screenshots.
 *        THE DROP-DOWN NOW LOOKS LIKE ONE (his report): the arrow's
 *        compartment is a step lighter than the field with a divider
 *        down its left edge, and the arrow is the platform's LIGHT
 *        glyph -- its own combobox arrow art is drawn dark, for light
 *        panels, and was invisible here. THE RESET BUTTONS (his
 *        report) sit on a chip above the panel with a defined edge:
 *        the platform paints QToolButton transparent, which put them
 *        into the panel. verify_theme_wiring.js asserts all of it.
 * 2.06  THE FOCUS GRID IN A VALUE BOX, root cause found in the
 *        platform's own header (his UnsharpMaskPro screenshot: the
 *        Star detection value box filled with a blue dither).
 *        Shared Compat.js resolved FOCUS_CLICK to 0x01 -- and
 *        pjsr/FocusStyle.jsh says 0x01 is FocusStyle_Tab; Click is
 *        0x02. PJSR declares these as preprocessor defines, so the
 *        runtime probes never resolve and the fallback IS the
 *        value. Every value edit the theme made "click-only" was
 *        therefore made the dialog's FIRST TAB STOP, so the
 *        opening focus landed on one and painted its focus marks
 *        over the number -- the artifact rule 82 part 3 exists to
 *        prevent, delivered inverted. The constant now comes from
 *        the header, with FOCUS_NONE and FOCUS_WHEEL checked
 *        against it too, and verify_theme_wiring.js asserts all
 *        three so the value cannot drift back. The preview's
 *        FOCUS_CLICK|FOCUS_WHEEL becomes click+wheel as intended
 *        (it was tab+wheel), which also takes it out of the tab
 *        chain.
 * 2.05  THE DARK THEME, suite-wide (rule 82; StarMask 0.39-0.53
 *        piloted it): Theme.js is included, applyTheme skins the
 *        dialog before any control constructs, and the themePolish
 *        one-shot names this script's hand-built controls
 *        (the star mask source picker and its reset button). The shared Target view picker is now the
 *        themed combo -- ViewList's closed face is core-painted past
 *        any style sheet (Template 2.59). Also inherited from
 *        Part-2, recorded here per rule 65: the wheel-zoom stand-in
 *        holds through the rebuild instead of snapping back to the
 *        stale view (shared PreviewControl, Template 2.58).
 *        Shared ParamControls now lists every per-row reset button
 *        on the dialog as it creates them, so the polish reaches
 *        controls no script names -- they were the one focusable
 *        class the recipe could not see.
 * 2.04  Shared PreviewControl: a rebuild finishing during an open drag
 *        parks its result and publishes at gesture end -- the in-flight
 *        rebuild can no longer eat the zoom box. Template 2.57.
 * 2.03  Shared PreviewControl: the wheel-zoom feedback anchors on the
 *        rendered selection (the 2.02 anchor jumped the view by the pan
 *        margin), and the gesture guard moved into rebuild() itself --
 *        the zoom box can no longer be eaten by ANY caller (his report,
 *        twice, on this script). Template 2.56.
 * 2.02  Shared PreviewControl: wheel zoom commits on wheel-quiet --
 *        notches accumulate with live scaled feedback, one rebuild 0.3 s
 *        after the last notch, mouse press commits first. Template 2.55.
 * 2.01  PAN_MARGIN 0.15 -> 0.75, THE SUITE'S PAN CONTRACT (rule 81; see
 *        Deconvolution 0.13). The margin is never the lever again.
 * 2.00  THE STAR MASK SOURCE ROW MOVES INSIDE MASKS, right after Star
 *        protection (the user's placement -- it belongs with the star
 *        cluster, not under a bar of its own). The shared dialog gained
 *        layoutGeneratedControls: the default per-control layout,
 *        callable, so the Masks builder composes the schema rows around
 *        the hand-built row instead of restating layout logic (Template
 *        2.54). Behaviour unchanged from 1.99.
 * 1.99  STAR MASK SOURCE (the user's feature, mock approved): a new
 *        section picks any open view -- a StarMask result, typically --
 *        whose pixels become the star protection mask DIRECTLY: read
 *        once at full resolution (color via luminance), cached per view
 *        and target, sampled per block, values as-is. Detection is
 *        bypassed while one is selected, so Star detection, Star mask
 *        size and Show star circles grey out (Star protection still
 *        applies -- it weights whatever mask is in use); the edge-map
 *        cleaning and every mask view read the same buffer unchanged. A
 *        missing or size-mismatched view warns and falls back to
 *        detection. Session-fresh per the StarMask precedent; saved
 *        instances replay it.
 * 1.98  Shared Engine: Execute writes any displayed view -- the guard
 *        that blocked executing a diagnostic view (the edge map, the
 *        star mask, All masks) is removed: wanting an image of the edge
 *        map is the user's own example. One undoable process step; the
 *        console notes a diagnostic output. Template 2.52 carries the
 *        mechanism.
 * 1.97  Shared AutoStretch: computeAutoStretch reads the native
 *        median/MAD first, keeping the JS histogram as the fallback --
 *        the derivation cost twelve full-frame JS passes on a color
 *        frame, most of a 49-second stars-only mask build (StarMask
 *        0.24). The screen stretch pays milliseconds now.
 * 1.96  Shared PreviewControl: the screen stretch always applies to the
 *        untransformed picture; only a diagnostic-map TRANSFORM skips its
 *        stretched copy. The old guard nulled the stretch for the whole
 *        preview, so a map view with Show transformed off displayed the
 *        plain image unstretched beside a ticked box (reported on
 *        StarMask 0.23; structural everywhere). Template 2.50 carries the
 *        mechanism.
 * 1.95  Shared MainDialog: the preview debounce defers while a zoom or
 *        pan drag is active, so a queued refresh can no longer eat
 *        the drag (reported on StarMask; structural everywhere).
 *        The mechanism is the Template 2.48 changelog entry.
 * 1.94  Per-parameter reset button at the end of every slider row (shared
 *        ParamControls), matching PixInsight's own convention: click
 *        restores the schema default and refreshes the preview.
 * 1.93  Rule 62 applied: debounce 0.25 -> 0.5 s and commitOnRelease on
 *        radius, edgePreservation, starDetect and starSize, so a mid-drag
 *        hesitation cannot fire a one-to-two-second rebuild under the
 *        finger. PAN_MARGIN 0.75 -> 0.15: the rendered buffer was a 5.2x
 *        pixel budget (measured in Deconvolution as a 33 s zoom), now under
 *        2x. Shared-library gains arriving with this build: integer sliders
 *        round after the curve (Radius read fractions before), and
 *        safeForceClose accepts windows as well as views.
 * 1.92     THE BACKGROUND MASK AUDITION USES THE PROTECTION SLIDER. With
 *          the mask Off and its Show box on, the power was forced to zero
 *          and the audition built a TWO-VALUE mask -- the user put the On
 *          and Off views side by side and they were nothing alike, when
 *          they must be identical. The audition now reads the slider;
 *          application stays gated on On (s.maskApplies), so the result is
 *          untouched while Off. Verified in the sim: On-view and Off-view
 *          bit-identical, both smooth. Note for the user's first
 *          screenshot: the On view WAS correct -- a background mask is the
 *          stretched background-removed luminance and at protection 1.0 it
 *          resembles the image itself; only the Off path was broken
 * 1.91     THE REFERENCE VIEW REFUSES CONDEMNED PIXELS. 1.90 fixed the
 *          histogram and left the view marking the dead border as
 *          background the reference never measured -- the user saw the
 *          speckle twice before the view caught up. Both branches, colour
 *          and mono. Verified on the Jupiter frame, render inspected:
 *          condemned pixels marked as background, zero. The speckle that
 *          remains at the border transition is pixels with ALL channels
 *          nonzero but faint -- the agreed pedestal limitation, honest
 * 1.90     A PIXEL IS DATA ONLY IF EVERY CHANNEL IS NONZERO. Per-channel
 *          zero exclusion was not enough: registration resampling smears
 *          counts into ONE channel along a dead border, so a border pixel
 *          reads (0, 0, 0.0004) and its nonzero channel survived into the
 *          reference -- the user watched border residue speckle the
 *          reference view. Real sky cannot put an exact zero in ANY
 *          channel, so one zero channel condemns the pixel for all three,
 *          in shared Engine.channelBackgrounds and the simulator's matched
 *          copy. Known limits, agreed with the user: a border with a
 *          nonzero pedestal is indistinguishable from dark sky per-pixel
 *          and is not attempted; a channel black-clipped over real sky is
 *          excluded too, which is arguably correct. The reference VIEW
 *          still marks dead pixels white -- it shows what is below the
 *          level, honestly.
 * 1.90     'Show ref.' sits beside 'Show mask' on the Background mask row,
 *          the user's placement, abbreviated to fit. The layout pass now
 *          chains any number of inline widgets onto the LAST REAL ROW in
 *          declared order -- attaching to the previous CONTROL broke when
 *          that control was itself inline
 * 1.89     THE BACKGROUND REFERENCE IGNORES EXACT ZEROS -- the user's
 *          original design requirement, which had made it into the shared
 *          luminance histogram ('pure black is a registration border') and
 *          the offline simulator, but NEVER into the per-channel histogram
 *          the background mask and Neutralize actually use. On the user's
 *          Jupiter frame, 6.5% dead border: the 0.05 quantile landed AT
 *          0.00000 where excluding zeros gives 0.00131, and the user
 *          watched the background jump as the setting moved through the
 *          zero mass. Fixed at histogram FILL in shared Engine
 *          channelBackgrounds (zeros and saturation both, matching its two
 *          siblings), so every consumer in every script is fixed at once.
 *          NOTE: this bug was invisible to the simulator, whose restated
 *          copy was CORRECT -- the inverse of the usual rule-39 drift.
 * 1.89     'Show reference' is back, on the Background reference row, at
 *          the user's request, as a fifth radio member.
 * 1.89     KNOWN, not chased: the simulator's own luminance estimate
 *          reports 'could not be measured' at some quantiles on 8-bit
 *          quantized data (below-quantile mass in one bin, sigma 0). Sim
 *          only; the engine uses a million-bin histogram. Next session
 * 1.88     The Sharpening tooltip carries the user's approved wording:
 *          Classic is traditional unsharp masking, for lunar/planetary and
 *          usable for deep sky; Halo-free finds the same detail keeping
 *          strong edges intact, mainly for deep sky. Outcome language, not
 *          arithmetic -- 'subtracts a blurred copy' meant nothing to the
 *          average user, which the user pointed out
 * 1.87     The header text describes the UI that exists: Classic/Halo-free
 *          and the threshold, the three masks with Show mask preview (noting
 *          it works while a mask is off), Rescale Image. The claim
 *          'equally at every brightness' became 'evenly across the
 *          brightness range', because it was measured: gain 1.00 symmetric
 *          through the midrange, easing a few percent at the extremes where
 *          the soft limit prevents clipping -- the two claims in that
 *          sentence trade against each other by design
 * 1.86     A CAPPED STAR'S FALLOFF COMPLETES INSIDE THE CAP. The paint
 *          radius is clamped to STAR_MASK_MAX_REACH, and for a saturated
 *          giant -- walk-measured alpha the blob's own extent, amplitude in
 *          thousands of sigma -- the clamp landed mid-plateau of the
 *          smoothstep: mask 0.92 at the cap, 0.00 two pixels past it. A
 *          hard-edged disc among soft stars; the user saw it in the mask
 *          view, and the seven plateau stars on his colour frame measured
 *          falls of 4-8 px against 36 for uncapped ones. The radial
 *          coordinate is now compressed by the overflow ratio, so the FLOOR
 *          crossing lands exactly at the cap: same soft shape, squeezed.
 *          After, through the shipped pipeline: the cliff stars fall in
 *          12-17 px, the uncapped are untouched, coverage stays 1.00, and
 *          the CATALOGUE IS BYTE-IDENTICAL to 1.85 -- painter only, star
 *          detection provably unaffected, which the user required.
 * 1.86     A patch anchored on this block earlier matched a DIFFERENT reach
 *          block and reported success; the standalone painter harness
 *          exposed it in one run. Anchor inside the function, not on text
 *          the file may repeat -- rule 38's structure-not-text, again
 * 1.85     RESCALE IGNORES EXACT ZEROS, and the control carries a note.
 *          An uncropped registration border is exactly 0.0 and real sky
 *          never is, so the border was setting sourceMin and the transform
 *          anchored on dead pixels. Verified: a frame given a 40 px zero
 *          border now rescales identically to the clean frame --
 *          0.07526..1.0 both ways, where the border used to read 0.00000.
 *          The BRIGHT end is deliberately untouched: a clipped core is
 *          still data the user wants just inside white, and the user has
 *          not settled how the top should behave -- recorded so it is not
 *          'fixed' casually later.
 * 1.85     'Ideal for lunar / solar surfaces' sits inline on the Rescale
 *          Image row, via a `note` descriptor field the shared layout pass
 *          renders after the control. A note is not a tooltip: it is text
 *          the user always sees, and naming the use case there was the
 *          user's own design
 * 1.84     SHOW IS INDEPENDENT OF ON. On means the mask acts on the
 *          result; Show means the user is looking at it. A mask can now be
 *          auditioned while Off -- tune Star detection watching the mask
 *          live, then switch it On once it looks right. Verified: with Star
 *          mask Off and Show checked the catalogue builds and the mask
 *          displays (12.2% covered on the mono frame); with neither, no
 *          catalogue is built and nothing is computed, so the default costs
 *          exactly what it did; the apply-side weights stay zeroed when Off,
 *          so the result is bit-identical either way; Execute stays blocked
 *          during any mask view. The catalogue trigger, the background
 *          build gate and the three show flags each took the OR; the
 *          simulator surfaced the one that was missed, by refusing to build
 *          the catalogue in the audition state
 * 1.83     The Show mask boxes sit IMMEDIATELY after their dropdown --
 *          Sizer.insert at position 2, behind the label and combo, before
 *          the row's stretch. Appended with add() they landed after the
 *          stretch, justified to the panel's right edge, which looked
 *          wrong and the user said so. A mock of the placement was shown
 *          and approved before this build -- the new working rule for
 *          layout changes, since a dialog cannot be seen outside
 *          PixInsight
 * 1.82     1.81'S LAYOUT SHIPPED WRONG AND THE USER FOUND ALL THREE FAULTS.
 *          - Every divider stacked at the TOP of the Masks group: the lines
 *            were added while the controls were being created, and the
 *            controls join the sizer in a later layout pass. Separators are
 *            rendered in that layout pass now, above the row they belong to.
 *          - The Show check boxes were blank: for a check control the LABEL
 *            field is the box text, and they declared label "" with a dead
 *            `text` field nothing reads.
 *          - They now sit ON the on/off combo's row, right-aligned, via
 *            `inlineWithPrevious` in the shared layout pass -- as specified,
 *            not on rows of their own.
 *          - The fifth check box (Show reference) was never asked for and is
 *            gone; the Background reference view has no UI entry. Four
 *            boxes: three Show mask, one Show all masks behind the line.
 *          - No line above the first block.
 * 1.81     THE UI RESTRUCTURE, as the user specified it.
 *          - 'Detail from: Blur / Edge preserving' is 'Sharpening: Classic /
 *            Halo-free', Classic the default, and the slider is 'Halo
 *            threshold'. The stored enum values were renamed with the
 *            labels, so the coercion gained `aliases`: a saved instance's
 *            old value reads as the new one. Verified in a round trip,
 *            including garbage falling to the default.
 *          - All mask controls live in their own Masks group, a divider
 *            line between the edge, star and background blocks. The
 *            `separatorBefore` field existed on two descriptors with
 *            nothing rendering it; the shared dialog now draws it.
 *          - The Show dropdown is gone. Each mask has a 'Show mask' check
 *            box (the background reference keeps 'Show reference'), and
 *            'Show all masks' closes the group. They are radio-behaved
 *            through one helper -- two maps on at once could only show one
 *            -- and they write the hidden `showWhat`, which remains the
 *            single value the engine reads, so Execute blocking and the
 *            screen-stretch suppression are untouched.
 *          - Rescale is labelled 'Rescale Image' and ends the sharpening
 *            group.
 *          Edge mask stays independent of the mode: the base decides what
 *          counts as detail, the masks decide where it lands, and Off
 *          already skips the whole computation at the build gate
 * 1.80     The screen stretch target is labelled "Background target", which is
 *          what the number is: the background level the stretch aims for.
 * 1.79     THE EDGE MAP'S CEILING COMES FROM ITS FLOOR, NOT FROM THE FRAME.
 *          The user reported the map reading as pure black and white on
 *          Test_3, and it was: the ceiling was the 90th percentile of the
 *          frame's variance ratios, and a percentile of the frame is a
 *          property of the FRAMING. On a mostly-sky frame it lands inside
 *          the noise distribution -- measured: floor 2.73, ceiling 2.80, a
 *          1.03x transition band, which is a switch. The log mapping and
 *          smoothstep downstream were already right; they had nothing to
 *          work across.
 *
 *          The ceiling is now EDGE_CEILING_SPAN (32) times the noise floor,
 *          which means the same thing on every frame however it is framed.
 *          On Test_3 the console reads flat below 2.8x, full at 89.9x, and
 *          the shipped map went from 0.1% graded pixels to 1.3%: filaments
 *          with soft edges, faint structure visible, the core still full
 *          because it genuinely sits further above the noise than the span.
 *          The render was inspected before shipping. Also measured: star
 *          reach inflated the old percentile 6.0x on the mono frame; a
 *          floor-derived ceiling makes that moot, since the floor is a sky
 *          median that stars cannot move
 * 1.78     A SATURATED CORE IS EXEMPT FROM THE NARROW-AMPLITUDE TEST, and
 *          its walk falls back to the wide reference.
 *
 *          Found on the user's colour frame: a 4813 sigma clipped star with
 *          no detection at all. Its core is a noisy plateau of exact 1.0
 *          ties, and for a saturated star the 7 px surroundings are ALSO
 *          saturated -- so the narrow amplitude added in 1.76 is zero
 *          however bright the star, and the test rejected it. A flat top
 *          means exact float ties, which noise never produces, so the
 *          exemption cannot admit texture. The narrow walk reference sits AT
 *          the peak for such a star, so the walk uses the wide one, which is
 *          what handled saturated stars correctly before 1.76.
 *
 *          Verified: the star is detected (amp 4843, plateau flagged, mask
 *          1.00 across the core) and the hybrid ground truth regression is
 *          bit-identical (340 kept, 78 false, 269 of 373 found), since
 *          planted fixture stars are never clipped.
 * 1.78     Looked at and deliberately NOT changed: a bright star drawing
 *          several overlapping circles. Those are independent maxima of one
 *          star; each is real, their union covers it (mask 1.00), and
 *          merging them risks under-covering an asymmetric core for a
 *          purely cosmetic gain
 * 1.77     TARGET BACKGROUND FOR THE SCREEN STRETCH, beside the mode in the
 *          preview header, default 0.20 (the old fixed constant was 0.25).
 *          Shared change: the target is a parameter of computeAutoStretch,
 *          part of the stretch cache key, and a NumericEdit in the shared
 *          dialog. View STF ignores it, as that mode uses the view's own
 *          transfer function. Verified: on a real frame the midtone moves
 *          monotonically with the target and nothing else changes.
 * 1.76     STARS ON NEBULOSITY ARE FOUND: the walk level is referenced to a
 *          NARROW background, the amplitude to the wide one.
 *
 *          The 20 px background undershoots a narrow nebula ridge, so a
 *          level of amp/8 above it can sit below the ridge top -- the walk
 *          then runs along the ridge, the star measures wide (8.9 px against
 *          2.4 for clean stars), and the seeing cap drops it. That was the
 *          user's screenshot: bright stars on the target with black halos
 *          and no circle.
 *
 *          A 7 px reference (STAR_WALK_RADIUS = 3, box-min-box) follows the
 *          ridge, so a level above it stops the walk where the star ends.
 *          Narrowing the 20 px background itself was tried in 1.71 and made
 *          coverage worse; the split uses each at what it is for -- wide for
 *          HOW BRIGHT, narrow for WHERE THE STAR ENDS.
 *
 *          Alone, that let nebula knots measure compact too (false 88 ->
 *          492). The discriminator: a star rises far above its 7 px
 *          surroundings, a texture bump IS its 7 px surroundings, so the
 *          narrow amplitude must also clear STAR_WALK_AMP_FRACTION times the
 *          detection threshold. Swept against ground truth built from the
 *          user's own frame (its real nebulosity, stars removed by a 9x9
 *          median, 373 known stars planted back), at the default threshold:
 *
 *             fraction   false   found of 373   on nebula of 200
 *               0.5       294        299             134
 *               1.0       125        288             128
 *               1.5        78        269             121
 *               2.0        63        245             112
 *
 *          1.5 beats 1.75 on every axis at once: false 88 -> 78, found
 *          248 -> 269, and on the nebulosity 85 -> 121 of 200. The six
 *          bright stars on the core that 1.74 never detected at all --
 *          (841,674) and its neighbours, the user's arrows -- are all
 *          detected now, verified individually.
 *
 *          What remains missed on structure is measurably structural: the
 *          star's amplitude in LOCAL sigma is below the threshold (photon
 *          noise on the bright core is real), or nebula texture beats it as
 *          the local maximum. Lowering Star detection reaches the former;
 *          nothing reaches the latter without redesigning the maximum test
 * 1.75     THE SEEING IS MEASURED FROM BRIGHT DETECTIONS ONLY, and the floor
 *          on Star detection is back at 3.
 *
 *          1.74's cap took its median over the whole catalogue, and that
 *          made the control NON-MONOTONIC: at a low threshold the catalogue
 *          floods with compact noise, the 'seeing' becomes the noise width,
 *          and the cap rejects every real star. Measured with ground truth
 *          built from the user's own frame -- its real nebulosity, stars
 *          removed by a 9x9 median, 373 known stars planted back:
 *
 *             threshold    found of 373 (1.74)    found (1.75)
 *                 3                  3                 246
 *                 3.5               17                 246
 *                 5                275                 243
 *                 8                265                 231
 *
 *          Detections above STAR_SEEING_AMP_MIN (30 sigma) are almost all
 *          real at any threshold, so a median over them cannot be poisoned.
 *          verify_star_detection_truth.js now applies the cap and asserts
 *          monotonicity; TRUTH_POISON=1 demonstrates the red case.
 *
 *          STAR_ALPHA_FACTOR 1.6 -> 2.0, measured: blended bright stars
 *          measure up to 2x their true width, and 1.6 dropped four planted
 *          stars above 100 sigma. At 2.0 every bright star survives; the
 *          cost at the default is 88 false against 2, for 17 more real
 *          stars -- and a missed bright star is a black halo, which is the
 *          worse error.
 * 1.75     KNOWN REMAINING: stars sitting ON structure still measure wide --
 *          the width walk escapes along the ridge (missed stars measure
 *          8.9 px where detected ones measure 2.4). At the default, 85 of
 *          200 stars planted on the user's nebulosity are found. A 7 px
 *          walk reference fixes the measurement (2.0 px) and is the next
 *          thing to try, carefully: narrowing the 20 px background globally
 *          was measured worse in 1.71
 * 1.74     THE WIDTH CAP COMES FROM THE FRAME'S OWN SEEING, and the number
 *          was measured on the user's own data with ground truth.
 *
 *          1.73's synthetic frame used smoothed noise for nebulosity, which
 *          is far smoother than the real thing, so it did not reproduce the
 *          fault at all -- a fixture that does not span what the fault
 *          depends on, which rule 50 was written about that same day.
 *
 *          Ground truth from the REAL frame instead: a 9x9 median destroys
 *          compact sources and keeps extended structure, so what remains is
 *          that frame's own nebulosity with NO stars in it, and every
 *          detection on it is false by construction. At detection 8 it gave
 *          235 false detections over 1.8 Mpx, and raising the threshold did
 *          not fix it -- 80 survived even at 20.
 *
 *          What separates them is WIDTH, and by a wide margin:
 *
 *                                    median alpha
 *             the real frame             2.54      85% between 2.0 and 3.0
 *             the same frame, starless   5.61
 *
 *          A star's core width is the seeing, and the seeing is the same for
 *          every star on a frame, so stars pile up at one width. The cap was
 *          8, which is three times the seeing here and let nebulosity through.
 *          False detections on that starless frame by cap: 8 -> 235,
 *          6 -> 162, 5 -> 66, 4 -> 28.
 *
 *          A FIXED cap cannot do this. It is a width in pixels, so a value
 *          tight enough here would reject every star on a frame with worse
 *          seeing. STAR_ALPHA_FACTOR = 1.6 times the frame's OWN median is
 *          the same decision expressed so it travels: on this frame it
 *          computes 4.06 px and drops 135 detections, and it would compute
 *          something wider on a softer frame without being told.
 *
 *          Cost, on the labelled synthetic: 222 planted stars found of 260 at
 *          cap 8, 211 at cap 4. Eleven stars for 207 false detections.
 *          Saturated cores are exempt, as they always were.
 * 1.74     ALSO: run_method_on_frame.js restated the catalogue as well as the
 *          noise estimator, so the first version of this fix appeared to do
 *          nothing when measured there. That is twice in one session that a
 *          restated copy in the simulator hid the answer. It is matched by
 *          hand for now and says so; making it evaluate the shipped hooks is
 *          the real fix and is not done
 * 1.73     STAR DETECTION DEFAULT 6.0 -> 8.0, MINIMUM 3.0 -> 5.0, and the
 *          number comes from ground truth for the first time.
 *
 *          Every earlier measurement of this detector was made on a real
 *          frame, where a false detection cannot be told from a faint star.
 *          So the question 'is it finding stars or nebulosity' was never
 *          actually answered -- and it was answered wrongly, most expensively
 *          by lowering the threshold to recover stars on a nebula, which
 *          produced a frame covered in circles over nebulosity.
 *
 *          On a synthetic frame with structured nebulosity and 260 planted
 *          stars, where a detection more than three pixels from a planted
 *          star is false by construction:
 *
 *             threshold   detections   false   found of 260
 *                  5          705       469        239
 *                  6          381       153        232
 *                  8          219         2        222
 *                 10          212         0        217
 *                 12          205         0        210
 *
 *          At 3.5 -- what the user had reached for -- 88% of detections are
 *          not stars, and a star-free frame of the same nebulosity yields
 *          2741 detections. At 8 it yields 3, and every star above 100 sigma
 *          is still found.
 *
 *          The minimum is 5 because below it the majority of detections are
 *          measurably not stars.
 * 1.73     tools/verify_star_detection_truth.js is that frame, kept. It
 *          asserts that most detections are stars, that every star above 100
 *          sigma is found, that raising the threshold reduces false
 *          detections, and that a star-free frame yields almost nothing.
 *          Verified against the old default: it reports 88% false and 2741
 *          detections on star-free nebulosity
 * 1.73     ALSO FIXED: run_method_on_frame.js had RESTATED the noise
 *          estimator instead of using the engine's. The engine measures the
 *          residual against a two pixel box, which keeps pixel noise and
 *          discards structure; the simulator measured against the twenty
 *          pixel background and counted nebula filaments as noise. Same
 *          frame: the engine's profile rises 5.0x from sky to core, the
 *          simulator's rose 41x. Every measurement taken there about
 *          detection on a bright object was about code that does not ship.
 *          Rule 39 says load what ships rather than restating it, and it was
 *          written before this happened again
 * 1.73     Measured and REJECTED: raising the width cap to recover stars on
 *          nebulosity. 8 -> 12 gains 11 real stars and 89 false ones; 8 -> 16
 *          gains 17 and 373. The cap stays at 8
 * 1.72     THE ELLIPSE IS GONE. The mask is a circle, sized by the measured
 *          radius and STAR MASK SIZE, and nothing computes a shape any more.
 *
 *          It was fitted across four versions and never earned its place.
 *          The fit is unstable on real stars -- neighbouring stars come out
 *          at different angles, so correcting one breaks the next, which is
 *          exactly how it behaved in use. And the coverage it bought was
 *          small: 228 of 400 escapes down to 203, against 104 from simply
 *          making the circle bigger.
 *
 *          A shape that changes its mind is worse than no shape. Circular,
 *          with the multiplier:
 *
 *             size   long axis escapes   sky masked
 *             1.00       239 of 400          3.1%
 *             1.25       142 of 400          6.1%
 *             1.50       104 of 400         10.0%
 *             2.00        72 of 400         19.4%
 *             2.50        60 of 400         30.1%
 *
 *          STAR_MASK_CIRCULAR, STAR_MAX_ELONGATION and STAR_SHAPE_MIN_AXIS
 *          are removed with it. ellipseAtLevel stays, used only for its
 *          geometric mean: sixteen arms interpolated to sub-pixel is a better
 *          radius than the four-arm whole-pixel average it replaced, and that
 *          part was worth keeping
 * 1.71     STAR MASK SIZE, a plain multiplier, because the computed size does
 *          not cover the star and four attempts at computing it better did
 *          not change that.
 *
 *          The reach is a Moffat solved from the core width. Measured on 476
 *          stars it comes to 74% of how far the star actually extends along
 *          its LONG axis:
 *
 *             amplitude    modelled   mean extent   LONG extent
 *             30 to 60        4.1         3.9           6.0
 *             150 to 500      6.0         5.4           9.0
 *             over 500       10.5         9.8          14.0
 *
 *          What the multiplier buys, on 400 bright stars:
 *
 *             size   long axis escapes   sky masked
 *             1.0        203 of 400          3.0%
 *             1.5         86 of 400          9.5%
 *             2.0         61 of 400         18.7%
 *             2.5         56 of 400         29.3%
 *
 *          1.50 is the default: it removes most of the escapes for a third
 *          of the sky cost of 2.0, and past 2.0 the return collapses. The
 *          right value depends on the optics, which is why it is a control
 *          rather than a constant.
 * 1.71     ALSO: the shape is measured at the FLOOR, not the core. Elongation
 *          grows outward -- on the same 476 stars it is 1.71 at the core and
 *          2.26 at the floor, and the short axis there is 2.8 pixels rather
 *          than 1, so the fit has something to work with. Measuring it at the
 *          core and applying it at the wing was the whole trouble with the
 *          shape work
 * 1.71     The multiplier first scaled `reach`, which bounds the paint loop,
 *          and produced a BIT-IDENTICAL mask: the mask falls to zero where
 *          the PROFILE meets the floor, so the extra iterations wrote
 *          nothing. It scales alpha now. A control that did nothing would
 *          have shipped had the sweep not been measured
 * 1.70     THE ELONGATION WAS BEING FITTED TO QUANTISATION NOISE, which is
 *          how a long thin ellipse ended up drawn across a dust lane with no
 *          star in it. Two causes, one cure each.
 *
 *          THE ARMS WERE WHOLE PIXELS. The walk returned the integer step at
 *          which the profile first fell below the level, and measured on a
 *          real frame the SHORT arm is one pixel for every detection under
 *          twenty sigma. A shape fitted to a one-pixel axis is noise.
 *          Interpolating the crossing between the last sample above and the
 *          first below costs one subtraction. Against synthetic ellipses of
 *          known axes the worst axis error went 14% -> 5% and the worst
 *          angle error 2.5 -> 1.6 degrees.
 *
 *          AND ELONGATION IS ONLY BELIEVED WHERE THERE IS ENOUGH STAR. Below
 *          a floor on the short axis the object is treated as round, which is
 *          a two-pixel object is. Measured median elongation by amplitude,
 *          before and after:
 *
 *                             before   after      90th after
 *             4 to 6 sigma      1.59    1.00          1.00
 *             6 to 10           1.46    1.00          1.48
 *             10 to 20          1.28    1.26          2.57
 *             over 50           1.16    1.19          1.35
 *
 * 1.70     What this does NOT fix: on 400 bright stars, the count whose long
 *          axis still escapes the mask is 154, against 170 for the plain
 *          circle and 109 for the version whose elongation was noise. The
 *          noisy version covered more BY BEING WRONG -- it inflated masks at
 *          random and some of that landed usefully. Sky masked 3.4% -> 2.9%,
 *          so this is a smaller and more accurate mask.
 *
 *          The remaining escapes are not a shape problem. The mask's REACH
 *          comes from a Moffat solved from the core width, and real stars
 *          have wings broader than that model predicts. That is the next
 *          thing to measure, and widening the mask to hide it would cost the
 *          nebulosity this mask exists to protect
 * 1.69     SHOW STAR CIRCLES NOW DRAWS THE ELLIPSE THE MASK ACTUALLY IS.
 *          1.68 made the mask elliptical and left the overlay circular, so
 *          the one tool for answering 'is this star covered' could not
 *          answer it. Same area convention as the painter, so a round star
 *          draws the circle it always did.
 * 1.69     A CIRCLE ON THE LONG AXIS was tried instead of the ellipse and
 *          measured worse. The reasoning for it is sound -- a circle is
 *          immune to any error in the fitted angle, and only the longest arm
 *          has to be right -- but on 400 stars of a real frame, the count
 *          whose long axis still escapes the mask:
 *
 *             circle on the mean       170 of 400   sky masked 3.4%
 *             ellipse                  109 of 400   sky masked 4.8%
 *             circle on the long axis  132 of 400   sky masked 5.0%
 *
 *          The ellipse covers more AND costs less sky, so the simpler shape
 *          loses on both counts. Superseded in 1.72, which removes the ellipse
 *          fallback if the angle ever proves unreliable on a frame.
 *
 *          109 of 400 still escape, so this is not finished. The fit
 *          under-calls elongation -- 1.29 median against 1.50 measured
 *          independently -- and that is where the remaining coverage is
 * 1.68     THE STAR MASK IS AN ELLIPSE, because stars are not circles. The
 *          width came from radiusAtLevel, which walks four directions and
 *          returns the MEAN of the arms -- one number, and therefore a
 *          circle. Measured on a mono linear frame, 575 stars walked in
 *          eight directions:
 *
 *             elongation, longest arm over shortest
 *                median 1.50   90th 2.47   99th 5.17
 *             how far the MEAN falls short of the long axis
 *                median 1.25x  90th 1.51x
 *
 *          So the ENDS of half the stars sat outside the mask. They were
 *          sharpened while the middle was not, and subtracting a blur there
 *          digs the dark ring -- the black halo around elongated stars.
 *
 *          ellipseAtLevel walks STAR_ELLIPSE_ARMS directions and fits an
 *          ellipse: 1/r^2 = A cos^2 + 2B cos sin + C sin^2 is linear in
 *          A, B, C, so sixteen arms give an ordinary least squares, a 3x3
 *          solve per star at catalogue time. Two details it needed:
 *
 *          WEIGHTED BY r^4. The equation is in 1/r^2, so an unweighted fit
 *          weights the short axis by the square of the elongation -- nine
 *          times on a 3:1 star. Measured against a synthetic 12x4 ellipse it
 *          put the major axis at 20.7, extrapolating past every arm it had.
 *
 *          CLAMPED TO THE MEASURED RANGE. A fit may extrapolate; a mask must
 *          not claim a star reaches further than was walked to.
 *
 *          With both, against synthetic ellipses of known axes: worst axis
 *          error 14%, worst angle error 2.5 degrees, and every error an
 *          over-estimate, which is the safe direction for a mask.
 *
 *          The painter rotates into the star's frame and preserves AREA --
 *          the ellipse extends by sqrt(ratio) along the major axis and
 *          shrinks by the same across it -- so a round star has ratio 1 and
 *          gets the circle it got before, to the bit. Measured on 236
 *          elongated stars, mask reach divided by star extent:
 *
 *                          long axis   short axis   balance
 *             circle           1.00       1.25       0.80
 *             ellipse          1.05       1.20       0.88
 *
 *          An improvement, not a cure: it recovers about 40% of the
 *          imbalance, and the catalogue's median elongation reads 1.29
 *          against 1.50 measured independently, so the fit still under-calls
 *          it. Sky masked 3.4% -> 4.8%
 * 1.67     STAR DETECTION THRESHOLDED AGAINST ONE NOISE FIGURE, and on a
 *          bright target that put large star circles on the target itself.
 *          Photon noise scales with signal. Measured on a mono linear frame
 *          of a bright nebula, the residual scatter against local
 *          background:
 *
 *             0.0755 (sky)   5.78e-05     1.0x
 *             0.0766         1.71e-04     3.0x
 *             0.0787         4.73e-04     8.2x
 *             0.0873 (core)  2.35e-03    40.7x
 *
 *          Everything was compared against the sky's figure, so an ordinary
 *          ripple on that core read as 160 sigma when against its own noise
 *          it was about 6. It then cleared the width cap, because 1.66
 *          exempts anything above STAR_WIDE_AMP_SIGMA -- which is only sound
 *          while the amplitude is honest.
 *
 *          Sixteen equal-count brightness bins now, the residual scatter in
 *          each, interpolated between -- the same shape the edge map's noise
 *          profile already used. Measured on that frame:
 *
 *                                    before   after
 *             detections on the core     60       8
 *             wider than the cap         93       0
 *             median width there       21.8     2.5
 *
 *          and the eight that remain are compact, which is what a star on a
 *          nebula looks like. No regression on the colour frame: maxima above
 *          20 sigma left uncovered 21 -> 23 of 876
 * 1.66     BRIGHT STARS ON NEBULOSITY WERE BEING MEASURED AS THE NEBULA.
 *          The width was walked outward to a fixed level above the local
 *          background -- but where a star sits ON nebulosity the surrounding
 *          nebula is also above that level, so the walk did not stop at the
 *          star's edge. Traced on a 464 sigma star at (964,549): outer radius
 *          21.3 pixels, alpha 10.21 against a cap of 8, rejected as too wide.
 *          It is not wide; it is bright and sitting on something bright.
 *
 *          The level is a fraction of the STAR'S OWN amplitude now, which is
 *          above its surroundings by construction. Eight, because for a
 *          Moffat with beta 3 the radius at amp/8 is exactly alpha
 * 1.66     AND THE WIDTH CAP DOES NOT APPLY TO A VERY BRIGHT SOURCE. The cap
 *          rejects nebula texture, which is broad AND FAINT. Of 555 maxima it
 *          rejected on the reference frame:
 *
 *             under 50 sigma   529   median alpha 20.5   texture
 *             50 to 200          8   median alpha  9.1
 *             over 1000         18   median alpha 11.1   stars, wrongly lost
 *
 *          The populations separate by BRIGHTNESS, not width: the faint ones
 *          sit at twice the cap, the bright ones just over it. Saturated
 *          cores were already exempt through flatTop, but a very bright star
 *          need not be clipped -- the traced one was not.
 *
 *          Together: maxima above 20 sigma that the mask leaves uncovered go
 *          from 37 to 21 of 876, sky coverage stays at 0.6%, nebula 20.6% ->
 *          24.7%
 * 1.65     STAR DETECTION WAS NOT MONOTONIC, so dragging the slider made
 *          stars appear as well as vanish. The width was measured AT the
 *          detection level and the profile solved back from it, so a star's
 *          computed width moved with the slider and stars crossed the width
 *          cap in BOTH directions. Measured on the reference frame, raising
 *          the threshold from 3 to 4 lost 880 detections and GAINED 240; the
 *          gains at each step ran 240, 137, 77, 36, 17, 5.
 *
 *          A star's width is a property of the star, so it is measured at a
 *          fixed level now -- STAR_WIDTH_SIGMA, three sigma, the lowest the
 *          control allows, so anything that passes detection can be measured.
 *          The threshold decides inclusion and nothing else. Gains after the
 *          change: 0 at every step
 * 1.65     tools/verify_star_detection.js asserts it on a synthetic frame
 *          where the truth is planted: raising never adds, the strictest
 *          catalogue is a subset of the loosest, a bright narrow star is
 *          found at every threshold, and the count only falls.
 *
 *          Its first version passed on the OLD code, which made it worthless.
 *          Every planted star had the same tidy width, so none sat near the
 *          cap the fault moves them across. Planted with widths from 2 to 9
 *          it fails on the old code -- 3 appeared going from 3 to 4 -- which
 *          is the difference between a test and a decoration
 * 1.64     STAR DETECTION is a control, not a constant. How far above its
 *          local background something must rise to count as a star, in units
 *          of the noise, from 3 to 30 with 6 the default. Measured on the
 *          reference frame, the catalogue it produces:
 *
 *             3 -> 3042 stars      10 -> 1260
 *             4 -> 2402            20 ->  786
 *             6 -> 1778
 *
 *          It pairs with Show star circles: move this with the circles on and
 *          the ones that appear and disappear are what the setting is
 *          deciding about, which is a question no number answers
 * 1.63     THE EDGE-PRESERVING BASE PRODUCED A BLACK PREVIEW ON ANY
 *          FRACTIONAL RADIUS, which a slider produces and a typed whole
 *          number does not. guidedBase passed the radius straight to
 *          blurFilter, and boxFilter indexes its sliding window with
 *          x + r + 1 -- a fractional index reads undefined, and
 *          `sum += undefined` is NaN. Measured at radius 3.7: all 6236427
 *          samples non-finite. Every blur inside the base is fractional now.
 *
 *          Every test written for 1.62 used whole numbers, which is exactly
 *          why it shipped. tools/verify_edge_preserving_base.js sweeps eleven
 *          radii including 1.05, 1.999, 4.25 and 7.13, and asserts the base
 *          is finite, continuous under a hundredth-pixel change, follows a
 *          hard edge, and still smooths flat ground. Verified to fail on a
 *          copy with the integer blur put back: radius 1.05, 39600 non-finite
 *          samples
 * 1.63     The base takes the SHARPENING radius rather than the edge window.
 *          It is the base the detail is measured against, so it has to be the
 *          scale the blur base would have used
 * 1.62     AN EDGE-PRESERVING BASE, and it is the first change here that
 *          alters what the script IS rather than where its masks act.
 *
 *          The detail layer is the image minus a base. A blurred base crosses
 *          edges, so subtracting it digs a trench on the dark side of every
 *          one -- the halo. That is not a mask problem, which is why a great
 *          deal of mask work never touched it. A base that declines to cross
 *          edges does not dig one. Measured through the shipped code at
 *          radius 5, amount 2, over 4486 stars, halo depth in sigma:
 *
 *                          blurred   edge preserving
 *             faint          -36.5        -6.3
 *             mid            -84.3        -3.0
 *             bright        -186.3        -1.3
 *             saturated    -1113.4        -0.0
 *
 *          `Detail from` chooses between them and `Edge preservation` sets
 *          how strong a feature has to be before the base refuses to cross
 *          it, in units of the noise. Measured trade, faint-star halo against
 *          detail gain: 3 -> -3.2 and 1.30x, 10 -> -6.6 and 1.66x, 30 ->
 *          -9.9 and 2.01x, 100 -> -13.3 and 2.35x, a plain blur -36.4 and
 *          2.73x. The default is 10
 * 1.62     SHOW STAR CIRCLES: a circle over the image at every detection, at
 *          the radius the mask will actually cover, red at 12 sigma and above
 *          and blue below. It exists because no number answers the question
 *          that matters -- is this circling a star or a piece of noise -- and
 *          a band average cannot either: 'stars covered 58.5%' read the same
 *          before and after a change that dropped every saturated star and
 *          picked up as many faint ones. Display only, through the same
 *          PreviewOverlay hook CLAHE uses for its tile grid
 * 1.61     THE NOISE ESTIMATOR ADDED IN 1.60 WAS 41% LOW, WHICH MANUFACTURED
 *          STARS. It took the MAD of the lower half of the residual about
 *          that half's own median -- but the lower half is a TRUNCATED
 *          distribution and its MAD is not sigma. Measured on standard
 *          normal data it reads 0.592 against a truth of 1.000. A threshold
 *          41% low fires on noise, and the decisive test says how much: run
 *          on synthetic frames containing NO STARS AT ALL,
 *
 *                                          before      after
 *             pure uncorrelated noise    569/Mpx      0/Mpx
 *             correlated noise             5/Mpx      0/Mpx
 *
 *          The estimator is one-sided now: the distance from the median down
 *          to the quarter point is 0.6744897 sigma for a normal, and stars
 *          only touch the UPPER tail, so it is unbiased AND robust -- 1.000
 *          on clean data, 1.021 with a heavy bright tail. On the reference
 *          frame it now measures 1.24e-4 where the synthetic truth is
 *          1.23e-4. Detections on the real frame: 3350 -> 2394 -> 1778
 * 1.61     The false-positive rate is now measured by running the detector
 *          on star-free synthetic frames, which is the only test that can
 *          answer the question. Statistics on the real frame could not: two
 *          plausible discriminators were tried and measured, brightness-
 *          dependent noise and local scatter, and both moved the answer by
 *          less than a factor of 1.6 while the real error was 1.7
 * 1.60     THE BACKGROUND REFERENCE CONTROL DID ALMOST NOTHING, and it was
 *          the same fault as 1.56 in the other direction: the VIEW and the
 *          MASK were reading different numbers. backgroundEstimate returns
 *          the raw quantile AND that quantile corrected back to where the
 *          sky sits. The view thresholds on the raw level; the mask clipped
 *          at the corrected one, and the correction cancels the control:
 *
 *               q     raw quantile   corrected sky   clipped
 *             0.010     0.097323       0.097851       22.5%
 *             0.150     0.097729       0.098120       37.5%
 *             0.500     0.098460       0.098460       50.0%
 *
 *          At the lowest setting the user expects to clip one percent and
 *          was clipping twenty-two. The black point is the RAW quantile now,
 *          and the clipped share equals the control: 1.0% at 0.01, 15.5% at
 *          0.15, 30.5% at 0.30
 * 1.60     Background reference sits under Background protection, where it
 *          belongs
 * 1.60     STAR DETECTION WAS THRESHOLDING AGAINST THE WRONG NOISE. It used
 *          adjacent differences, and on stacked data the noise is strongly
 *          correlated -- measured adjacent-pixel correlation 0.973 in both
 *          axes, from registration and drizzle -- so adjacent differences see
 *          only part of it:
 *
 *             adjacent differences             1.227e-4
 *             scatter of ( lum - background )  1.870e-4   a factor of 1.52
 *
 *          The detection compares ( lum - background ) against a multiple of
 *          sigma, so a 6 sigma star was really 3.9 sigma against the quantity
 *          being tested. Rendered with a circle on every detection, the false
 *          ones were visible as clumps along nebula texture with nothing
 *          under them at 8x. Measuring the residual directly is Part Two rule
 *          40 -- measure the quantity, not a proxy. Detections 3350 -> 2394
 * 1.59     THE STAR MASK IS MEASURED ONCE ON THE FULL IMAGE. Detection used
 *          to run inside the method, on whatever buffer it was handed -- and
 *          in a preview that is a crop resampled to the display, so a zoomed
 *          view found a different set of stars from the whole frame. The
 *          mask changed as you zoomed, and the mask being judged was never
 *          the one Execute applied.
 *
 *          detectStarsInBand is now one function with one caller: the
 *          engine's starCatalogue, which streams the full-resolution target
 *          in bands with a halo and caches the result in IMAGE coordinates
 *          against the view id. paintStarMask only paints it, mapping
 *          through ctx.originX, ctx.originY and ctx.scale -- the same
 *          mapping BlemishRemover has carried all along, ported here because
 *          the scale alone lets a method SIZE something but not LOCATE it.
 *          Measured: 3350 stars, and a 1:1 zoomed crop is BIT-IDENTICAL to
 *          the same region of the full-resolution mask, 0 of 196608 samples
 *          differing; a 1:2 preview masks 19.79% against 19.93%
 * 1.59     THE BACKGROUND MASK IS THE STRETCHED LUMINANCE, two steps not
 *          three. Remove the background, stretch what is left, and that is
 *          the mask. The third step, m = 1 - ( 0.25/st )^power, was written
 *          when the sky landed at 0.25 AFTER the autostretch; the sky lands
 *          at 0 now, so 0.25 had become an arbitrary second threshold:
 *
 *                              sky   faint  nebula  bright  protected
 *             stretched lum  0.010   0.295   0.685   0.917    39.4%
 *             with 3rd step  0.000   0.296   0.862   0.925    68.1%
 *
 *          It discarded 68% of the frame against 39% AND inflated the nebula
 *          core to 0.862 against a true 0.685 -- cutting the faint end and
 *          over-driving the bright end at once. Background protection is the
 *          exponent now: 1.00 is that luminance unchanged, above protects
 *          more, below less. It previously INCREASED the sharpening as it
 *          was raised, which is backwards from its name
 * 1.58     BACKGROUND REFERENCE is a control, not a constant -- the same
 *          number and the same meaning as the control of that name in
 *          Neutralize, defaulting to 0.150. It sets the black point the
 *          background mask rescales from, so a field where nebulosity fills
 *          the frame can be told to treat less of it as sky. Measured share
 *          of sharpening allowed:
 *
 *             reference    sky   faint  nebula  bright  protected
 *                0.05    0.000   0.427   0.884   0.928     60.3%
 *                0.15    0.000   0.296   0.862   0.925     68.1%
 *                0.30    0.000   0.207   0.836   0.922     72.9%
 * 1.57     THE BACKGROUND MASK WENT BINARY IN 1.56, AND IT WAS ONE ZERO.
 *          Moving the black point to the sky itself made ( bgLevel -
 *          maskClip ) exactly zero, and that expression was the midtone
 *          anchor -- midtoneTransfer( 0.25, 0 ) is a midtone of zero, which
 *          is a step function. The stretch was removed by accident while
 *          moving the black point.
 *
 *          The anchor is BACKGROUND_TARGET_SIGMA above the sky now, measured
 *          in the post-clip range. Share of sharpening by band, and the
 *          share of the frame at an intermediate value -- which is the
 *          number that says whether it is a gradient at all:
 *
 *               N      sky   faint  nebula  bright   intermediate
 *               1    0.000   0.681   0.916   0.934      48.6%
 *               3    0.000   0.296   0.862   0.925      31.8%
 *              12    0.000   0.000   0.447   0.879       9.9%
 *              50    0.000   0.000   0.000   0.536       0.9%
 *
 *          Three, which is also where a signal is conventionally taken to be
 *          a detection rather than noise. A midtone that still comes out at
 *          zero now warns and falls back rather than silently stepping
 * 1.56     THE BACKGROUND REFERENCE VIEW NOW AGREES WITH NEUTRALIZE. It was
 *          thresholding luminance against a sky level CORRECTED for where
 *          the quantile sits; Neutralize thresholds each channel against its
 *          RAW quantile and calls a pixel background only where all three
 *          are at or below their own level. On the same frame that is 5.1%
 *          of the pixels against 37.8%, and the two views could not be
 *          compared. channelBackgrounds is ported region-for-region from
 *          Neutralize rather than rewritten -- rule 31. It selects 10% of
 *          the sky band and 0% of faint, nebula and bright
 * 1.56     And the mask's black point is the background ITSELF rather than
 *          2.8 sigma below it, so everything at or below the measured sky is
 *          excluded outright and the stretch runs on what is left. Fully
 *          protected share 37.8%; at protection 2.00 the sky receives 0.228
 *          and faint, nebula and bright all receive 0.938
 * 1.55     SMALL STARS WERE BEING REJECTED FOR BEING FAINT, NOT FOR BEING
 *          WIDE. The width is alpha = r_t / sqrt( (amp/detect)^(1/beta) -
 *          1 ), and that divisor collapses as the amplitude approaches the
 *          detection threshold:
 *
 *             amp    7 sigma   divisor 0.230   a 2 px radius reads alpha 8.7
 *             amp   20         divisor 0.703                        2.8
 *             amp  200         divisor 1.489                        1.3
 *             amp 6000         divisor 3.000                        0.7
 *
 *          so the same physical star reads six times wider when faint, and
 *          walked into the alpha cap. Measured share rejected by that cap:
 *          28% at 6-10 sigma, 33% at 10-20, 14% at 20-50, 1% above 50.
 *          The divisor has a floor now, which bounds the inflation without
 *          weakening the test -- something genuinely broad still has a large
 *          r_t and still fails. Coverage at 6-10 sigma 73% -> 81%, and the
 *          sky masked share FELL from 13.6% to 12.2%
 * 1.54     THE BACKGROUND MASK NO LONGER SPLITS AT THE FRAME'S MEDIAN. It
 *          built an autostretch putting the median at 0.25 and read as zero
 *          at or below 0.25, so exactly half of every frame was fully
 *          protected whatever the frame contained -- measured, 49.3%. On a
 *          field with more nebulosity than sky the median sits inside the
 *          signal and the mask protects the very thing the sharpening is
 *          for. Part One section 6 says this in as many words and Neutralize
 *          already does it correctly; backgroundEstimate has been sitting in
 *          this engine unused at Engine.js:966 the whole time.
 *
 *          It is anchored on backgroundEstimate( 0.15 ) now -- the measured
 *          sky and its one-sided sigma -- with the black point 2.8 sigma
 *          below sky and the sky stretched to 0.25. Measured on the linear
 *          frame at protection 2.00, the share of sharpening each band
 *          receives:
 *
 *                        median-anchored   sky-anchored
 *             sky              0.000          0.077
 *             faint            0.427          0.675
 *             nebula           0.826          0.886
 *             bright           0.917          0.928
 *
 *          and the fully protected share of the frame falls from 49.3% to
 *          33.1%. Measured sky 9.8126e-2, sigma 3.785e-4
 * 1.54     Show gains BACKGROUND REFERENCE, a temporary diagnostic: white is
 *          at or below the measured sky, fading out over the same span the
 *          mask uses. A number cannot say whether the estimate landed on sky
 *          or in nebulosity; this can. On the reference frame it counts
 *          37.8% of the pixels as sky and the nebula is plainly excluded
 * 1.54     tools/run_method_on_frame.js carries the same backgroundEstimate, so the
 *          simulator exercises the path that ships rather than a fallback
 * 1.53     THE STAR MASK VIEW WAS BEING SCREEN-STRETCHED, and that is the
 *          whole of why it looked like a hard binary mask beside an
 *          identical soft one under All masks. The two masks were already
 *          bit-identical; only the DISPLAY differed. An autostretch of a map
 *          holding values between 0 and 1 drives every non-zero pixel
 *          towards white -- Part Two rule 32 says exactly this, and the view
 *          was simply missing from the list of views the stretch skips
 * 1.53     And missing from the Execute guard as well, so pressing Execute
 *          with Show set to Star mask would have written the mask into the
 *          user's image. Two lists enumerating the same thing, and a new
 *          option added to neither -- the same shape as Part Two rule 33.
 *          There is one list now, `engine.diagnosticViews`, read by both,
 *          and check_source.py has a check that every Show option other than Result
 *          appears in it. Verified to fail on a copy with Star mask removed
 *          from the list
 * 1.52     THE WIDTH CAP WAS REJECTING REAL STARS, and this was the fault
 *          behind every 'that bright star is not masked' report. Traced on
 *          the specific star: a saturated core spanning a plateau produces
 *          exactly ONE surviving candidate, because the tie rule gives the
 *          plateau to its scan-order-first pixel and rejects the other 120.
 *          That one candidate then failed alpha 5.12 against a cap of 4.71
 *          at a 1:1.7 preview -- 8.7 against 8.0 at full resolution -- so
 *          the whole star was thrown away. It was the 21st brightest in the
 *          frame. One rejection, one missing star, and nothing anywhere said
 *          so
 * 1.52     The cap exists to reject nebula texture, which is broad AND
 *          unclipped. A clipped core is a star by definition, so the width
 *          test is skipped where flatTop is set. Measured at preview scale:
 *          the brightest unmasked maximum went from 6588 sigma to 1703, and
 *          10 of the 25 remaining are within three pixels of a frame edge,
 *          where the detection loop does not reach. Sky masked 6.0% -> 8.2%,
 *          nebula 23.0% -> 23.2%
 * 1.52     The second background pass CLIPS to the first estimate instead of
 *          adding a ceiling to it. Anchored to bg1 it inherited the very
 *          bump it existed to remove; a minimum can only ever lower the
 *          estimate
 * 1.51     EVERY VIEW NOW HAS THE SAME POLARITY: white is where the
 *          sharpening acts. The Star mask view showed the mask itself, so
 *          white meant star and therefore HELD BACK -- the opposite of the
 *          other three. Measured on one frame, what each view gives on sky
 *          against on stars:
 *
 *                                sky     stars
 *             Edge map          0.017    0.072    white = acts
 *             Background mask   0.000    0.937    white = acts
 *             Star mask         0.110    1.000    white = HELD BACK
 *             All masks         0.000    0.000    white = acts
 *
 *          So switching between Star mask and All masks inverted the
 *          picture, which reads as the two being built differently. They
 *          were not; only the sense of the display differed. With one mask
 *          on, its own view is now bit-identical to All masks -- verified
 *          for the edge mask and for the star mask
 * 1.50     AND THEY STILL WERE, for a second reason 1.49 did not touch. The
 *          mask normalised each star against ITS OWN PEAK, so the half point
 *          landed where the profile had fallen to the square root of the
 *          amplitude -- about 80 sigma on a bright star, a long way inside
 *          its visible disc. Measured: the mask reached 1.000 at every one
 *          of the 25 brightest maxima and still covered only 9 to 26 percent
 *          of a 50x50 box around them, which is why they read as unmasked.
 *          The band is FIXED above the noise now, 1 sigma to 30, so the mask
 *          follows how far the star actually extends. Radius at which the
 *          mask reaches one half, modelled:
 *
 *                              faint 60   mid 600   bright 6300
 *             own peak             4.0       5.5           7.2
 *             fixed band           4.5       7.8          12.2
 *             profile reaches 0    6.8      10.8          16.2
 *
 *          so the falloff is still four pixels wide on the brightest star
 *          rather than a step. Measured on the frame: the 40 brightest stars
 *          went from 18% to 36% covered, sky from 3.7% to 3.1%, nebula from
 *          20.8% to 24.0%, and 82% of the mask is still gradient
 * 1.49     THE BRIGHTEST STARS WERE MASKED TOO NARROWLY. A bright star is
 *          not a Moffat, it is a flat saturated disc with a Moffat's wings
 *          outside it. Measured on the brightest star in the reference
 *          frame, radial profile against the fitted model, in units of noise:
 *
 *             r        0      4      8     10     14
 *             measured 6348  6355  5540  2375     72
 *             Moffat   6348   735    45     15    2.4
 *
 *          Still fully saturated at r = 8 where the model has it at 45, so
 *          the mask read about 0.4 across ground that is solid star. The
 *          core radius is measured at half maximum now -- which on a clipped
 *          star IS the plateau -- and the mask is flat across it, while the
 *          wing still comes from the detection-level width. Only the EXCESS
 *          over what the profile predicts is credited, or every faint star
 *          would widen too: crediting the whole radius took the nebula band
 *          from 20.6% covered to 39.0% and the sky from 3.7% to 12.8%
 * 1.49     And the plateau is gated on the top being EXACTLY flat. Bright
 *          nebulosity is broad and smooth as well, so its half-maximum
 *          radius is large too, and crediting that grew a cluster of
 *          oversized blobs over the nebula core. Float data does not produce
 *          exactly equal neighbours by chance; a clipped core does. Measured
 *          after: saturated pixels covered 95.7% -> 100.0%, the largest star
 *          17% -> 34% of its neighbourhood, nebula 20.6% -> 20.8% and sky
 *          3.7% -> 3.7%
 * 1.49     The radial walk is one function. It had been written twice, for
 *          two different levels, and the audit's duplicate-block check
 *          caught it before the two could drift
 * 1.48     ALL MASKS SHOWS THE COMBINED SELECTION, NOT THE WEIGHTED
 *          MULTIPLIER. Each mask that is ON contributes itself and each mask
 *          that is OFF contributes 1, so with only the edge mask on the view
 *          is now bit-identical to the Edge map, with everything off it is a
 *          white frame, and switching a mask on can only take something
 *          away. It used to show mask*( 1 - edgeWeight + edgeWeight*edges )*
 *          ( 1 - starWeight*starMask ) -- the real multiplier, weights and
 *          all -- which at the default edge weight of 0.30 can only move
 *          between 0.70 and 1.00, so the whole frame read as flat grey and
 *          could not be compared against the Edge map beside it. The weights
 *          say HOW MUCH and the masks say WHERE; this view is WHERE
 * 1.47     THE MEASUREMENT WINDOW IS FRACTIONAL. It rounded to an integer,
 *          and the preview scales the radius to the display before the
 *          method sees it -- so at a 1:1.7 zoom, where ctx.scale is 0.588,
 *          the window could only change where round( radius*0.588 ) changed:
 *
 *             radius 1.0 to 2.5   window 1
 *                    2.6 to 4.2   window 2
 *                    4.3 to 5.9   window 3
 *                    6.0 to 7.6   window 4
 *
 *          Four values across the whole useful range. Dragging the slider
 *          through 1.0 to 2.5 changed nothing while typing a number that
 *          crossed a boundary changed everything, which reads as the slider
 *          and the edit box being two different controls and was reported as
 *          exactly that. They are not: both commit through the same path.
 *          The window now interpolates between its two neighbouring integer
 *          values, as blurFractional already does for the sharpening blur.
 *          Measured at that zoom, every step from radius 2.0 upward moves 15
 *          to 26 percent of the frame. Below 1.7 it is pinned at the minimum,
 *          which is physical -- a variance needs at least a 3x3 window
 * 1.46     The star mask is dilated by the measurement window before it gates
 *          anything. Local variance at a pixel includes a star whenever the
 *          star falls inside that pixel's window, so a mask covering only
 *          the star leaves the window's own response around it -- which
 *          showed as each star being a black dot inside a white ring
 * 1.46     Removing the star from the measurement was taken OUT and put
 *          BACK, and the experiment is worth keeping. Out, because the map
 *          should mean one thing and the masks multiply. Back, because they
 *          cannot: a star's influence on the map is as wide as the filter's
 *          whole reach, four passes of half-width r reaching 4r, so gating
 *          by a mask needs that mask dilated by 4r. Measured at radius 5, a
 *          20 pixel dilation left the combined mask at 0.036 on nebulosity
 *          and 0.002 on sky. The mask cannot be wide enough to cover a
 *          star's reach and narrow enough to leave the nebulosity between
 *          stars. What HAD made the removal fail was the background, not the
 *          idea: a single box blur near a bright star is lifted by that
 *          star's own flux, so blending towards it painted in a slope. The
 *          background is taken twice now
 * 1.46     blurRound is driven by BLUR_ROUND_PASSES rather than four
 *          hardcoded calls, so the dilation and the filter cannot disagree
 *          about how far the cascade reaches
 * 1.45     NEBULA STRUCTURE WAS BEING MASKED AS STARS, found by the user by
 *          overlaying the mask on the image -- which is a better test than
 *          any statistic run here, and is now how this is checked. Share of
 *          each band the mask covered above 0.5:
 *
 *                       1.43    1.44    1.45
 *             sky      14.0%    1.8%    1.5%
 *             nebula   33.2%   18.4%   15.4%
 *             stars    58.5%   36.1%   92.5%
 *
 * 1.45     The width test moves from HALF MAXIMUM to the detection level. A
 *          half-maximum radius is not comparable between stars: a bright core
 *          saturates, so the amplitude is underestimated and the crossing
 *          moves outward. Median half-width by amplitude was 2.50 everywhere
 *          and 7.00 above 1000 sigma, so a cap on it threw out 287 of the
 *          BRIGHTEST stars. Walking to a fixed level and solving the Moffat
 *          back for its core width gives the seeing and nothing else --
 *          median alpha 4.26, 3.93, 3.75, 3.91 across the same bands. The cap
 *          is on that now, at 8 image pixels, in the knee of its
 *          distribution: 75% of detections sit under 6.4 and the next
 *          quantile up is 16.2
 * 1.45     And tied maxima are accepted. The strict 5x5 test rejected any
 *          pixel with an equal neighbour, which is right when detections are
 *          going to be FITTED -- a clipped core drags the fit -- and exactly
 *          backwards when they are going to be MASKED, because a saturated
 *          core is the largest star in the frame. Measured, saturated cores
 *          covered: 3.2% before, 92.0% after, with sky and nebula unchanged.
 *          Ties break by scan order so a plateau gives one detection
 * 1.44     THE STAR MASK WAS BINARY IN EVERYTHING BUT NAME. It summed flux
 *          in units of noise and put 1 - exp(-x) over the total -- but a
 *          star runs to hundreds or thousands of sigma, and 1 - exp(-500) is
 *          one to forty decimal places. So the mask sat flat at 1 across a
 *          wide disc and fell in two pixels: a hard-edged blob wearing a
 *          soft formula, and hard edges in a mask are hard transitions in
 *          the result. Each star's profile is normalised against ITS OWN
 *          peak now, in log, smoothstepped, and combined by maximum rather
 *          than by sum. Fraction of the mask's extent sitting flat at 1:
 *
 *             1 - exp(-flux)   faint 28%   bright 35%   measured 35% of frame
 *             log normalised   faint 10%   bright  5%   measured  3.2%
 *
 *          The width still scales with brightness, which was the good
 *          property of the old form: zero at r = 6 for a 50 sigma star and
 *          r = 12 for a 2000 sigma one
 * 1.44     And a width cap, because the softened mask grew a solid patch
 *          over the nebula core. Nebula texture makes local maxima above a
 *          local background too, and they are WIDE. Half-width quantiles of
 *          every detection on the reference frame:
 *
 *              5%  1.75      75%   3.00      95%  13.50
 *             25%  2.25      90%  10.00      99%  18.67
 *
 *          Two populations with a gap, not one distribution -- a star's
 *          width is the seeing and is the same for all of them. The cut goes
 *          in the gap, at 5 image pixels, scaled by ctx.scale. Absolute
 *          rather than a multiple of the frame's own median, because a
 *          median over the stars in a BLOCK moves with the block
 * 1.43     FIXED AT LOAD: the script would not open. `var STAR_DETECT_SIGMA`
 *          in Methods.js collides with `#define STAR_DETECT_SIGMA 20` in the
 *          entry script, and PixInsight substitutes a #define TEXTUALLY, so
 *          the line reached the parser as `var 20 = 6.0;`. Nothing here could
 *          see it: check_source.py strips every # line before any check runs and
 *          node --check has no preprocessor, so it passed both. The constant
 *          is STAR_MASK_DETECT_SIGMA now, and check_source.py has a new check --
 *          declaration collides with a #define -- which reads the entry
 *          script directly, as check_unused_defines already does
 * 1.43     EDGE_WINDOW_MIN drops from 3 to 1, so the radius reaches the edge
 *          map at every setting. At 3 the window was max( 3, round( radius ) )
 *          and radii 1, 2 and 3 produced BIT-IDENTICAL maps -- the control
 *          moved and the mask did not, which is what the user reported and
 *          was right about. The minimum was added when a 3x3 window gave a
 *          wormy map, before the floor was derived per window and before
 *          stars were removed from the measurement; measured now, r=1 gives
 *          4.86x nebula-to-sky against 9.40x at r=5, and every step changes
 *          about 20% of the frame
 * 1.43     The measurement blur takes FOUR box passes, not three. Cascaded
 *          boxes converge on a Gaussian, so the footprint's shape is bought
 *          with passes. Measured, diagonal over across, circle 1.00 square
 *          1.41:  1 pass 1.414, 2 1.286, 3 1.131, 4 1.021, true Gaussian
 *          1.010. A direct Gaussian IS the right shape -- it is the one
 *          kernel both separable and radially symmetric -- but it cost 169
 *          ms at sigma 2, 391 at 5 and 735 at 10 on this frame against a
 *          flat 104 ms for the cascade. One extra pass buys the same shape
 *          for a third of one blur. The sharpening's own base is untouched
 * 1.42     STAR MASK. One mask, two jobs: it holds the sharpening back on
 *          stars, and it takes them out of the luminance the edge map
 *          measures. Each star is painted with its own Moffat profile at its
 *          own amplitude and its own measured width -- soft by construction,
 *          no threshold, no blur step, and a bright star gets a wider mask
 *          than a faint one with nothing to set. Controls: Star mask on/off
 *          and Star protection, plus Star mask in Show
 * 1.42     And that is what removes the squares. A star is so much brighter
 *          than the sky that ANY window touching it saturates the edge map,
 *          so one bright pixel paints the whole shape of the window.
 *          Measured on a flat field, a single saturated pixel produced a 31
 *          pixel blob at radius 5, diagonal-to-across 1.32 where a circle is
 *          1.00 and a square 1.41. On the reference frame, edge map by band:
 *
 *                        stars off   stars on
 *             sky           0.188      0.015
 *             nebula        0.366      0.131
 *             neb/sky       1.95x      8.94x
 *             stretched     2.27x     21.40x
 *
 * 1.42     Three wrong forms were shipped into the diagnostic before the
 *          right one, and each is worth recording. Replacing the star with
 *          its local background left a clean ANNULUS that widening the reach
 *          did not touch: the ring was wherever the mask was PARTIAL, not at
 *          its edge, because out there lum is flat sky while bg is a sloping
 *          bump, so the code was painting in the structure it then reported.
 *          Blending towards the SOFT-LIMITED value instead cannot do that --
 *          where there is no excursion the limited value equals lum, so a
 *          partial mask changes nothing. And the background itself had to be
 *          taken twice: one star lifted its own 41 pixel background window
 *          by 24 sigma at the centre, so the first estimate carried the
 *          star's shape into everything downstream
 * 1.42     Two block-invariance faults found by the simulator's rows=
 *          override, both introduced by the star work. A median core width
 *          pooled over the stars in each BAND moved with the band, changing
 *          1.9% of the frame -- each star uses its own width now. And the
 *          halo was sized at one background radius where the background is a
 *          three-pass box taken twice, so it reaches six times that: 212436
 *          samples differed at 97-row blocks, and the error grew as the
 *          blocks shrank, which is what a short halo looks like. Both now
 *          bit-identical at every block size tested
 * 1.41     THE FLOOR WAS CALIBRATED ON A CONTAMINATED POPULATION AND KILLED
 *          THE NEBULOSITY. 1.40 took the 99th percentile of local variance
 *          over the darkest fifth of the frame, on the reasoning that a
 *          floor there passes 1% of flat sky. The reasoning is sound; the
 *          population is not. The darkest fifth by local mean still holds
 *          everything sitting BETWEEN stars, where the variance comes from
 *          stellar wings. Measured in units of the local noise variance:
 *
 *             sky median      2.1
 *             faint           3.1
 *             nebula          5.5
 *             99th pct sky   23.9   <- the 1.40 floor, four times the nebula
 *
 *          So nebulosity fell below the floor and the map showed stars on
 *          black. The floor is twice the sky's MEDIAN now, which a tail of
 *          star wings cannot move. Nebula reads 0.32 against 0.21, and the
 *          floor lands within 2% of itself on linear and stretched copies of
 *          the same frame, which is the part 1.40 got right and this keeps
 * 1.41     The mask window follows the sharpening radius again. Decoupling it
 *          in 1.40 removed the squares and removed the user's only handle on
 *          the mask with them -- radius changed the sharpening and nothing
 *          about the map. The squares are a star saturating the map across
 *          the whole window footprint, so they belong to the star work, not
 *          to the window. Measured nebula against radius, linear frame:
 *          0.322 at r=2, 0.366 at r=5, 0.389 at r=8
 * 1.40     The noise profile and both bounds are built on typed arrays with
 *          numeric sorts. The first cut used Array.sort with a comparator
 *          three times over a hundred thousand elements, which measured 156
 *          ms on a 2.1 megapixel frame -- more than the whole per-pixel
 *          pass. Best of nine, against 1.39: 467 ms -> 520 ms total, so the
 *          brightness-dependent floor costs about 11% and not the factor
 *          the comparator sorts would have
 * 1.40     THE EDGE MAP NOW MEANS THE SAME THING ON LINEAR AND STRETCHED
 *          DATA. Its floor was one global noise sigma, but noise is a
 *          function of brightness and that function INVERTS between the two.
 *          Measured on a linear frame and an autostretched copy of the same
 *          pixels -- noise sigma against local brightness:
 *
 *                        linear      stretched
 *             sky        2.39e-4     1.54e-2
 *             bright     8.02e-4     4.14e-3
 *                        rises 3.4x  falls 3.7x
 *
 *          One global figure sits near the sky on both, so on linear data
 *          the floor was ~3x too low on bright structure and on stretched
 *          data ~2.8x too high. The same pixels read 0.393 and 0.173, and
 *          the nebula-to-sky ratio was 9.12x against 1.91x. A monotonic
 *          stretch multiplies the local excursion and the local noise by the
 *          same gain, so local variance over the noise variance AT THAT
 *          BRIGHTNESS is what it leaves alone. The floor is that now, from a
 *          24-bin profile measured in the first pass. Four of five bands now
 *          agree within 9%; star cores still differ, and that is real -- the
 *          stretch widens the clipped plateau and variance there is zero
 * 1.40     THE MASK WINDOW NO LONGER FOLLOWS THE SHARPENING RADIUS. It was
 *          max( 3, round( radius ) ), so radius 7 measured variance over a
 *          15x15 box and every saturated star stamped a 15x15 SQUARE on the
 *          map. The two answer different questions -- the radius is what
 *          scale of detail to amplify, the window is how much evidence to
 *          gather before believing there is structure. Measured at radius
 *          7.138, holding the window at 7x7: sky 0.254 -> 0.126 and the
 *          nebula-to-sky ratio 2.39x -> 4.14x, with the result bit-identical
 *          across block geometries
 * 1.40     EDGE_NOISE_FLOOR_FACTOR retired. It was 3.0 with a comment beside
 *          it that reasoned its way to 2 and was never reconciled. The floor
 *          is now measured from the frame's own sky: the 99th percentile of
 *          local variance over noise-only pixels, in units of the noise
 *          variance there. That is the value pure noise exceeds one time in
 *          a hundred, so 1% of flat sky passes by construction -- whatever
 *          the window size and whatever the noise correlation, which is why
 *          it is measured rather than taken from a chi-squared table.
 *          Stacked data has correlated noise and scatters more than
 *          independent samples predict. It comes out near 46x on this linear
 *          frame and 27x on the stretched copy
 * 1.40     Three test scripts deleted: test_filter.js, test_hue.js and
 *          test_modes.js all exercised the guided filter and the vividLight
 *          ratio detail, neither of which has existed since 1.31. They
 *          passed, which is worse than failing. verify_no_clipping.js kept, with
 *          its dead ratio branch cut
 * 1.39     Header text as the user wrote it. And linear data was tested rather
 *          than ruled out: radius 2, amount 2, edge mask on, measured as the
 *          change in nebula detail against the original --
 *
 *             linear    edge weight 0.3  x0.89     1.0  x0.84
 *             stretched edge weight 0.3  x1.49     1.0  x1.35
 *
 *          On linear it does not sharpen nebulosity at all. The sky sits at
 *          0.098 and the nebula at 0.107, so there is almost no local variance
 *          for the mask to find and almost no difference to amplify; stretched,
 *          the same structure is nearly twice the sky
 * 1.38     Header text down to two paragraphs: what the script is, and what
 *          the controls do. How an unsharp mask works belongs in the code, not
 *          in the dialog
 * 1.37     RESCALE RUNS FIRST, and nothing clips any more.
 *
 *          It ran last, and its transform comes from the SOURCE range -- so
 *          sharpening pushed bright edges above the source maximum and those
 *          landed past the top margin and clamped. On a lunar frame a crater
 *          rim read 0.919 unrescaled and 1.000 rescaled: pure white, detail
 *          gone. Rescaling first means the headroom limiter works on the
 *          rescaled values and the boundaries are unreachable again. The edge
 *          map bounds scale with it, by the square, since a local variance
 *          does.
 *
 *          And the limiter's own margin was RELATIVE to the headroom, so a
 *          pixel already at 0.99 was left 1e-8 short of white -- below the
 *          1.19e-7 step float32 has next to 1.0, so it rounded onto it. At
 *          amount 11.6 that was 5672 pixels of pure white. The margin is
 *          absolute now. Measured after: 0 newly at 1.0, 0 newly at 0.0.
 *
 *          Edge mask defaults On at weight 0.30. At 1.00 the mask gates the
 *          sharpening completely wherever it reads zero, which shows as
 *          boundaries between treated and untreated ground; at 0.30 it biases
 *          towards structure instead
 * 1.36     Star detection thresholds against a LOCAL background rather than
 *          the frame's sky. A star stands above its own surroundings; the sky
 *          median says nothing about a peak sitting on nebulosity, so anywhere
 *          the nebula rose above it, its texture read as stars. Measured on a
 *          real frame: 6070 candidates against 2499, and the extra ones were
 *          nebula -- a mask painted from them was a solid blob over M20.
 *          Groundwork for the star mask; nothing consumes it yet
 * 1.35     Renamed Unsharp Mask Pro. The script was called Detail Enhancer
 *          while it enhanced detail with a filter it did not have; it is an
 *          unsharp mask, and one that cannot clip, does not shift hue and
 *          amplifies light and dark equally. Nothing had shipped, so the id
 *          and key prefix changed with it.
 *
 *          RESCALE added, below the masks: the darkest pixel maps to
 *          RESCALE_MARGIN and the brightest to 1 - that, so neither end is
 *          crushed and a later curve still has something to pull back. All
 *          channels take the same transform, so no hue shift. For lunar and
 *          planetary frames that occupy a fraction of the range.
 *
 *          A rule above the Edge mask and above Rescale, separating what the
 *          sharpening does from where it acts. The header text is four
 *          paragraphs instead of thirty lines
 * 1.34     The edge map stops being wormy, and Show gains "All masks".
 *
 *          The map measured local variance over the SHARPENING radius, so at
 *          radius 1 that is a 3x3 window -- about eight samples, and a variance
 *          from eight samples scatters far too much to decide anything. It has
 *          its own minimum window now. Measured separation, sky against
 *          nebulosity: 3x3 13.2x, 5x5 24.6x, 7x7 33.4x. Nothing required the
 *          two to match: the radius says what scale to amplify, the window says
 *          how much evidence to gather first.
 *
 *          AND A REAL STREAMING BUG, found by the simulator. The noise sample
 *          stride was computed from the BLOCK's row count, and sampling stopped
 *          after forty thousand pairs -- so which pixels were measured depended
 *          on how the engine divided the image. One block against seven changed
 *          2.2 million samples. Now 0. Part One section 9 names this as the
 *          invariant most likely to be quietly wrong in a streaming script
 * 1.33     Less noise in the edge map. It started to rise AT the noise
 *          variance, which passes half the sky, because the variance estimate
 *          is itself noisy -- a 3x3 window has about eight degrees of freedom
 *          and on pure noise the local variance scatters 76%. Measured share
 *          of pure sky reaching a map value above 0.3:
 *
 *             floor 1x noise   23.5%
 *             floor 2x noise    8.6%
 *             floor 4x noise    2.9%
 *
 *          Faint structure is barely selected at any floor -- low contrast
 *          means low local variance -- so raising it costs nothing real.
 *          EDGE_NOISE_FLOOR_FACTOR, beside the numbers
 * 1.32     The edge map reaches full at the 90th percentile of local variance,
 *          not the 99th. The comment beside that line always said 90th; the
 *          code said 0.99. Measured on a stretched frame, as the median map
 *          value each region receives:
 *
 *                             nebulosity   sky     stars
 *             99th percentile    0.033     0.000   0.079
 *             90th percentile    0.999     0.003   1.000
 *
 *          At the 99th nothing reaches the top of the range -- even stellar
 *          cores only got 0.079 -- so the map read as a near-black frame with
 *          a few points on it and the sharpening it gates was nearly off. It
 *          is EDGE_FULL_QUANTILE now, in one place, beside the numbers
 * 1.31     THE SHARPENING MATHS WAS WRONG. The detail layer was extracted with
 *          a Vivid Light blend, vividLight( lum, base ) - 0.5, which is zero
 *          when the two agree and so looks like a high-pass. It is not one.
 *          Vivid Light is two branches whose slopes both depend on the local
 *          level. Measured gain on a small excursion:
 *
 *             level 0.098   up 0.554   down 5.102   -- 9.2x asymmetric
 *             level 0.270   up 0.685   down 1.852   -- 2.7x
 *             level 0.500   up 1.000   down 1.000   -- symmetric
 *             level 0.900   up 5.000   down 0.556
 *
 *          So on linear data every dark excursion was amplified nine times
 *          more than the matching bright one -- the hard black ring around
 *          every star -- and because the gain runs 0.55 to 5.0 across the
 *          tonal range, one Amount sharpened different parts of the frame by
 *          different factors. That is the muddled texture. It is also why
 *          Amount had to be pushed so far: at sky level the useful gain was
 *          0.554.
 *
 *          It is now a plain difference. Gain 1 on both sides at every level;
 *          measured detail symmetry 1.02 against 9.2. Clipping is still
 *          impossible: the headroom limiter makes 0 and 1 unreachable by form
 * 1.30     tools/run_method_on_frame.js runs the shipped method over real data outside
 *          PixInsight, with the engine's own block streaming, and writes both
 *          a picture and the float result. It reproduces what the script does
 *          rather than describing it. Eight builds went out to be tested by
 *          hand for things that are visible here in one run
 * 1.29     Both masks default to Off, so the sharpening can be judged on its
 *          own. Settings persist, so a stored On survives until Reset
 * 1.28     Everything added in 1.26 and 1.27 removed. What was asked for was a
 *          downsampled preview with the kernel rescaled to match: one crop,
 *          one resample to display size, one transform there. That is what
 *          this is, and it is all it is.
 *
 *          Gone: the pixel budget, minimumScale, the intermediate work buffer,
 *          the second resample of the result, the mask at a matching scale,
 *          the cached full-resolution source, and the gate that refused to
 *          transform below one buffer pixel. That gate is why nothing changed
 *          at any setting, and it is why Amount got pushed to 4.8, where the
 *          headroom limiter drives noise to pure black and white -- the
 *          speckle. Below one buffer pixel the preview now shows the effect
 *          weakly, which is honest, and says so once
 * 1.27     Fixes the half-size preview 1.26 shipped. The work buffer sits at
 *          workScale, so bringing the RESULT to the display needs the
 *          remaining factor zoom/workScale -- using the whole display zoom
 *          shrank it twice and gave 512x342 for a 1024x683 preview. Caught by
 *          the buffer size check added in 1.19, not by reading the code.
 *          The mask is now built at workScale too, so it matches the buffer
 *          the transform runs on: at display size it disagreed with the
 *          working image and the engine dropped it, which was already true of
 *          the old full-resolution path
 * 1.26     The preview shows the sharpening again.
 *
 *          1.25 was correct and useless: it transformed at DISPLAY scale, and
 *          a radius of R image pixels is one buffer pixel only at scale 1/R,
 *          so at any ordinary zoom the radius fell below the floor and the
 *          method declined. Nothing visible at any setting.
 *
 *          The preview now asks the method, through minimumScale(), for the
 *          scale it needs and works THERE when a pixel budget allows. On a
 *          9032x6028 frame in a 1024x683 preview: radius 1 renders at full
 *          resolution out to 1:4, radius 2 and above at every zoom. Beyond the
 *          budget it declines and names the zoom that would show it.
 *
 *          scaleDependent is gone -- minimumScale supersedes it and says how
 *          much rather than merely whether
 * 1.25     Fixes the artifacts 1.24 shipped. 1.24 moved the transform to
 *          display resolution and scaled the radius by ctx.scale -- but NOTHING
 *          EVER SET ctx.scale. It is read as a guarded fallback, so undefined
 *          simply meant 1, and the preview applied radius 1 to a buffer shrunk
 *          8.8 times: an 8.8 pixel operation where 1 was asked for, with the
 *          edge map measured on resampled data. The engine now carries the
 *          scale and the preview sets it, cleared in a finally so Execute is
 *          always 1. Two audit checks added: a ctx field the engine never
 *          defines, and one that reads the RAW source because strip_code()
 *          blanks the string in defineProperty( ctx, "stats" )
 * 1.24     Opening should now take about a second instead of forty.
 *
 *          TWO causes, both measured rather than guessed. Adding the preview
 *          to a sizer resizes it and onResize rebuilds -- before the dialog
 *          has asked for anything -- so construction ran two full rebuilds,
 *          18.8 s and 19.0 s. Rebuilds are now suspended until setImage.
 *
 *          And the transform ran on the full-resolution crop: 13.7 s of each
 *          rebuild, on 54.4 megapixels to fill 0.70. It now runs at display
 *          resolution with the radius scaled to match. Where the scaled radius
 *          falls below one buffer pixel the preview says so and leaves the
 *          image alone rather than drawing a coarser operation than Execute
 *          applies -- radius 1 needs 1:1, radius 4 needs 1:4
 * 1.23     Fixes the blank preview 1.22 shipped: `why` was added as a parameter
 *          of rebuild() while the log line using it lives in rebuildOnce(), so
 *          the rebuild threw and was swallowed. A thirtieth audit check now
 *          catches a name used in one function but declared only in another --
 *          the same shape as the `i` bug in Part Two rule 4
 * 1.22     Every rebuild logs WHICH caller started it. The guard added in 1.21
 *          was correct in itself but did not remove the second rebuild, and
 *          two attempts to name that caller by reading the call sites were
 *          both wrong. Diagnostic only
 * 1.21     The preview was built TWICE on opening. updateViewLists() assigns
 *          ViewList.currentView, that fires onViewSelected, and that handler
 *          was the only one in the dialog without the updating guard -- so it
 *          ran a full rebuild before the constructor ran its own. Measured at
 *          18.7 s and 19.7 s on a 9032x6028 frame, the whole of the 38.8 s
 *          the dialog took to appear. Rebuilds are now numbered in the log
 * 1.20     Timing. Every stage of a preview rebuild and of opening reports its
 *          own elapsed milliseconds to the console. Diagnostic only: no
 *          behaviour changes. Three guesses at the open time were wrong
 * 1.19     The compare view no longer jumps to a different part of the image.
 *          For a scale-dependent method the stretched ORIGINAL was built from
 *          the full-resolution crop while the stretched preview was resized
 *          down, and drawBitmap does not scale. That was also most of the cost
 *          of opening: a full-resolution copy, a HistogramTransformation over
 *          it and a full-resolution Bitmap on every rebuild. A size check now
 *          warns if any preview buffer disagrees with the display size
 * 1.18     The method is called Unsharp Mask, because that is what it is: the
 *          base is a blurred copy and the comment claiming a guided filter was
 *          false. Star detection and a Moffat PSF fit added to the engine, in a
 *          region marked for the Template, reported by the diagnostics button.
 *          Nothing consumes the PSF yet
 * 1.17     Diagnostics report the block geometry, so a seam at a block
 *          boundary can be read off numbers rather than guessed at
 * 1.16     Detail from and Edge threshold removed, with the guided filter
 *          behind them. The edge mask calibrates itself from the image, so a
 *          raw threshold in noise sigma had nothing left to decide and two
 *          controls both named 'edge' meant different things
 * 1.15     The black edge map. backgroundEstimate takes the spread below a
 *          low brightness quantile, which is the sky on a deep sky frame and
 *          the terminator on a lunar one -- it returned 67x the true noise,
 *          putting the map's floor above its ceiling so every pixel clamped
 *          to zero. The noise is now measured from adjacent differences in
 *          the first pass, and an inverted range falls back instead of
 *          emitting a black map
 * 1.14     Each mask has its own on/off. Turning one off meant knowing that a
 *          strength of zero did it, which is not a control, and the Show list
 *          offered maps that were not active. Both toggles gate the maths as
 *          well as the panel
 * 1.13     The edge map was mathematically in 0-1 and visually black: local
 *          variance spans decades, so a linear rescale crushed the median to
 *          0.002. It is rescaled in LOG space now, median 0.36, and the noise
 *          floor it starts from is the noise variance itself rather than a
 *          formula that came out 0.4x too small
 * 1.12     The blur was reading buffers it had already overwritten. Chaining
 *          three box passes with two arrays made the source and the scratch
 *          the same on two of them, and the result was a blur ASYMMETRIC by
 *          0.080 across a step -- now 3e-8. Every result since the three-pass
 *          blur arrived went through it: the ratio detail, the guided filter,
 *          and the variance the edge map is built from
 * 1.11     The edge map is now rescaled to 0-1 and actually USED. It was the
 *          raw coefficient, unreadable, and computed only for display -- so
 *          the sharpening was applied evenly and flat areas got the same
 *          amplification as real structure, which is the pebbling. Measured
 *          on a lunar frame: pebbles 42.9x with the map off, 1.34x with it
 *          on, while detail on real edges rose from 11.0x to 5.3x
 * 1.10     Moving a slider shrank the preview. The full-resolution crop was a
 *          local set only when the source was rebuilt, so a parameter change
 *          transformed the already-resampled image and then resized it again.
 *          It is now cached like every other buffer, and the resize keys off
 *          whether a full-resolution image was actually used
 * 1.09     The preview transformed an image that had already been resampled,
 *          so it sharpened features larger than the ones Execute works on and
 *          the output came back softer than the screen. It now crops,
 *          transforms at FULL RESOLUTION, and resizes the result -- the same
 *          operation Execute performs, at every zoom
 * 1.08     Two thirds of the sharpening was being thrown away before it
 *          reached the image. The no-clip application scaled every change by
 *          the headroom at that pixel, costing about half everywhere rather
 *          than only at the extremes, and Background protection read a lunar
 *          frame as three quarters background. The application now passes
 *          85-97% of what it is given and still cannot clip; protection
 *          defaults to off
 * 1.07     The preview now SAYS when the radius is too fine to show at this
 *          zoom. Showing the untouched image silently was worse than showing
 *          the wrong radius: downsampling flatters any frame, so an untouched
 *          preview reads as a good result
 * 1.06     The preview was applying a different radius from Execute. The
 *          buffer radius was floored at one pixel, so at 1:2.3 a requested
 *          radius of 1 ran as 2.3 image pixels and the effective radius
 *          changed with every zoom. The radius is now fractional and exact
 *          at any zoom that can show it; below that the preview shows the
 *          image untouched instead of a radius nobody asked for
 * 1.05     Three box passes instead of one: a single box is a plateau with
 *          hard shoulders, and subtracting it left those shoulders in the
 *          detail layer. Edge threshold reaches 5000, because at 2 it kept
 *          nothing at all on a lunar frame. New Show: an Edge map, which
 *          makes that visible instead of leaving it to be inferred
 * 1.04     Amount reaches 100 on a curved slider: a soft frame carries a detail
 *          layer around 0.005 and needs fifty before anything shows. The
 *          scaled detail is now soft limited rather than clamped, so the top
 *          of the control still responds and no pixel reaches black or white
 * 1.03     The detail comes from luminance and drives all three channels, so
 *          the hue cannot shift. Filtering each channel separately moved the
 *          hue up to 3.5 degrees at high amounts, and cost three times the
 *          work for the privilege
 * 1.02     Two ways of separating the detail, chosen by a control, and the
 *          edge threshold exposed. The threshold was derived from the noise,
 *          which made the filter preserve exactly what a lunar image is made
 *          of: 22% of a crater rim was extracted against 91% of nebulosity
 * 1.01     The detail goes back as a share of the headroom left at each pixel,
 *          not as a fixed quantity, so no amount can blow a highlight to
 *          white or a shadow to black. Amount range 0 to 8 to suit
 * 1.0      First release. Derived from the script template.
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    UnsharpMaskPro : Another Astro Channel > Unsharp Mask Pro
#feature-icon  @script_icons_dir/UnsharpMaskPro.svg


#feature-info  Unsharp masking with an edge mask measured from the frame's own noise, a background mask, and an optional rescale for lunar and planetary work. Nothing it does can clip.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder, and it is the author's to decide:
 *
 *    ASSISTANTS -- ASK, DO NOT ASSUME. The person you are building for owns
 *    this line. Ask them what name and year they want, or whether they want no
 *    attribution at all, in which case set it to "" and the panel simply starts
 *    with the description. Do not copy a name out of an example, another
 *    script, or this file's history. Guessing here puts someone else's name on
 *    the user's work.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Unsharp Mask Pro"
#define VERSION     "2.16"
#define SCRIPT_ID   "UnsharpMaskPro"
#define KEYPREFIX   "UnsharpMaskPro"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Unsharp masking that cannot clip, gated by an edge mask measured from the frame's own noise."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
/*
 * 0.75 IS THE SUITE'S PAN CONTRACT (rule 81, set by the user after two
 * scripts clamped his pan for rebuild cost). The margin is never the
 * lever again: the cost lever is caching the transform result, and a
 * slower zoom is the accepted price until this script gains one
 * (StarMask's full-resolution result caches are the model).
 */
#define PAN_MARGIN               0.75

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304


#define STATISTICS_BINS          1048576


/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
/*
 * The blur radius, in image pixels, that separates detail from base.
 *
 * This is the one number that decides what the script IS. At a small radius the
 * detail layer is edges and grain, and scaling it sharpens; at a large one it is
 * structure several tens of pixels across, and scaling it is what other software
 * calls clarity. Same filter, same control.
 */
/*
 * The smallest radius, in BUFFER pixels, the preview can honestly draw. Three
 * box passes are a running sum over 2r+1 pixels, so there is no window below
 * one. Under this the preview leaves the image alone and says the radius is
 * not visible at that zoom, rather than drawing a coarser operation than
 * Execute will apply.
 */
#define DETAIL_MIN_BUFFER_RADIUS 1.0

/*
 * How far Rescale keeps the result from black and white, as a fraction.
 *
 * Rescaling to exactly 0 and 1 leaves nothing at either end: the darkest pixel
 * is then unrecoverably black and the brightest unrecoverably white, and any
 * later curve has nothing to pull back. 0.2% of the range costs nothing
 * visible and leaves both ends intact.
 *
 * Hardcoded rather than exposed. It is not a creative decision and a control
 * for it would be one more thing to explain.
 */
#define RESCALE_MARGIN           0.002

/*
 * How far short of black and white the headroom limiter stops, as an ABSOLUTE
 * value.
 *
 * The limiter approaches the boundary asymptotically, but float32 has a step of
 * 1.19e-7 next to 1.0, so anything closer than that rounds onto it. A margin
 * proportional to the headroom shrinks below the representable step exactly
 * where it matters -- at pixels already near white -- and the guarantee fails
 * silently. 1e-6 is representable at both ends and invisible.
 */
#define HEADROOM_EPSILON         1e-6


#define DETAIL_RADIUS_MIN        1
#define DETAIL_RADIUS_MAX        100

/*
 * Rows per streamed band, and the halo each band reads beyond its own rows.
 *
 * The blur is three box passes, so it reaches three times the radius, and and a
 * fractional radius applies it twice, once at each of the two integer radii
 * either side. Six times the radius is what makes a band self-contained. Measured: 512 rows with a 120 pixel halo is
 * 235 MB resident for a 24 megapixel colour frame, against 1960 MB for the whole
 * image, and that figure does not grow with the image.
 */
#define DETAIL_HALO_FACTOR       6


/*
 * Rec. 709 luminance, the same weights the saturation mask uses. Consistency
 * matters more than the choice: two masks disagreeing about what brightness
 * means would select differently on the same pixel.
 */
/*
 * STAR DETECTION AND PSF MEASUREMENT
 *
 * STAR_DETECT_SIGMA is above the SKY in units of the noise. The measured PSF is
 * insensitive to it: on a real frame the median FWHM moved 3% across thresholds
 * from 10 to 40 sigma, so it is set high enough that faint candidates do not
 * dominate the sort rather than tuned.
 *
 * STAR_FIT_MAX is 150 because 50 stars already give the median FWHM to within
 * 0.3% of what 487 give. Beyond that it is cost with no accuracy.
 *
 * STAR_SAMPLE_ROWS bounds the statistics pass. 400 rows spread over the frame
 * gives the noise to well within 1% and does not grow with the image.
 *
 * STAR_BLEND_FRACTION is applied to a genuine second MAXIMUM, never to a bright
 * pixel. A star of sigma 1.9 has 28% of its peak at radius 3, so testing bright
 * pixels at 30% rejects stars for their own wings -- 93% of them, measured.
 */
#define STAR_WINDOW              8

/*
 * The radius of the local background window used for star DETECTION, in pixels.
 *
 * A star must stand above its own surroundings, not above the frame's median.
 * Measured: thresholding against the global sky found 6070 candidates on a real
 * frame against 2499 with a local background, and the extra ones were nebula
 * texture -- a mask painted from them covered the nebula in a solid blob.
 *
 * 20 is comfortably wider than any star and far narrower than the nebulosity it
 * has to follow. It sets the halo the detection pass reads, so raising it costs
 * memory as well as time.
 */
#define STAR_BACKGROUND_RADIUS  20
#define STAR_NOISE_BINS          16

/*
 * The width cap, as a multiple of the frame's own median core width. A star's
 * width is the seeing and every star shares it; anything much wider is not one.
 */
#define STAR_ALPHA_FACTOR        2.0

/* Below this many detections the median is not worth trusting, so no cap. */
#define STAR_ALPHA_SAMPLE_MIN    50

/*
 * The seeing median is taken over detections at least this bright, in local
 * sigma. Above it a detection is almost always a real star at any threshold,
 * so the cap cannot be poisoned by a low detection setting.
 */
#define STAR_SEEING_AMP_MIN      30

/*
 * The walk level's narrow reference, a box radius in pixels. Wide enough to sit
 * under a star, narrow enough to follow a nebula ridge.
 */
#define STAR_WALK_RADIUS         3

/*
 * How much of the detection threshold the narrow amplitude must also clear.
 * A half, because the narrow reference sits partly on a real star's own wings.
 */
#define STAR_WALK_AMP_FRACTION   1.5
/*
 * The radius of the reference the noise is measured against. Small enough that
 * an object's structure survives it and only pixel-to-pixel scatter is left.
 */
#define STAR_NOISE_SCALE         2
#define STAR_ELLIPSE_ARMS        16

/*
 * How far the profile may rise above its lowest point before the walk decides
 * the star has ended, in units of the local noise. Grain alone must not end it.
 */
#define STAR_TURN_TOLERANCE      2.0

#define STAR_SAMPLE_ROWS         400
#define STAR_NOISE_SAMPLES       50000
#define STAR_DETECT_SIGMA        20
#define STAR_FIT_MIN             8
#define STAR_FIT_MAX             150
#define STAR_CANDIDATE_SLACK     20
#define STAR_SATURATION          0.999
#define STAR_CORE_RADIUS         3
#define STAR_BLEND_FRACTION      0.30
#define STAR_PROFILE_BINS        32
#define STAR_BIN_MIN             5

/*
 * The adaptive moment weight. STAR_MOMENT_CUTOFF is in squared Mahalanobis
 * radius, so 9 is three sigma of the current estimate -- past that the weight
 * is under 0.011 and the pixel is noise.
 */
#define STAR_MOMENT_SEED         2.0
#define STAR_MOMENT_ITERATIONS   12
#define STAR_MOMENT_CUTOFF       9

/*
 * The Moffat grid. beta is the wing weight: 4.765 is pure Kolmogorov seeing and
 * real data sits lower. Measured 3.1 to 3.5 on a real frame, so the range is
 * wide enough to be a measurement rather than a confirmation of the default.
 */
#define MOFFAT_BETA_MIN          1.2
#define MOFFAT_BETA_MAX          9.0
#define MOFFAT_BETA_STEP         0.02
#define MOFFAT_BETA_COARSE       0.20
#define MOFFAT_FWHM_MIN          1.2
#define MOFFAT_FWHM_MAX          12.0
#define MOFFAT_FWHM_STEP         0.01
#define MOFFAT_FWHM_COARSE       0.10

#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define CURVE_PLOT_HEIGHT        200
#define READOUT_HEIGHT           32
// Raised from 0.25 with rule 62: this script's rebuild runs one to two
// seconds, and a debounce shorter than a mid-drag hesitation fires it while
// the finger is still moving, freezing the slider.
#define PREVIEW_DEBOUNCE_SECONDS 0.5

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/StarMeasurement.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      /*
       * TIMED. Opening this script took thirty seconds against three for one
       * that does not transform at full resolution, and three separate guesses
       * at the cause were wrong. The stages report themselves so the fourth
       * does not have to be a guess.
       */
      let t0 = Date.now();
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();
      let tTarget = Date.now();

      let dialog = new MainDialog( engine );
      let tDialog = Date.now();

      console.noteln( "<end><cbr>open: target " + ( tTarget - t0 ) + "ms" +
                      "   dialog built in " + ( tDialog - tTarget ) + "ms" );

      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
