/*
 ****************************************************************************
 * Contrast Limited Adaptive Histogram Equalization
 *
 * CLAHE.js
 *
 * Local contrast enhancement by Contrast Limited Adaptive Histogram
 * Equalization. The image is divided into tiles, a clipped histogram
 * equalisation is derived for each, and the mappings are interpolated between
 * tile centres so no tile boundary is visible.
 *
 * Built on the PixInsight Script Template. The maths lives in lib/Methods.js and
 * the parameters in lib/Config.js.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.67  THE PAN CONTRACT IS RESTORED, and the attempt that broke it is
 *        withdrawn. Rule 81 says the margin is 0.75 in every script and is
 *        NEVER the lever for speed; the previous build shrank it for
 *        transforms measured as expensive, and the pan clamp was reported
 *        within the hour -- the fourth report of that one bug. A smaller
 *        margin IS less pan travel, whatever the justification, and no
 *        measurement makes that acceptable. marginSelection no longer even
 *        ACCEPTS an override, and verify_wheel_standin.js now enforces the
 *        rule: no override, no cost test at the render-region choice, and
 *        PAN_MARGIN 0.75 asserted in all ten entry scripts. A rule that
 *        lives only in a document gets broken.
 *        WHAT SURVIVES, because it costs the user nothing: the wheel waits
 *        longer before committing when the transform is expensive (his
 *        report -- one accidental notch, reaching for a pan, used to commit
 *        before it could be scrolled back, and half a minute went with it).
 *        0.3 s for a cheap transform, 1.5 s for an expensive one, decided by
 *        what the last pass measured per visible megapixel. That number
 *        sizes the delay and nothing else.
 *        THE ZOOM FLASH stays fixed (the stand-in now ends at applyPublish,
 *        not when the rebuild starts), and EXECUTE and the STATISTICS are
 *        untouched as always: Execute runs over the target view itself, and
 *        median/MAD come from the full target view cached per view, never
 *        per zoom -- so a stretch places the whole image's median however
 *        far in you are looking. Both are asserted now.
 *        DECONVOLUTION'S ZOOM COST IS THEREFORE STILL OPEN: 540 ms per
 *        megapixel per RL iteration, 6.25x of it for the pan margin. The
 *        honest levers are caching and the cost per pixel, not the margin.
 *        THE DRAWN ZOOM BOX NOW BEHAVES LIKE THE WHEEL (his report: "it
 *        processes first before it actually zooms in, which is
 *        backwards"). Both gestures queue a selection and both wait on the
 *        same rebuild, but only the wheel armed the scaled stand-in, so a
 *        boxed zoom drew the OLD un-zoomed view under the busy cross for
 *        the whole transform and arrived at the new view last. One line;
 *        the checks now assert both paths arm it.
 * 1.66  THE ZOOM FLASH, fixed at the right moment this time (his
 *        report, from video, twice: wheel to zoom, stop, and the
 *        preview SNAPS BACK to where it was, waits out the
 *        transform, then arrives at the zoomed view).
 *        A wheel notch only queues a selection -- the rebuild waits
 *        for wheel-quiet -- so between notch and render the painter
 *        draws the current bitmap SCALED to the queued zoom. That
 *        stand-in is the entire gesture's feedback, and it was being
 *        cancelled at the START of a transform that then runs for
 *        seconds, repainting a busy indicator over whatever the
 *        painter could draw: the old buffer, at the old zoom. The
 *        earlier fix moved that cancellation from the wheel commit
 *        to where rebuildOnce consumes the queued selection -- still
 *        the start of the transform, so the flash survived and was
 *        reported again. The painter now reads standInSelection, a
 *        field of its own that no rebuild touches, and applyPublish
 *        clears it: the one moment the render that replaces it
 *        actually exists. Dropped too when the target changes or a
 *        queued zoom is abandoned, so a stand-in cannot outlive its
 *        image. New check, shared/tools/verify_wheel_standin.js,
 *        asserts the ORDER on the shipped source and goes red on the
 *        exact form that shipped twice.
 * 1.65  NO MORE BOXES AROUND THE LABELS (his report: "all of these
 *        text boxes, whether they're blank or not, have outlines
 *        around them"). The section panel's sheet is set on the box
 *        with BARE declarations -- the form that reliably reaches a
 *        PCL control -- but Qt matches those declarations against
 *        every DESCENDANT too, so `border: 1px solid` was drawing a
 *        rounded rectangle around every label and every empty cell
 *        in the section. The fill still reaches the children, which
 *        was always right; the border is confined to a class
 *        selector, and no border is declared for the rest, since
 *        saying `border: none` there would strip the value boxes and
 *        buttons of the borders the dialog sheet gives them.
 *        US SPELLING THROUGHOUT THE INTERFACE (his report, raised
 *        before): color, not colour, and the same for neutralize,
 *        normalize, center, gray and their relatives. TEXT ONLY --
 *        `colourProtection` and `colour` are PERSISTED SETTINGS KEYS
 *        and keep their spelling, because renaming one orphans every
 *        saved setting and process icon; "centre" is also a drag
 *        state and a property name in the hue wheel.
 * 1.64  THE GLOBAL RESET BUTTON, the one button in the dialog still
 *        wearing the stock look (his screenshot). It is
 *        dialog.resetButton -- one letter from dialog.resetButtons,
 *        the per-row list declared beside it -- and a hand-written
 *        list of the dialog's buttons simply skipped it.
 *        verify_theme_wiring.js now DERIVES that list from
 *        MainDialog's own source, matching every
 *        `this.<name>Button = new ToolButton`, so a button added
 *        there and not styled fails a check instead of a
 *        screenshot; poisoned, it names the missing button.
 * 1.63  THE ICON BUTTONS GET A LIGHT FACE -- the point behind every
 *        "I can barely see the reset buttons" report, finally heard.
 *        PixInsight's icons are drawn DARK, for its light stock
 *        theme; on a dark chip a dark glyph is an EMPTY SQUARE, and
 *        outlining that square in white changes nothing, because the
 *        glyph inside is still dark on dark. His words: stop
 *        outlining things in white, make the thing itself contrast.
 *        So every icon button now has a light face and a quiet grey
 *        edge -- the per-row reset buttons, the dialog's own row
 *        (new instance, execute, cancel, real-time, documentation,
 *        diagnostics), the preview's zoom trio, and THE SECTION BAR
 *        COLLAPSE TOGGLES, which had never been styled at all: PJSR
 *        builds that button inside SectionBar, so nothing in this
 *        codebase held a reference to one until it was reached
 *        through bar.button.
 *        Also: 0.23's drop-down arrow was a CSS border-triangle,
 *        chosen to force it white. On the web that draws a triangle;
 *        Qt fills ::down-arrow as a BOX, so every dropdown showed a
 *        solid white SQUARE -- a regression on an arrow that had
 *        rendered correctly since 0.21. The platform's light arrow
 *        image is back, the compartment's divider is quiet grey
 *        again, and the verifier FAILS if the triangle form returns.
 * 1.62  WHITE ARROWS AND WHITE-EDGED ICON BUTTONS -- his call, asked
 *        for three times while grey after grey was offered instead,
 *        and approved from a drawing before this was built. The
 *        drop-down arrow is drawn as a CSS triangle in #ffffff
 *        rather than loaded from a resource, so there is no asset
 *        path left to fail; the platform's own arrow art is dark,
 *        for light panels. The per-row reset buttons and the
 *        dialog's own icon buttons -- new instance, execute,
 *        cancel, real-time, documentation, diagnostics and the
 *        preview's zoom trio -- carry a white edge on a dark chip.
 *        The chip stays dark deliberately: the glyphs are light,
 *        and a white FILL would erase them. The diagnostic build's
 *        magenta and orange are gone; its counting line is gone
 *        too, but a refusal still warns to the console, because
 *        four silent try/catch blocks are how a fix shipped four
 *        times and changed nothing.
 * 1.61  DIAGNOSTIC BUILD -- THE COLOURS ARE DELIBERATELY WRONG, and
 *        the next build takes them out again. Four attempts to shade
 *        the icon buttons have come back from PixInsight looking
 *        identical, and the pixels cannot say WHY: refused,
 *        ignored, or applied and invisible all look the same. So
 *        the reset buttons are screaming magenta, the dialog's own
 *        icon buttons orange, and themePolish now COUNTS what it
 *        did and prints it -- four silent try/catch blocks in a row
 *        is how a fix ships four times and changes nothing. Three
 *        outcomes, each pointing somewhere different: solid colour
 *        means the sheet reaches the control and only the colour
 *        was ever wrong; a thin coloured RING around the icon means
 *        the icon is drawn over the whole button and no fill can
 *        ever show (the borders have always rendered -- that is the
 *        clue); no colour at all means no style sheet reaches a PCL
 *        ToolButton and the answer is a different mechanism. The
 *        console line reports the counts independently of the
 *        pixels. Rule 82's method, which ended the confetti in one
 *        screenshot after six plausible fixes had failed.
 * 1.60  THE ICON BUTTONS, ON THE ONE FORM PROVEN TO REACH A PCL
 *        CONTROL. Three builds tried to shade the per-row reset
 *        buttons and each left them sunk into the panel in his
 *        screenshots: a dialog-level QToolButton rule, the same
 *        rule with the background shorthand, then a widget-local
 *        sheet wrapped in `*`. Meanwhile the section panels have
 *        been correctly shaded since the pilot -- by a widget-local
 *        sheet of BARE DECLARATIONS. That form is now copied
 *        exactly instead of a fourth variation being invented, and
 *        the verifier asserts the chip sheet carries no selector so
 *        the failing form cannot come back. Accepted cost: bare
 *        declarations cannot express :hover, so these buttons lose
 *        their hover lift -- a button that can be SEEN beats one
 *        that lights up once the pointer is already on it.
 *        THE DIALOG'S OWN ICON BUTTONS get the same chip (his
 *        second report: the row along the bottom "blending into
 *        the dark background") -- new instance, execute, cancel,
 *        real-time, documentation, diagnostics and the preview's
 *        three zoom buttons. The platform paints them transparent,
 *        so on this floor they were icons floating on nothing.
 * 1.59  THE RESET BUTTONS AND THE DROP-DOWN ARROW, ON THE ROUTE THAT
 *        ACTUALLY REACHES THEM (his report on the last build: "I
 *        dont see any of the changes" -- the package carried them,
 *        the controls ignored them). Both were styled by
 *        DIALOG-LEVEL class rules, QToolButton and
 *        QComboBox::drop-down, and those do not reach PCL's
 *        controls -- the same lesson this theme learned twice
 *        before, for the section panels and the popup lists, and
 *        the reason both of those are set WIDGET-LOCALLY. They are
 *        now set the same way: themePolish puts a chip sheet on
 *        every reset button it finds on the dialog, and the arrow
 *        compartment sheet on every picker AND every schema-built
 *        combo (recognised by what it can do, since the method and
 *        Show dropdowns are declared in Config and appear in no
 *        script's picker list). The lift shade goes from one step
 *        above the panel to clearly above it -- the previous value
 *        would have been near-invisible even had it applied.
 *        verify_theme_wiring.js now asserts the sheets ON THE
 *        OBJECTS, not merely that the rules exist: a rule assigned
 *        to nothing is exactly what shipped last time.
 * 1.58  THE BLUE GRID, AND TWO CONTRAST FIXES HE ASKED FOR. The grid
 *        in a value box was never our focus handling: PixInsight's
 *        OWN style sheet (rsc/qss/core-standard.qss) paints these
 *        controls with TILED 9-slice images -- QLineEdit:focus gets
 *        border-image: url(:/qss/border-focus.png) 33% repeat -- and
 *        a light-theme frame repeated across a 20-pixel box renders
 *        as a blue checkerboard over the value. border-image is a
 *        separate property from border, so setting a border never
 *        displaced it. Now turned off by name on every state the
 *        platform sets it on, for line edits, spin boxes, combos,
 *        push buttons and tool buttons; a focused edit takes a plain
 *        accent outline instead. This also retires the "hatched
 *        button" seen in the earliest theme screenshots.
 *        THE DROP-DOWN NOW LOOKS LIKE ONE (his report): the arrow's
 *        compartment is a step lighter than the field with a divider
 *        down its left edge, and the arrow is the platform's LIGHT
 *        glyph -- its own combobox arrow art is drawn dark, for light
 *        panels, and was invisible here. THE RESET BUTTONS (his
 *        report) sit on a chip above the panel with a defined edge:
 *        the platform paints QToolButton transparent, which put them
 *        into the panel. verify_theme_wiring.js asserts all of it.
 * 1.57  THE FOCUS GRID IN A VALUE BOX, root cause found in the
 *        platform's own header (his UnsharpMaskPro screenshot: the
 *        Star detection value box filled with a blue dither).
 *        Shared Compat.js resolved FOCUS_CLICK to 0x01 -- and
 *        pjsr/FocusStyle.jsh says 0x01 is FocusStyle_Tab; Click is
 *        0x02. PJSR declares these as preprocessor defines, so the
 *        runtime probes never resolve and the fallback IS the
 *        value. Every value edit the theme made "click-only" was
 *        therefore made the dialog's FIRST TAB STOP, so the
 *        opening focus landed on one and painted its focus marks
 *        over the number -- the artifact rule 82 part 3 exists to
 *        prevent, delivered inverted. The constant now comes from
 *        the header, with FOCUS_NONE and FOCUS_WHEEL checked
 *        against it too, and verify_theme_wiring.js asserts all
 *        three so the value cannot drift back. The preview's
 *        FOCUS_CLICK|FOCUS_WHEEL becomes click+wheel as intended
 *        (it was tab+wheel), which also takes it out of the tab
 *        chain.
 * 1.56  THE DARK THEME, suite-wide (rule 82; StarMask 0.39-0.53
 *        piloted it): Theme.js is included, applyTheme skins the
 *        dialog before any control constructs, and the themePolish
 *        one-shot names this script's hand-built controls
 *        (it has none). The shared Target view picker is now the
 *        themed combo -- ViewList's closed face is core-painted past
 *        any style sheet (Template 2.59). Also inherited from
 *        Part-2, recorded here per rule 65: the wheel-zoom stand-in
 *        holds through the rebuild instead of snapping back to the
 *        stale view (shared PreviewControl, Template 2.58).
 *        Shared ParamControls now lists every per-row reset button
 *        on the dialog as it creates them, so the polish reaches
 *        controls no script names -- they were the one focusable
 *        class the recipe could not see.
 * 1.55  Shared PreviewControl: a rebuild finishing during an open drag
 *        parks its result and publishes at gesture end -- the in-flight
 *        rebuild can no longer eat the zoom box. Template 2.57.
 * 1.54  Shared PreviewControl: the wheel-zoom feedback anchors on the
 *        rendered selection (the 1.53 anchor jumped the view by the pan
 *        margin), and the gesture guard moved into rebuild() itself --
 *        no caller can steal a drag. Template 2.56.
 * 1.53  Shared PreviewControl: wheel zoom commits on wheel-quiet --
 *        notches accumulate with live scaled feedback, one rebuild 0.3 s
 *        after the last notch, mouse press commits first. Template 2.55.
 * 1.52  Shared MainDialog: the default per-control layout is callable
 *        (layoutGeneratedControls), so a section builder can compose
 *        schema rows around a hand-built one (UnsharpMaskPro 2.00's
 *        Masks section). No behaviour change here. Template 2.54.
 * 1.51  Shared Engine: Execute writes any displayed view -- the guard
 *        that blocked executing a diagnostic view is removed (the run is
 *        one undoable process step; the console notes a diagnostic
 *        output). Template 2.52 carries the mechanism.
 * 1.50  Shared AutoStretch: computeAutoStretch reads the native
 *        median/MAD first, keeping the JS histogram as the fallback --
 *        the derivation cost twelve full-frame JS passes on a color
 *        frame, most of a 49-second stars-only mask build (StarMask
 *        0.24). The screen stretch pays milliseconds now.
 * 1.49  Shared PreviewControl: the screen stretch always applies to the
 *        untransformed picture; only a diagnostic-map TRANSFORM skips its
 *        stretched copy. The old guard nulled the stretch for the whole
 *        preview, so a map view with Show transformed off displayed the
 *        plain image unstretched beside a ticked box (reported on
 *        StarMask 0.23; structural everywhere). Template 2.50 carries the
 *        mechanism.
 * 1.48  Shared MainDialog: the preview debounce defers while a zoom or
 *        pan drag is active, so a queued refresh can no longer eat
 *        the drag (reported on StarMask; structural everywhere).
 *        The mechanism is the Template 2.48 changelog entry.
 * 1.47  Per-parameter reset button at the end of every slider row (shared
 *        ParamControls), matching PixInsight's own convention: click
 *        restores the schema default and refreshes the preview.
 * 1.46     The screen stretch target is labelled "Background target", which is
 *          what the number is: the background level the stretch aims for.
 * 1.45     TARGET BACKGROUND FOR THE SCREEN STRETCH, beside the mode in the
 *          preview header, default 0.20 (the old fixed constant was 0.25).
 *          Shared change: the target is a parameter of computeAutoStretch,
 *          part of the stretch cache key, and a NumericEdit in the shared
 *          dialog. View STF ignores it, as that mode uses the view's own
 *          transfer function. Verified: on a real frame the midtone moves
 *          monotonically with the target and nothing else changes.
 * 1.44     Output options and Preview dimensions start folded away
 * 1.43     Vertical pan travel matches horizontal. The render margin was sized from
 *          the selection, so wherever the selection was shorter than the control
 *          the margin went on covering that inset instead of giving travel -- 44%
 *          of a view on a 1600x900 selection, none at all on an extreme aspect.
 *          Sized from the control it is 75% in both axes at every aspect
 * 1.42     Pan clamped to the control rather than to viewPort(), which is the
 *          selection centred in the control and therefore inset wherever the
 *          selection is smaller than the control. That inset was the strip of
 *          empty canvas at the end of a drag -- 30 px on a full frame -- and it
 *          appeared in whichever axis had the slack
 * 1.41     The end of a pan showed empty canvas. The clamp measured the rendered
 *          margin in image coordinates, which exceeds what the bitmap covers by
 *          the slack between the fitted selection and the viewport -- 192 px for
 *          a 1600x900 selection in a 1024x768 preview. It now clamps to the
 *          bitmap's own extent
 * 1.40     Pan margin 0.75, so a drag from anywhere but hard against an edge runs its
 *          full length without stopping to rebuild
 * 1.39     Pan travel doubled. A drag is clamped to the rendered margin, which was a
 *          quarter of a view and now is half, so it stops to rebuild half as often
 * 1.38     Slider travel can be curved, for a parameter whose useful values sit at
 *          one end of a wide range
 * 1.37     Opening with the screen stretch on showed an unstretched image beside a
 *          ticked box: setImage discarded the stretched copies and nothing
 *          rebuilt them, so only toggling the box made the two agree
 * 1.36     Temporal dead zone check now sees nested blocks. A `let` used inside an
 *          `if` above its own declaration parsed, passed the check, and threw
 * 1.35     A parameter key passed as a string was Americanised by the spelling pass,
 *          silently disabling a control. Audit now checks every key-string lookup
 * 1.34     US spelling in everything a user reads, matching PixInsight's own UI.
 *          Parameter keys keep the British spelling on purpose: renaming one
 *          would make saved instances fall back to defaults without an error
 * 1.33     Dead mask machinery removed: the ProtectionMask subsystem and the per-view
 *          mask registry, ~250 lines that could never run. The preview now honours
 *          a user's mask, which a flag that was always false had prevented
 * 1.32     Ancestor string removed from the label column; new README check
 * 1.31     Label column measured from the schema instead of a hardcoded sample
 *          string, so a long label no longer pushes its own control out of line
 * 1.30     Audit gains a check for a parameter group with no matching section
 * 1.29     Header text rewritten: the acronym is broken down first and the
 *          comparison with LocalHistogramEqualization is gone
 * 1.28     Preview size labels share one column; audit gains a check for an
 *          object used but never declared, which a clone had lost
 * 1.27     Audit gains a class-method check
 * 1.26     tools/build_update_package.py builds an update package for a repository
 * 1.25     Attribution moved to the dialog header and declared once, as a define
 * 1.24     Menu and title now Contrast (CLAHE); custom icon; header notes
 *          the difference from LocalHistogramEqualization
 * 1.23     Menu group: Another Astro Channel, out of Utilities
 * 1.22     Audit reads the #feature-* directives
 * 1.21     Feature-info corrected: it still described the script as a template
 * 1.20     Audit gains field, ALL_CAPS and placeholder-identity checks
 * 1.19     scriptWarn/suppressWarnings restored; DESCRIPTION is live again
 * 1.18     The preview publishes its state atomically, so no paint can see a
 *          half-finished rebuild
 * 1.17     The screen stretch appeared to switch itself off after a zoom
 * 1.16     The preview was one rebuild behind whenever the screen stretch
 *          was on: a stale bitmap cache
 * 1.15     A drawn bug icon for the diagnostics button, moved to the right
 * 1.14     Diagnostic maps skip the screen stretch; labelWidth restored
 * 1.13     Preview rendered before the layout had applied the new size
 * 1.12     Custom width and height sit together instead of at opposite ends
 * 1.11     The preview is rebuilt after an in-place Execute
 * 1.10     Preview size as a dropdown, custom width and height on one row
 * 1.09     Trimmed the header text to two paragraphs
 * 1.08     Header text in METHOD_INFO, with attribution; labels capitalised
 * 1.07     Carry screen stretch removed, with the engine and AutoStretch
 *          code that only it used
 * 1.06     Apply to target image is the default; Create new image is not
 * 1.0      First build, derived from the template at v1.21
 * 1.01     Interpolate between histogram bins: the nearest-bin lookup was
 *          collapsing 64 input levels onto each output
 * 1.02     Show tiles overlay
 * 1.03     Conservative defaults: 24 tiles, contrast limit 1.0, amount 0.5
 * 1.04     Trimmed the header text; Clip limit renamed Contrast limit
 * 1.05     Shed template leftovers; statistics measured only when read
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    CLAHE : Another Astro Channel > Contrast (CLAHE)
#feature-icon  @script_icons_dir/CLAHE.svg


#feature-info  Local contrast enhancement by contrast limited adaptive histogram equalization.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Contrast (CLAHE)"
#define VERSION     "1.67"
#define SCRIPT_ID   "CLAHE"
#define KEYPREFIX   "CLAHE"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
/*
 * Kept for the template contract, but the dialog no longer prints it: the
 * method's own one-line description says the same thing, in the same place,
 * without repeating itself.
 */
#define DESCRIPTION "Local contrast enhancement by contrast limited adaptive histogram equalization."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
#define PAN_MARGIN               0.75

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
#define STATISTICS_BINS          1048576

/*
 * Maximum chroma gain at full saturation. The soft limiter that prevents
 * clipping tapers as chroma approaches the available headroom, so the delivered
 * gain is well below this on bright pixels. 8 is the knee: 3 -> 8 buys about 45%
 * more separation, 8 -> 12 only another 12%.
 */
/*
 * Histogram resolution per tile. Astronomical data is smooth, so 256 bins band
 * visibly; 1024 costs 4 KB per tile and does not.
 */
#define CLAHE_BINS               1024

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define CURVE_PLOT_HEIGHT        200
#define READOUT_HEIGHT           32
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
