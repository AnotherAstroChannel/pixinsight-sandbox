# Neutralize for PixInsight

Neutralizes the background by matching the three channel levels to each other, so
the sky reads neutral. Works on linear and stretched data, and cannot clip.

Installs under **Script → Another Astro Channel → Neutralize**.

---

## What it does

Sky glow is not the same brightness in every channel, so the background of an
uncalibrated frame carries a color cast. Left in place, every subsequent step
amplifies it — a saturation boost in particular cannot tell a cast from real
color, so a faintly blue sky becomes a strongly blue one.

This measures each channel's background level and scales the channels so those
levels meet.

**It scales down, never up.** The three levels are matched to the *dimmest* of
them, so every factor is at most one. That is what makes clipping impossible: no
value can be pushed past white, and nothing can cross zero, so a negative pixel
left by stacking stays finite rather than becoming a NaN. The guarantee comes
from the form of the maths, not from a clamp afterwards.

**It removes a fixed amount, not a fixed fraction.** This is the part worth
understanding, because it is what makes the script usable after color
calibration.

Sky glow adds the *same amount* to every pixel — the same small offset in a star
core as in empty sky. But a plain rescale removes an amount *proportional* to
brightness. On a measured frame that means it takes roughly the right amount out
of the sky and about ten times too much at ten times the sky level, rising to
several hundred times too much in a bright core.

Color calibration protection scales the correction back in proportion to brightness, so the
amount removed is constant everywhere. Verified flat to within a few percent
across three decades of luminance. The sky is corrected; stars and nebulosity are
left as they were.

---

## Controls

**Neutralization Method** — where the background levels are measured.
*Statistical* reads a low quantile of each channel across the whole frame, and
needs no input. *Selected area* uses a box you place on the image instead.

**Background Reference** — which quantile counts as background, for the
statistical method. 0.5 would be the median; 0.15 as shipped.

Not the median, because the median of a whole frame is only the sky level if most
of the frame is sky. On a field full of nebulosity it is not: signal drags it
upward, and the channels are then matched at a level inside the nebula rather
than in the sky. **Lower it on a crowded field.**

**Sample box** — the side of the sampled box, in pixels of the full-resolution
image. 32 samples 1024 pixels. The median of the box is taken, so a star inside
it is ignored as long as it covers less than half the box.

**Pick background area** — arms the picker; the next click on the preview places
the box there. The console reports how far the box sits above the whole-frame
estimate, in noise sigma. Well above zero means you are on structure rather than
sky — which a stretched preview will not show you.

**Color calibration protection** — described above. **This is for an image that
has already been color calibrated, and it is off by default.** Turn it on after
calibration, to keep the color the calibration gave the stars and nebulosity; on
an uncalibrated frame it holds back the correction you came here for.

**Show protection** — displays the weight instead of the image. White where the
full correction lands, dark where it is held back: at ten times the sky level the
weight is a tenth, at a hundred times a hundredth, so stars read near black. The
map is not screen-stretched, so what you see is the weight itself. Execute is
refused while it is on.

---

## Where it fits in a workflow

Neutralizing the background is reasonable as the first thing done to a linear
image, before color calibration, since a cast in the sky affects everything
downstream.

It is also useful *after* calibration and stretching, where small residual shifts
appear. That is the case color calibration protection exists for: the correction removes the
residual from the sky without disturbing color a calibration has already set.

---

## Notes

**Measurements come from the full-resolution target**, never from the preview
buffer. The buffer is cropped and resampled, so a reading taken from it would
depend on the zoom.

**Noise is not the limiting factor on the sampled box.** The median of 1024
pixels is accurate to about 0.04 noise sigma. Contamination is the risk — a box
placed on faint nebulosity reads high, which is why the reading is reported in
sigma above the statistical estimate.

**A mono image has no cast to remove**, so the controls are disabled for one.

---

## Requirements

PixInsight 1.8.9 or later, with the V8 script engine.

---

© 2026 Bill Blanshan — Another Astro Channel
