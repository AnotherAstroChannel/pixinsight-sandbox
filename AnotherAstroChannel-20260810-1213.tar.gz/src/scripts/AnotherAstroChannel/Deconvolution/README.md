# Deconvolution

**In development. Not for release.**

Cloned from Unsharp Mask Pro 1.92 to inherit its preview, engine, star
catalogue, Moffat PSF measurement and protection masks. The sharpening
operator is being replaced by regularized deconvolution driven by the
image's own measured star profile. Until that lands, this script still
sharpens.

This README is a placeholder; the real one is written when the maths ships.
