# Unsharp Mask Pro

Sharpening and local contrast for PixInsight, under
**Script → Another Astro Channel → Unsharp Mask Pro**.

© 2026 Bill Blanshan — Another Astro Channel

---

## What it does

One method at present, **Unsharp Mask**. A second, Deconvolution, is being
built; this version already measures the star profile that method needs and
reports it, so the measurement can be checked before anything depends on it.

### Unsharp Mask

The image is blurred, the difference between the image and the blur is the
detail, and that difference is put back amplified.

| control | what it does |
|---|---|
| **Radius** | the scale it works at. Small sharpens; large adds local contrast. |
| **Amount** | how much of the detail layer goes back. |
| **Edge mask** | holds the sharpening off flat areas. |
| **Edge weight** | how strongly the mask acts. |
| **Background mask** | holds it back in the sky. 0 is off. |
| **Protection** | how far up the brightness range the background mask reaches. |
| **Rescale** | stretches the result to just inside black and white. For lunar and planetary. |
| **Show** | displays any mask, or all of them combined, instead of the result. |

**The edge mask is not optional in practice.** Subtracting a blurred copy
produces a signed rim either side of every edge, and in a flat region the
difference is simply the noise. Amplifying those is where star rings and
background pebbling come from. The mask exists to hold the amplification off
both, and it is calibrated from the frame's own noise floor, so it means the
same thing on any image and needs no threshold set by hand.

**Not for linear data.** The detail layer scales with local brightness, so on a
linear frame it is negligible in the sky and enormous at the stars, and one
Amount cannot suit both.

**Nothing here can clip.** The detail is added as a share of the headroom
remaining at each pixel, approaching 0 and 1 without reaching either, so no
Amount blows a highlight to white or a shadow to black. Amount 0 is bit-exact.

**Hue is preserved.** The detail is taken from luminance and applied to all
three channels equally.

---

## The star profile

Press the **bug icon**, bottom right, and the console reports what the script
measures from the target: the noise, the sky level, how many stars it found and
rejected, and the fitted profile.

Nothing consumes these numbers yet. They are reported so the measurement can be
checked before deconvolution relies on it.

```
star profile
   noise (adjacent differences)  1.343e-4
   sky level                     0.098020
   candidates found              7584
   measured                      150   rejected: 39 saturated, 3 blended, 5 too wide
   FWHM                          4.20 px
   Moffat beta                   3.30
   eccentricity                  0.25  at 35 deg
   profile fit rms   Moffat      0.0113   Gaussian 0.0259
```

**The model is a Moffat, not a Gaussian.** Star profiles have heavier wings than
a Gaussian, and the difference is not small: on a real frame the Moffat fit left
less than half the residual. Deconvolving with a Gaussian models the wings as
far too faint, so the algorithm tries to explain the real wings as structure and
drives them into the correction — which is where ringing around bright stars
comes from. Both residuals are printed so the claim can be checked on your own
data rather than taken on trust.

**Accuracy.** Against synthetic frames with a known profile, the FWHM comes back
within about 5%, biased slightly high because centroid error smears the stacked
profile. Too wide is the direction that rings, so a deconvolution should apply a
little under the measured value.

**What it needs.** Enough unsaturated, unblended stars — eight at minimum. On a
lunar or planetary frame there are none, and it will say so rather than return a
number. Those will use a typed PSF instead.

**Cost does not grow with the image.** The statistics come from a bounded sample
and only the brightest 150 stars are measured, so the only part that scales with
the frame is one comparison per pixel.

---

## Installing

Unzip into your PixInsight scripts directory, then **Script → Feature Scripts →
Add** and pick the folder. Restart PixInsight.

## Notes

**`*** Error: Source code MD5 checksum mismatch`** is not a bug. PixInsight
stores a hash of the script source in every process icon and refuses to run one
after the source has changed. Launch through **Script → Execute Script File**
instead, or rebuild the icon.

**The preview transforms at full resolution and then resizes**, because the
result depends on pixel scale: sharpening a half-size image is not the same
operation as sharpening and then halving, and the second is what Execute does.

## Verifying

```bash
node tools/verify_star_psf.js      # recovers a known profile from synthetic frames
python3 tools/check_source.py
python3 tools/verify_check_source.py
```

`verify_star_psf.js` builds its own test frames, so it needs no data file. Given
one it will also measure a real frame:

```bash
node tools/verify_star_psf.js frame.bin <width> <height> <channels>
```
