# Star Mask (development script -- not for release)

The suite's star mask as its own script, so the mask can be built, judged and
fixed cheaply, then carried back into UnsharpMaskPro and Deconvolution.

Show:
- **Result** -- the mask, and what Execute writes.
- **Stars removed** -- every masked star replaced by its local background.
  Any star still visible is one the mask missed. This view exists for
  debugging screenshots.

(The untouched image is the Show transformed check box, unticked; the
"Image" option was removed at 0.30. Execute writes whichever view is
displayed -- suite-wide since Template 2.52.)

The star machinery (catalogue, PSF measurement, detection, painting) is
file-carried from the tested Deconvolution copies and must stay in step with
them.
