# SCNR-Pro

Removes a green or magenta cast from an astronomical image without throwing
away the signal that carries it, and without clipping anything.

## Why it exists

The usual way to remove green lowers the green channel to whatever red and
blue justify. On a normal colour image that is right: green there is a cast,
and its brightness was never real. On a narrowband image mapped to the Hubble
palette it is a problem, because green is hydrogen -- usually the deepest
signal in the frame -- and lowering it discards the best data you collected.

Measured on an Ha-dominant pixel, plain removal keeps **43.8%** of the
hydrogen. Holding the brightness while correcting the colour keeps **85.2%**,
and holding the green itself keeps all of it.

## Controls

**Green target** decides what green is allowed to reach.

- *Average* pulls it to the mean of red and blue -- the firmest correction.
- *Maximum* pulls it only to the brighter of the two -- the gentlest.
- *Hybrid* blends the two, weighted by how far green is above its neighbours,
  so a strong cast gets the firm treatment and a mild one is barely touched.
  Yellow, where green legitimately sits between red and blue, is left alone.

**Neutralise by** decides where the correction comes from.

- *Normal* -- green comes down and the frame gets darker. Right when green
  is a cast.
- *Hold luminance* -- green comes down and red and blue come up until they
  meet, so the frame keeps its brightness. The default.
- *Hold the green* -- the green is untouched and the other two rise to meet
  it, so the frame gets brighter. Keeps every bit of the signal.

**Correct** chooses green, magenta, or both. Magenta is the same operation on
inverted data, since magenta is what green becomes when you invert.

## What it will not do

It cannot clip. Every path either scales by a factor bounded so nothing can
pass 1, or scales downward. Verified over the whole RGB cube: no value above 1
and none below 0, in any mode, in any setting.

It also cannot create signal. Raising red and blue raises their noise with
them, and in a narrowband set those are usually the thin channels. How far this
can be pushed is set by how well they were exposed.
