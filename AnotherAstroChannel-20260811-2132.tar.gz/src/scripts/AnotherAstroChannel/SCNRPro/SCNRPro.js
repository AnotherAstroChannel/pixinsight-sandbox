﻿/*
 ****************************************************************************
 * PixInsight Script Template
 *
 * Template.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.09  THE HEADER, AS HE WROTE IT BACK. The first paragraph is now
 *        one sentence saying what the script is for; Correct moved down
 *        to open the second, where the other two controls already were.
 *        His edits kept: American spelling to match PixInsight's own UI,
 *        "without clipping" rather than "without clipping anything", and
 *        the note about Correct starting at Off deleted -- the dialog
 *        already shows that.
 *        RULE 84 GAINS ITS PROSE HALF, on his instruction: "send me the
 *        text before you create the build." A picture is cheaper than a
 *        build and so is a paragraph, since there is nothing to render.
 *        The reply he sent back changed three things in one pass, where
 *        the same three would have been three install cycles. It covers
 *        anything read on screen: the header, tool tips, labels, option
 *        names, console lines and warnings.
 * 1.08  THE LABEL READS, AND THE HEADER SUMMARISES. "Neutralise by:
 *        Hold the green" is not English -- `by` wants a verb after it and
 *        the options are noun phrases. The options are his and stay; the
 *        label is "Correction:", which reads with all three and separates
 *        it from Green target above. A label change keeps the key, so no
 *        stored setting and no saved instance notices (rule 8).
 *        THE HEADER WAS EXPLAINING RATHER THAN SUMMARISING. Rule 78: what
 *        the script does, plain language, three paragraphs at most,
 *        controls named exactly as they read on screen. It now says what
 *        each of the two enums chooses and what each choice costs, and it
 *        mentions the Star mask, which it never did. The paragraph arguing
 *        the narrowband case has gone to the README, where a reader who
 *        wants the reasoning will find it and a reader mid-adjustment
 *        will not have to scroll past it.
 * 1.07  HOLD THE GREEN NOW FINISHES THE JOB. His report: green bleeds
 *        through on the Average target. Measured over the cube, the share
 *        of colours that still carried a cast afterwards:
 *
 *           target     Normal   Hold luminance   Hold the green
 *           Average      0.0%             0.0%            51.9%
 *           Maximum      0.0%             0.0%             0.1%
 *           Hybrid       0.0%             0.0%             0.1%
 *
 *        Half the colours, silently. The Average target asks red and blue
 *        to raise their MEAN to meet green, and the cap that stops either
 *        passing 1 bites long before that wherever the two are unequal:
 *        at R 0.8 and B 0.2 the mean is 0.5 but the larger is 0.8, so the
 *        factor runs out at 1.25 when 2G is needed. With the Maximum
 *        target the two conditions coincide exactly and the cap can never
 *        bind first, which is why that column read 0.1% and this went
 *        unnoticed.
 *        Raising is a preference about WHERE the correction comes from,
 *        not a promise to leave green alone at the cost of not correcting
 *        at all. So green is held as far as it can be and comes down for
 *        whatever is left. After: 0.0% carry a cast on every target, and
 *        green is still kept at 89.6% on Average and 99.9% on the other
 *        two, with nothing clipped.
 *        THE GATE HAD BEEN EXCUSING THIS ROUTE from its "the cast is gone
 *        afterwards" assertion, which is why it stayed green through the
 *        whole thing. It asserts every route now.
 * 1.06  THE STAR MASK OPENS AT OFF, EVERY TIME. His report: the script
 *        takes a long time to start. The default was already Off, but the
 *        setting PERSISTED -- so once it had been switched on while
 *        testing, every later open restored it and ran a full-frame star
 *        detection before he had asked for anything.
 *        `persist: false`, the StarMask precedent, and here it costs real
 *        seconds rather than only surprise. A saved process instance still
 *        replays its own choice; only the stored setting is dropped.
 *        Checked across the panel: starMask, Show mask and the mask-source
 *        picker are all session-fresh now, so a fresh open runs no
 *        detection at all. The tuning values -- Star detection, Star mask
 *        size, Star strength -- still persist, because remembering those
 *        costs nothing on open and is what anyone would want.
 * 1.05  CORRECT STARTS AT OFF. His call, and it gives the "before"
 *        view back as a setting rather than as behaviour hidden inside
 *        the map: with nothing being corrected the Cast map shows the
 *        cast in full, and opening the script changes no pixel until a
 *        cast is chosen.
 *        THE ENCODING CHANGED WITH IT, and it had to. The three targets
 *        were 0/1/2 with the passes chosen by `what != 1` and
 *        `what != 0` -- arithmetic that reads like a set membership test
 *        and is not one, so a fourth value would have run BOTH passes
 *        instead of neither. Two booleans cannot fail that way.
 *        THE MAP STILL SEES BOTH CASTS WHILE OFF, deliberately: measuring
 *        only what is selected would make the Off map black, which is the
 *        opposite of the reason for having Off. Verified: Off changes no
 *        pixel, and the map reads 0.75 on a green cast, 0.75 on its
 *        magenta mirror and 0.0000 on neutral grey.
 * 1.04  THE PIXEL READOUT REACHES THE EDGE OF THE PICTURE. His
 *        report: zoomed in, the RGB values stop before the cursor gets
 *        to the edge. Reproduced outside PixInsight at his own 1:1.9 on
 *        a 960x730 canvas with a 1500x1388 selection: the picture spanned
 *        the whole 960 px and the readout accepted 86 .. 874, so
 *        eighty-six pixels of visible picture down each side reported
 *        nothing.
 *        THE CAUSE. zoomFactor is min( W/w, H/h ), so a selection whose
 *        aspect differs from the panel is letterboxed -- and the PAN
 *        MARGIN is painted into that letterbox, because the bitmap is
 *        anchored on renderSelection. The picture therefore fills the
 *        canvas while viewPort(), which the readout gated on, covers only
 *        the selection. Rule 36: the paint learned about the margin and
 *        the readout never did.
 *        THE FIX was to remove the gate, not widen it. viewToImagePoint
 *        is linear, so a pointer in the margin already maps to the pixel
 *        being displayed there. It now blanks on the one condition that
 *        means no picture: the pixel falls outside the image. The clamp
 *        went too -- it reported the edge pixel's value for a pointer on
 *        empty canvas, a number where there is nothing.
 *        Measured after: 0 columns of visible picture report nothing,
 *        where there were 86 on each side.
 * 1.03  THE STAR MASK GROUP, which is what makes this Pro. The whole
 *        panel is plugged in from ../shared/lib/StarDetect.js rather than
 *        copied -- detection threshold, mask size, star circles and the
 *        mask-source picker are STAR_MASK_PARAMS (rule 98), and the star
 *        engine itself is the one every script in the suite runs.
 *        THREE SETTINGS, because both directions are useful and they are
 *        one sign apart:
 *           Protect stars   corrects the sky and the nebulosity and
 *                           leaves the stars alone, so SCNR stops greying
 *                           out star colour
 *           Stars only      the inverse: fixes magenta or green fringing
 *                           on stars and touches nothing else
 *        Star strength blends between them: at 1 a protected star is
 *        exactly as it was, and lower keeps part of the correction.
 *        Verified: mask 0 gets all the correction under Protect and none
 *        under Stars only, mask 1 the reverse, and the interior is linear.
 *        THE MASK IS PAINTED PER BLOCK, at ctx.scale with ctx.originX/Y
 *        and ctx.y0, because the preview processes a crop at a reduced
 *        scale and a mask built at the wrong geometry does not error -- it
 *        just lands somewhere else on the picture (rule 36).
 *        THE BLEND IS TOWARDS THE CORRECTED COLOUR, all three channels
 *        together, so a partial strength stays on the line between what
 *        the pixel was and what the correction made of it and cannot
 *        invent a colour neither end has.
 * 1.02  THE TWO LABELS HE HAD ALREADY APPROVED ARE BACK. He asked for
 *        ONE term changed -- "Hold nothing" -- and I rewrote all three.
 *        His stated preference is the specification and a taste call
 *        about the other two was never mine to make (rule 84).
 *           Normal            was "Hold nothing", his own suggestion
 *           Hold luminance    restored
 *           Hold the green    restored
 *        THE OLD STRINGS STILL RESOLVE. A stored enum value IS the option
 *        string, so renaming one would read as absent and fall back to
 *        the default, quietly discarding whatever had been selected. The
 *        descriptor carries `aliases` mapping the 1.01 names onto these,
 *        which is the facility rule 8 asks for -- and which only reached
 *        every script when coerceParameterValue was shared, since it had
 *        been sitting in two of ten.
 * 1.01  THE CAST MAP SHOWS WHAT IS LEFT, NOT WHAT WAS THERE. The owner
 *        ran it with Correct = Magenta, saw magenta marks in the map and
 *        read that as a fault. It was not -- the map rendered the cast as
 *        it stood BEFORE the correction -- but his reading is the better
 *        view, and for a reason that settles it: a before-map looks the
 *        same whether the maths works or not, so it cannot fail. The
 *        after-map is black when the correction lands, and anything
 *        visible in it is a pixel that was not fixed. Measured over the
 *        whole cube with Correct = Both, the worst residue is 2.6e-15.
 *        The state before is still one click away: untick Show
 *        transformed.
 *        AND THE TWO PATHS SHARE ONE CORRECTOR NOW. The map used to
 *        measure the cast with code the result path did not run, which is
 *        exactly how a diagnostic comes to describe something the script
 *        does not do.
 *        THE MAGENTA MATHS WAS CHECKED END TO END and holds: every
 *        magenta patch clears, green is untouched when Correct is
 *        Magenta, Correct = Both never raises the green the first pass
 *        lowered (0 pixels in the cube), and nothing clips in any
 *        combination. The luminance is held to 1e-16 on a real cast; it
 *        degrades only as the magenta approaches saturation -- mean error
 *        0.0001 for a shallow cast, 0.0305 for an extreme one -- which is
 *        the same degenerate limit as a pure green pixel, and no more
 *        reachable on a photograph.
 * 2.76  THE AUDIT SELF-TEST FOLLOWS THE SCHEMA. Moving the core
 *        parameters into shared/lib/ParamSchema.js left
 *        verify_check_source.py injecting its faults into lib/Config.js,
 *        which no longer holds them: three breakers found nothing to
 *        break and the whole run aborted. Two checks then reported
 *        "MISSED" because they scanned only Methods.js and Config.js.
 *        Both follow the schema now.
 *        This is the SECOND time that file has been caught by a move --
 *        its own resolve() docstring records the day lib/Engine.js was
 *        shared and the run died the same way. The lesson is in rule 92:
 *        the moment to run a gate is the moment you touch what it
 *        guards, and MOVING a file is touching it.
 *        One correction to my own fix, worth writing down: reading those
 *        scratch copies with newline='' broke every remaining breaker,
 *        because their anchors are written with 
 and Engine.js and the
 *        entry scripts are CRLF. Rule 93 asks for byte-exact endings when
 *        editing the REPOSITORY, where a phantom diff hides a real one;
 *        a throwaway scratch copy wants universal newlines.

 * 2.75  THE CLONING PROCEDURE IS VERIFIED, by doing it rather than by
 *        reading it: the Template was copied, renamed, its identity
 *        edited, and every gate run on the result. Section 2 of
 *        DEVELOPMENT_RULES.md is rewritten to match, and gained the two
 *        steps a clone actually needs that the list did not have -- write
 *        the script's own README, and declare SCHEMA_OVERRIDES rather
 *        than copying the core schema to change one default.
 *        AND IT FOUND check_source.py CRASHING ON EVERY CLONE. The check
 *        that reports a clone still shipping the Template's README read
 *        that file without naming an encoding, so on Windows it met the
 *        first non-ASCII character in it and died with a
 *        UnicodeDecodeError instead of reporting anything -- so a new
 *        author's first audit was a stack trace. The Template itself was
 *        immune, because that check returns early while SCRIPT_ID is
 *        still the placeholder: the one path it guarded was the only
 *        path it could not survive. All 58 file reads in that tool name
 *        their encoding now.
 *        The general form is rule 50's -- a check that cannot report is
 *        worse than no check -- and the specific one is worth its own
 *        sentence: a guard that exempts the reference case is a guard
 *        whose real behaviour is never exercised.

 * 2.74  THE UNIT OF SHARING IS THE DEFINITION, NOT THE FILE, and rule 49
 *        is rewritten to say so. It was written about files and it worked
 *        -- 112 library files became 66 -- and then every audit built on
 *        it called the workspace clean while 2587 lines of duplicated code
 *        sat INSIDE those files, because eleven Methods.js files are the
 *        design and no file-level check looks inside one.
 *        NEW SHARED FILES: ParamSchema.js, MethodRegistry.js, EdgeMap.js,
 *        Circles.js, StretchCurve.js. Config.js is 69 lines where it was
 *        405.
 *        TWO HABITS CAME OUT OF IT, both now in rule 49. A difference of
 *        one VALUE is not a reason to copy 174 lines -- StarMask declares
 *        SCHEMA_OVERRIDES instead of carrying its own core schema. A
 *        difference of one NAME is not a reason to copy 100 lines -- the
 *        harmonic solver takes its sweep count as an argument instead of
 *        existing twice for BLEMISH_SWEEPS and STARSREM_SWEEPS.
 *        THE AUDIT ENFORCES IT: check_workspace.py compares definitions
 *        with comments stripped, since two copies differing only in their
 *        comments are still one piece of code in two places -- which is
 *        how MethodRegistry sat in ten scripts looking like ten different
 *        things. All eleven checks are proved able to fail.
 *        AND THE HARNESSES STOPPED RESTATING WHAT TO LOAD. Moving code
 *        broke eight tools at once, twice, so load_script_maths.js reads
 *        the entry script's own #include lines and loads the maths tier in
 *        the script's own order. It cannot drift from what ships.
 * 2.73  ONE STAR ENGINE FOR THE SUITE. shared/lib/StarDetect.js now
 *        carries the whole pipeline -- matched filter, detector, dedupe,
 *        roundness gate, PSF-fit gate, mask painter -- plus
 *        installStarDetection( engine ), the catalogue driver and the PSF
 *        measurement, installed the same way the shared preview and the
 *        shared dialog are.
 *        THE MEASURED EFFECT: the two scripts that had the older detector
 *        find 221 of 260 planted stars at the default threshold where
 *        they found 204, with false detections at zero before and after.
 *        StarMask, whose engine it is, is bit-identical.
 *        DUPLICATION ACROSS THE WORKSPACE: 2587 redundant lines before
 *        this work, 1195 after. What remains is not star code -- it is
 *        the Config.js plumbing that is identical in all ten scripts, the
 *        edge/detail machinery shared by two, and the curve machinery
 *        shared by two.
 *        A SCRIPT MAY POST-PROCESS THE CATALOGUE by declaring
 *        engine.starCatalogueCorrections( cat ); the driver calls it at
 *        both exits and a script that declares nothing pays nothing.
 *        THE WORKSPACE NOW DECLARES NO EXCEPTIONS AT ALL. The last three
 *        were StarMask's private detector tools, which existed only
 *        because its detector took a signature the others lacked.
 *        verify_check_workspace.py had been stripping the declaration off
 *        one of those very files to prove that check could fail, so it
 *        died with ENOENT when they went -- it manufactures its own
 *        fixture now, because a self-test that needs the workspace to
 *        still contain the fault has an expiry date on it.
 * 2.72  THE SHARED LIBRARY GAINS StarDetect.js, and Utilities.js gains
 *        the separable box blur. Three scripts had byte-identical
 *        copies of the star geometry and the blur; they have one now,
 *        and 1318 duplicated lines came out with no output change
 *        anywhere.
 *        AND THE HARNESSES STOPPED RESTATING WHAT TO LOAD.
 *        shared/tools/load_script_maths.js reads the entry script's own
 *        #include lines and evaluates the maths tier from the real
 *        files, so a tool cannot drift from what ships (rule 39). It
 *        exists because moving three functions broke EIGHT tools at
 *        once, each for the same reason and each needing the same two
 *        lines pasted in.
 *        IT ALSO FOUND A GATE THAT HAD BEEN RED SINCE 2026-08-11.
 *        verify_star_psf.js still read <script>/lib/StarMeasurement.js,
 *        a path that stopped existing when that file was shared, so
 *        every run since died in readFileSync -- and a crash prints no
 *        FAIL line, which is exactly rule 50's second form. The
 *        measurement itself was never wrong: with the path fixed it
 *        recovers 4.21/3.22, 2.46/1.92 and 7.03/5.34, the same figures
 *        it gave before the file moved. Its permissive isValidView stub
 *        is gone too, so it now runs against the real guard.
 * 2.71  THE SHARED PREVIEW ARRIVES, the one developed and measured on
 *        the Deconvolution bench, so every script previews the same
 *        way. What changes here:
 *        THE PREVIEW IS NEVER SOFTER THAN THE SCREEN. The processing
 *        level is the coarsest rung still at least as fine as the
 *        display, instead of the nearest rung either side of it.
 *        Measured on a 9032x6028 frame: an open and two zooms
 *        processed at 1.10x, 1.02x and 1.31x the display size per
 *        axis, and nothing is upsampled at any zoom.
 *        THE VISIBLE REGION IS PUBLISHED FIRST and the pan margin
 *        filled second, so a zoom shows a correct picture without
 *        waiting for 2.5x the canvas.
 *        A DRAG IS NO LONGER EATEN by a refresh that comes due
 *        during it, a double click zooms out, and the pan backdrop
 *        no longer builds its bitmap inside onPaint -- which was
 *        blanking the preview on large frames (rule 87).
 *        TWO NEW #defines carry it. PREVIEW_SCALE_OCTAVE_STEPS 2:
 *        without it the fallback is FULL octaves and a zoom can pay
 *        4x the display pixels. PREVIEW_METHOD_HALO 64: the
 *        conservative reach for this method, where Deconvolution
 *        measured its own at 24. Lower it once this method's reach
 *        has been measured.
 *        PAN_MARGIN is unchanged at 0.75 (rule 81).
 * 2.70  THE PAN CONTRACT IS RESTORED, and the attempt that broke it is
 *        withdrawn. Rule 81 says the margin is 0.75 in every script and is
 *        NEVER the lever for speed; the previous build shrank it for
 *        transforms measured as expensive, and the pan clamp was reported
 *        within the hour -- the fourth report of that one bug. A smaller
 *        margin IS less pan travel, whatever the justification, and no
 *        measurement makes that acceptable. marginSelection no longer even
 *        ACCEPTS an override, and verify_wheel_standin.js now enforces the
 *        rule: no override, no cost test at the render-region choice, and
 *        PAN_MARGIN 0.75 asserted in all ten entry scripts. A rule that
 *        lives only in a document gets broken.
 *        WHAT SURVIVES, because it costs the user nothing: the wheel waits
 *        longer before committing when the transform is expensive (his
 *        report -- one accidental notch, reaching for a pan, used to commit
 *        before it could be scrolled back, and half a minute went with it).
 *        0.3 s for a cheap transform, 1.5 s for an expensive one, decided by
 *        what the last pass measured per visible megapixel. That number
 *        sizes the delay and nothing else.
 *        THE ZOOM FLASH stays fixed (the stand-in now ends at applyPublish,
 *        not when the rebuild starts), and EXECUTE and the STATISTICS are
 *        untouched as always: Execute runs over the target view itself, and
 *        median/MAD come from the full target view cached per view, never
 *        per zoom -- so a stretch places the whole image's median however
 *        far in you are looking. Both are asserted now.
 *        DECONVOLUTION'S ZOOM COST IS THEREFORE STILL OPEN: 540 ms per
 *        megapixel per RL iteration, 6.25x of it for the pan margin. The
 *        honest levers are caching and the cost per pixel, not the margin.
 *        THE DRAWN ZOOM BOX NOW BEHAVES LIKE THE WHEEL (his report: "it
 *        processes first before it actually zooms in, which is
 *        backwards"). Both gestures queue a selection and both wait on the
 *        same rebuild, but only the wheel armed the scaled stand-in, so a
 *        boxed zoom drew the OLD un-zoomed view under the busy cross for
 *        the whole transform and arrived at the new view last. One line;
 *        the checks now assert both paths arm it.
 * 2.69  THE ZOOM FLASH, fixed at the right moment this time (his
 *        report, from video, twice: wheel to zoom, stop, and the
 *        preview SNAPS BACK to where it was, waits out the
 *        transform, then arrives at the zoomed view).
 *        A wheel notch only queues a selection -- the rebuild waits
 *        for wheel-quiet -- so between notch and render the painter
 *        draws the current bitmap SCALED to the queued zoom. That
 *        stand-in is the entire gesture's feedback, and it was being
 *        cancelled at the START of a transform that then runs for
 *        seconds, repainting a busy indicator over whatever the
 *        painter could draw: the old buffer, at the old zoom. The
 *        earlier fix moved that cancellation from the wheel commit
 *        to where rebuildOnce consumes the queued selection -- still
 *        the start of the transform, so the flash survived and was
 *        reported again. The painter now reads standInSelection, a
 *        field of its own that no rebuild touches, and applyPublish
 *        clears it: the one moment the render that replaces it
 *        actually exists. Dropped too when the target changes or a
 *        queued zoom is abandoned, so a stand-in cannot outlive its
 *        image. New check, shared/tools/verify_wheel_standin.js,
 *        asserts the ORDER on the shipped source and goes red on the
 *        exact form that shipped twice.
 * 2.68  NO MORE BOXES AROUND THE LABELS (his report: "all of these
 *        text boxes, whether they're blank or not, have outlines
 *        around them"). The section panel's sheet is set on the box
 *        with BARE declarations -- the form that reliably reaches a
 *        PCL control -- but Qt matches those declarations against
 *        every DESCENDANT too, so `border: 1px solid` was drawing a
 *        rounded rectangle around every label and every empty cell
 *        in the section. The fill still reaches the children, which
 *        was always right; the border is confined to a class
 *        selector, and no border is declared for the rest, since
 *        saying `border: none` there would strip the value boxes and
 *        buttons of the borders the dialog sheet gives them.
 *        US SPELLING THROUGHOUT THE INTERFACE (his report, raised
 *        before): color, not colour, and the same for neutralize,
 *        normalize, center, gray and their relatives. TEXT ONLY --
 *        `colourProtection` and `colour` are PERSISTED SETTINGS KEYS
 *        and keep their spelling, because renaming one orphans every
 *        saved setting and process icon; "centre" is also a drag
 *        state and a property name in the hue wheel.
 * 2.67  THE GLOBAL RESET BUTTON, the one button in the dialog still
 *        wearing the stock look (his screenshot). It is
 *        dialog.resetButton -- one letter from dialog.resetButtons,
 *        the per-row list declared beside it -- and a hand-written
 *        list of the dialog's buttons simply skipped it.
 *        verify_theme_wiring.js now DERIVES that list from
 *        MainDialog's own source, matching every
 *        `this.<name>Button = new ToolButton`, so a button added
 *        there and not styled fails a check instead of a
 *        screenshot; poisoned, it names the missing button.
 * 2.66  THE ICON BUTTONS GET A LIGHT FACE -- the point behind every
 *        "I can barely see the reset buttons" report, finally heard.
 *        PixInsight's icons are drawn DARK, for its light stock
 *        theme; on a dark chip a dark glyph is an EMPTY SQUARE, and
 *        outlining that square in white changes nothing, because the
 *        glyph inside is still dark on dark. His words: stop
 *        outlining things in white, make the thing itself contrast.
 *        So every icon button now has a light face and a quiet grey
 *        edge -- the per-row reset buttons, the dialog's own row
 *        (new instance, execute, cancel, real-time, documentation,
 *        diagnostics), the preview's zoom trio, and THE SECTION BAR
 *        COLLAPSE TOGGLES, which had never been styled at all: PJSR
 *        builds that button inside SectionBar, so nothing in this
 *        codebase held a reference to one until it was reached
 *        through bar.button.
 *        Also: 0.23's drop-down arrow was a CSS border-triangle,
 *        chosen to force it white. On the web that draws a triangle;
 *        Qt fills ::down-arrow as a BOX, so every dropdown showed a
 *        solid white SQUARE -- a regression on an arrow that had
 *        rendered correctly since 0.21. The platform's light arrow
 *        image is back, the compartment's divider is quiet grey
 *        again, and the verifier FAILS if the triangle form returns.
 * 2.65  WHITE ARROWS AND WHITE-EDGED ICON BUTTONS -- his call, asked
 *        for three times while grey after grey was offered instead,
 *        and approved from a drawing before this was built. The
 *        drop-down arrow is drawn as a CSS triangle in #ffffff
 *        rather than loaded from a resource, so there is no asset
 *        path left to fail; the platform's own arrow art is dark,
 *        for light panels. The per-row reset buttons and the
 *        dialog's own icon buttons -- new instance, execute,
 *        cancel, real-time, documentation, diagnostics and the
 *        preview's zoom trio -- carry a white edge on a dark chip.
 *        The chip stays dark deliberately: the glyphs are light,
 *        and a white FILL would erase them. The diagnostic build's
 *        magenta and orange are gone; its counting line is gone
 *        too, but a refusal still warns to the console, because
 *        four silent try/catch blocks are how a fix shipped four
 *        times and changed nothing.
 * 2.64  DIAGNOSTIC BUILD -- THE COLOURS ARE DELIBERATELY WRONG, and
 *        the next build takes them out again. Four attempts to shade
 *        the icon buttons have come back from PixInsight looking
 *        identical, and the pixels cannot say WHY: refused,
 *        ignored, or applied and invisible all look the same. So
 *        the reset buttons are screaming magenta, the dialog's own
 *        icon buttons orange, and themePolish now COUNTS what it
 *        did and prints it -- four silent try/catch blocks in a row
 *        is how a fix ships four times and changes nothing. Three
 *        outcomes, each pointing somewhere different: solid colour
 *        means the sheet reaches the control and only the colour
 *        was ever wrong; a thin coloured RING around the icon means
 *        the icon is drawn over the whole button and no fill can
 *        ever show (the borders have always rendered -- that is the
 *        clue); no colour at all means no style sheet reaches a PCL
 *        ToolButton and the answer is a different mechanism. The
 *        console line reports the counts independently of the
 *        pixels. Rule 82's method, which ended the confetti in one
 *        screenshot after six plausible fixes had failed.
 * 2.63  THE ICON BUTTONS, ON THE ONE FORM PROVEN TO REACH A PCL
 *        CONTROL. Three builds tried to shade the per-row reset
 *        buttons and each left them sunk into the panel in his
 *        screenshots: a dialog-level QToolButton rule, the same
 *        rule with the background shorthand, then a widget-local
 *        sheet wrapped in `*`. Meanwhile the section panels have
 *        been correctly shaded since the pilot -- by a widget-local
 *        sheet of BARE DECLARATIONS. That form is now copied
 *        exactly instead of a fourth variation being invented, and
 *        the verifier asserts the chip sheet carries no selector so
 *        the failing form cannot come back. Accepted cost: bare
 *        declarations cannot express :hover, so these buttons lose
 *        their hover lift -- a button that can be SEEN beats one
 *        that lights up once the pointer is already on it.
 *        THE DIALOG'S OWN ICON BUTTONS get the same chip (his
 *        second report: the row along the bottom "blending into
 *        the dark background") -- new instance, execute, cancel,
 *        real-time, documentation, diagnostics and the preview's
 *        three zoom buttons. The platform paints them transparent,
 *        so on this floor they were icons floating on nothing.
 * 2.62  THE RESET BUTTONS AND THE DROP-DOWN ARROW, ON THE ROUTE THAT
 *        ACTUALLY REACHES THEM (his report on the last build: "I
 *        dont see any of the changes" -- the package carried them,
 *        the controls ignored them). Both were styled by
 *        DIALOG-LEVEL class rules, QToolButton and
 *        QComboBox::drop-down, and those do not reach PCL's
 *        controls -- the same lesson this theme learned twice
 *        before, for the section panels and the popup lists, and
 *        the reason both of those are set WIDGET-LOCALLY. They are
 *        now set the same way: themePolish puts a chip sheet on
 *        every reset button it finds on the dialog, and the arrow
 *        compartment sheet on every picker AND every schema-built
 *        combo (recognised by what it can do, since the method and
 *        Show dropdowns are declared in Config and appear in no
 *        script's picker list). The lift shade goes from one step
 *        above the panel to clearly above it -- the previous value
 *        would have been near-invisible even had it applied.
 *        verify_theme_wiring.js now asserts the sheets ON THE
 *        OBJECTS, not merely that the rules exist: a rule assigned
 *        to nothing is exactly what shipped last time.
 * 2.61  THE BLUE GRID, AND TWO CONTRAST FIXES HE ASKED FOR. The grid
 *        in a value box was never our focus handling: PixInsight's
 *        OWN style sheet (rsc/qss/core-standard.qss) paints these
 *        controls with TILED 9-slice images -- QLineEdit:focus gets
 *        border-image: url(:/qss/border-focus.png) 33% repeat -- and
 *        a light-theme frame repeated across a 20-pixel box renders
 *        as a blue checkerboard over the value. border-image is a
 *        separate property from border, so setting a border never
 *        displaced it. Now turned off by name on every state the
 *        platform sets it on, for line edits, spin boxes, combos,
 *        push buttons and tool buttons; a focused edit takes a plain
 *        accent outline instead. This also retires the "hatched
 *        button" seen in the earliest theme screenshots.
 *        THE DROP-DOWN NOW LOOKS LIKE ONE (his report): the arrow's
 *        compartment is a step lighter than the field with a divider
 *        down its left edge, and the arrow is the platform's LIGHT
 *        glyph -- its own combobox arrow art is drawn dark, for light
 *        panels, and was invisible here. THE RESET BUTTONS (his
 *        report) sit on a chip above the panel with a defined edge:
 *        the platform paints QToolButton transparent, which put them
 *        into the panel. verify_theme_wiring.js asserts all of it.
 * 2.60  THE FOCUS GRID IN A VALUE BOX, root cause found in the
 *        platform's own header (his UnsharpMaskPro screenshot: the
 *        Star detection value box filled with a blue dither).
 *        Shared Compat.js resolved FOCUS_CLICK to 0x01 -- and
 *        pjsr/FocusStyle.jsh says 0x01 is FocusStyle_Tab; Click is
 *        0x02. PJSR declares these as preprocessor defines, so the
 *        runtime probes never resolve and the fallback IS the
 *        value. Every value edit the theme made "click-only" was
 *        therefore made the dialog's FIRST TAB STOP, so the
 *        opening focus landed on one and painted its focus marks
 *        over the number -- the artifact rule 82 part 3 exists to
 *        prevent, delivered inverted. The constant now comes from
 *        the header, with FOCUS_NONE and FOCUS_WHEEL checked
 *        against it too, and verify_theme_wiring.js asserts all
 *        three so the value cannot drift back. The preview's
 *        FOCUS_CLICK|FOCUS_WHEEL becomes click+wheel as intended
 *        (it was tab+wheel), which also takes it out of the tab
 *        chain.
 * 2.59  THE DARK THEME SUITE-WIDE (rule 82): every script includes
 *        Theme.js, applies applyTheme before construction and runs the
 *        themePolish one-shot naming its hand-built controls. Shared
 *        MainDialog: the Target view picker is the themed combo
 *        (makeViewCombo) when the Theme include is present -- ViewList's
 *        closed face is core-painted past any style sheet, proven by
 *        the pilot's orange-selection diagnostic -- with the stock
 *        ViewList as the no-include fallback; both branches drive one
 *        chooser, and updateViewLists reloads the combo truthfully.
 *        Shared ParamControls lists every per-row reset button on the
 *        dialog as it builds them (they are born in one place and
 *        handed to a sizer, so nothing could reach them before), and
 *        themePolish takes them NoFocus with the rest. The dialog
 *        harness is now importable -- buildDialog(root, opts) --
 *        rather than restated by each verifier that needs it, and
 *        shared/tools/verify_theme_wiring.js uses it to prove the
 *        theme is actually wired in every script.
 * 2.58  Shared PreviewControl: the wheel-zoom stand-in HOLDS THROUGH
 *        THE REBUILD -- the pending flag clears where rebuildOnce
 *        consumes the pending selection, so the display goes stand-in
 *        to finished render with no detour through the stale view (the
 *        user's video: zoom, snap BACK, think, then the new view). This
 *        entry is written in arrears: the 2.58 build shipped with the
 *        version bump alone, against rule 65.
 * 2.57  Shared PreviewControl: A REBUILD MAY NOT PUBLISH UNDER AN OPEN
 *        DRAG -- the transform pumps events, so a drag can BEGIN while a
 *        rebuild runs, and 2.56's entry guard could not stop the
 *        IN-FLIGHT rebuild from replacing the view mid-gesture (the
 *        user's zoom box, eaten a third way; near-certain on scripts
 *        whose transforms take seconds). A rebuild finishing mid-drag
 *        parks its result (heldPublish); the gesture's end APPLIES it
 *        when nothing superseded it (cancel, empty box) or FREES it when
 *        the gesture's own rebuild replaces it (box, pan). One publish
 *        implementation (applyPublish) serves both paths. With the entry
 *        guard, gesture protection now closes BOTH ends of the pipeline.
 * 2.56  Shared PreviewControl, two gesture fixes from live testing.
 *        (1) The 2.55 wheel-zoom feedback anchored the bitmap on the
 *        VISIBLE selection; the render carries the pan margin, so the
 *        view jumped by exactly that margin ("flashes to a different
 *        area") -- anchored on renderSelection now. (2) THE GESTURE
 *        GUARD LIVES IN rebuild() ITSELF: any request arriving during a
 *        drag defers into the pending queue and every drag end flushes
 *        it, and a drag that begins mid-rebuild (applyMethod pumps
 *        events) halts the queue until it ends. The first zoom-box fix
 *        guarded only the dialog's debounce timer -- one caller of many
 *        -- and the box kept being eaten (reported twice; suspend at the
 *        choke point, never guard callers).
 * 2.55  Shared PreviewControl: WHEEL ZOOM COMMITS ON WHEEL-QUIET (the
 *        user's call -- each notch used to rebuild immediately, stealing
 *        the gesture mid-scroll). Notches accumulate on the pending
 *        selection, the paint draws the current bitmap scaled to the
 *        pending zoom as live feedback (rule 71), and ONE rebuild runs
 *        0.3 s after the last notch; any mouse press commits first so a
 *        click never acts on an uncommitted view. Armed-mode wheel
 *        (circle sizing) is untouched.
 * 2.54  Shared MainDialog: the default per-control layout is CALLABLE --
 *        layoutGeneratedControls(box, list), extracted verbatim from the
 *        section loop -- so a section's `extra` builder can compose the
 *        schema rows around a hand-built row (UnsharpMaskPro 2.00 puts
 *        its star mask source ViewList inside Masks this way) instead of
 *        restating the layout logic and drifting from it. A slice that
 *        starts with an inlineWithPrevious control falls back to its own
 *        row; split after the row it rides.
 * 2.53  THE TEMPLATE IS A PRODUCT (rule 80, written this build): the
 *        workspace's two goals are the owner's own scripts AND this
 *        Template as a generic product for strangers -- so every
 *        personal reference was swept out of the Template family
 *        (this file, the rules, PUBLISHING.md, the shared library and
 *        tools): war stories say "the user", PUBLISHING's worked
 *        example uses a <Brand> placeholder, and the packager's
 *        --install-dir is REQUIRED so no one publishes under someone
 *        else's brand by default. Comment-only sweep: no behaviour
 *        change anywhere; sibling scripts keep their versions.
 * 2.52  Shared Engine: EXECUTE WRITES ANY DISPLAYED VIEW (the user's
 *        call: viewing an edge map and wanting an image of it is a
 *        legitimate ask -- "we do not need a restriction"). The
 *        validateForExecution guard that blocked diagnostic views, and
 *        the executableMapViews exemption StarMask motivated, are both
 *        removed: the run is one undoable process step, so the worst
 *        mistake costs one Ctrl+Z, and execute() notes to the console
 *        when the output is a diagnostic view so what was written is
 *        never a mystery. diagnosticViews stays -- it still drives the
 *        screen-stretch guard (rule 32) and the audit's view
 *        declarations.
 * 2.51  Shared AutoStretch: computeAutoStretch reads the NATIVE
 *        median/MAD first (image.median()/image.MAD(), the same
 *        native-first-with-histogram-fallback pattern
 *        engineSourceStatistics has carried since it chased a PixelMath
 *        discrepancy) -- the JS histogram is two full-frame passes per
 *        channel, so a color-frame stretch derivation cost twelve, and
 *        that was most of StarMask's 49-second stars-only mask build
 *        (0.24, rule 77: when the codebase already holds the fast form
 *        of a computation, a second call site doing it the slow way is
 *        a defect, not a style choice).
 * 2.50  Shared changelog, two changes, both from StarMask 0.23's reports.
 *        PreviewControl: THE MAP GUARD BELONGS TO THE TRANSFORMED BUFFER,
 *        NOT TO THE STRETCH -- producesDiagnosticMap() used to null
 *        currentStretch() outright, so with a map view selected and Show
 *        transformed OFF the plain picture displayed unstretched beside a
 *        ticked Screen stretch box. The stretch is now always computed
 *        and applied to the untransformed picture; only the transformed
 *        copy skips it when the engine says the transform is a map
 *        (transformIsMap(), asked per buffer at both build sites).
 *        AutoStretch: stretchLinkedRow( H ) -- the one row that carries a
 *        linked stretch is row 3 (RGB/K), with rows 0-2 identity; a
 *        caller plucking H[0] gets the red channel's IDENTITY row and a
 *        transfer that does nothing, which is exactly how StarMask's
 *        stars-only baseline shipped unstretched. The helper owns the
 *        row convention where the shape is defined; callers name the
 *        meaning, not the index.
 * 2.49  Shared changelog, two changes. MainDialog: a section with no
 *        schema-generated controls still builds when it declares an
 *        `extra` builder -- skipping on empty descriptors silently
 *        deleted StarMask's hand-built stars-only section, and the user
 *        asked for a feature that had already shipped because its bar
 *        never existed (rule 54's boundary: the dialog-builds check
 *        constructs, it does not see). PreviewControl: the
 *        onCursorRadiusWheel hook -- while pick mode is armed, wheel
 *        notches size the placement circle instead of zooming (the
 *        user's spec: adjust on the fly, and zoom must not fire in that
 *        mode); null keeps wheel zoom exactly as before, so only scripts
 *        that wire it change.
 * 2.48  Shared changelog: the preview debounce timeout DEFERS WHILE A
 *        DRAG IS ACTIVE. It used to fire unconditionally, so a refresh
 *        queued by a slider commit could land mid-zoom-box, block the
 *        event loop for the length of a rebuild, and eat the drag --
 *        reported on StarMask ("it wants to process before I can finish
 *        the drag"), structural in every script, felt only where the
 *        rebuild is slow. The timeout now restarts itself while
 *        imagePreview.dragging is true and fires after the gesture ends;
 *        pending stays true throughout, so the refresh is delayed, never
 *        dropped (rule 17 extended to gestures).
 * 2.47  Shared changelog: PreviewControl gains the PLACEMENT GHOST --
 *        cursorCircleRadius, a host-set function returning the radius in
 *        image pixels a click would commit; while pick mode is armed the
 *        paint draws that circle under the pointer (32 drawLine segments,
 *        proven primitives only), tracking every mouse move and slider
 *        change live. Null by default: a script that sets nothing behaves
 *        exactly as before. Built for BlemishRemover 1.17 and the StarMask
 *        manual-correction feature, at the user's direction: the size must
 *        be visible and adjustable BEFORE the click.
 * 2.46  Shared changelog: Engine gains executableMapViews -- a map view a
 *        script declares as its PRODUCT is unstretched on display like any
 *        diagnostic (rule 32) but stays legal to Execute; empty by default,
 *        so every existing script behaves identically. check_source's
 *        show-option check learned engine.pictureViews, declared deliberate
 *        picture views. Both born of the StarMask script, whose result IS a
 *        map.
 * 2.45  Per-parameter reset button at the end of every slider row (shared
 *        ParamControls), matching PixInsight's own convention: click
 *        restores the schema default and refreshes the preview.
 * 2.44  The shared library changed under every script and the Template
 *        records it: ParamControls rounds integer sliders after the curve
 *        and honors commitOnRelease (rule 62); safeForceClose accepts
 *        windows as well as views (rule 63). Warnings written at the two
 *        per-script constants whose safe value scales with method cost:
 *        PREVIEW_DEBOUNCE_SECONDS and PAN_MARGIN. commitOnRelease joined
 *        the documented descriptor vocabulary in Config.js.
 * 2.43     The screen stretch target is labelled "Background target", which is
 *          what the number is: the background level the stretch aims for.
 * 2.42     TARGET BACKGROUND FOR THE SCREEN STRETCH, beside the mode in the
 *          preview header, default 0.20 (the old fixed constant was 0.25).
 *          Shared change: the target is a parameter of computeAutoStretch,
 *          part of the stretch cache key, and a NumericEdit in the shared
 *          dialog. View STF ignores it, as that mode uses the view's own
 *          transfer function. Verified: on a real frame the midtone moves
 *          monotonically with the target and nothing else changes.
 * 2.41     Transfer curve moved above Output options; Output options and Preview
 *          dimensions start folded away
 * 2.40     Vertical pan travel matches horizontal. The render margin was sized from
 *          the selection, so wherever the selection was shorter than the control
 *          the margin went on covering that inset instead of giving travel -- 44%
 *          of a view on a 1600x900 selection, none at all on an extreme aspect.
 *          Sized from the control it is 75% in both axes at every aspect
 * 2.39     Pan clamped to the control rather than to viewPort(), which is the
 *          selection centred in the control and therefore inset wherever the
 *          selection is smaller than the control. That inset was the strip of
 *          empty canvas at the end of a drag -- 30 px on a full frame -- and it
 *          appeared in whichever axis had the slack
 * 2.38     The end of a pan showed empty canvas. The clamp measured the rendered
 *          margin in image coordinates, which exceeds what the bitmap covers by
 *          the slack between the fitted selection and the viewport -- 192 px for
 *          a 1600x900 selection in a 1024x768 preview. It now clamps to the
 *          bitmap's own extent
 * 2.37     Pan margin 0.75, so a drag from anywhere but hard against an edge runs its
 *          full length without stopping to rebuild
 * 2.36     Pan travel doubled. A drag is clamped to the rendered margin, which was a
 *          quarter of a view and now is half, so it stops to rebuild half as often
 * 2.35     Slider travel can be curved, for a parameter whose useful values sit at
 *          one end of a wide range
 * 2.34     Opening with the screen stretch on showed an unstretched image beside a
 *          ticked box: setImage discarded the stretched copies and nothing
 *          rebuilt them, so only toggling the box made the two agree
 * 2.33     Temporal dead zone check now sees nested blocks. A `let` used inside an
 *          `if` above its own declaration parsed, passed the check, and threw
 * 2.32     A parameter key passed as a string was Americanised by the spelling pass,
 *          silently disabling a control. Audit now checks every key-string lookup
 * 2.31     US spelling in everything a user reads, matching PixInsight's own UI.
 *          Parameter keys keep the British spelling on purpose: renaming one
 *          would make saved instances fall back to defaults without an error
 * 2.30     Dead mask machinery removed: the ProtectionMask subsystem and the per-view
 *          mask registry, ~250 lines that could never run. The preview now honours
 *          a user's mask, which a flag that was always false had prevented
 * 2.29     Ancestor string removed from the label column; audit checks that a
 *          clone is not shipping the Template's README
 * 2.28     Label column measured from the schema instead of a hardcoded sample
 *          string, so a long label no longer pushes its own control out of line
 * 2.27     Audit gains a check for a parameter group with no matching section
 * 2.26     Preview size labels share one column; audit gains a check for an
 *          object used but never declared, which a clone had lost
 * 2.25     Self-test breakers no longer hardcode the entry script name or
 *          the Template identity values, so a clone can run its own
 * 2.24     Section `extra` builders are actually called: the preview custom
 *          size numbers sat on two rows because the hook was never wired
 * 2.23     PUBLISHING.md and tools/build_update_package.py: repository distribution
 * 2.22     Attribution moved to the dialog header and declared once, as a define
 * 2.21     Icon path corrected: @script_icons_dir is per script, and an
 *          update package can deploy it -- both measured, not assumed
 * 2.20     Process icon is made last, not during cloning; letters as paths
 * 2.19     The process icon documented: #feature-icon, where the SVG lives,
 *          and what a rename leaves behind
 * 2.18     Audit reads the #feature-* directives: they are stripped before
 *          every other check and a wrong feature-info shipped three times
 * 2.17     Ancestor residue swept; audit gains field, ALL_CAPS and
 *          placeholder-identity checks; rule 34 on residue vs design
 * 2.16     Generic identity: ATTRIBUTION is asked for, not assumed; the
 *          rules open with a section addressed to the assistant reading them
 * 2.15     Consolidation: METHOD_INFO, the two-pass protocol, the
 *          overlay hook, the background estimator and lazy statistics
 * 2.14     The preview publishes its state atomically, so no paint can see a
 *          half-finished rebuild
 * 2.13     The screen stretch appeared to switch itself off after a zoom
 * 2.12     The preview was one rebuild behind whenever the screen stretch
 *          was on: a stale bitmap cache
 * 2.11     A drawn bug icon for the diagnostics button, moved to the right
 * 2.10     Diagnostic maps skip the screen stretch; labelWidth restored
 * 2.09     Preview rendered before the layout had applied the new size
 * 2.08     Custom width and height sit together instead of at opposite ends
 * 2.07     The preview is rebuilt after an in-place Execute
 * 2.06     Preview size as a dropdown, custom width and height on one row
 * 2.05     Rules 28 and 29: ES6 widget classes, and the proven drawing calls
 * 2.04     Highlight stage tabulated: 9x faster
 * 2.03     Carry screen stretch removed, with the engine and AutoStretch
 *          code that only it used
 * 2.02     Apply to target image is the default; Create new image is not
 * 2.01     Highlights control: 1.0 leaves the bright end alone, lower brings
 *          it down. Replaces Highlight recovery, which read the other way.
 * 2.0      First release build. Single method, statistics measured exactly,
 *          color as a blend of two stretches with gamut walk-back, highlight
 *          recovery and white point both anchored on the target background.
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    SCNRPro : Another Astro Channel > SCNR Pro


#feature-icon  @script_icons_dir/SCNRPro.svg
#feature-info  Removes a green or magenta cast without discarding the signal that carries it, and without clipping.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder, and it is the author's to decide:
 *
 *    ASSISTANTS -- ASK, DO NOT ASSUME. The person you are building for owns
 *    this line. Ask them what name and year they want, or whether they want no
 *    attribution at all, in which case set it to "" and the panel simply starts
 *    with the description. Do not copy a name out of an example, another
 *    script, or this file's history. Guessing here puts someone else's name on
 *    the user's work.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "SCNR-Pro"
#define VERSION     "1.09"
#define SCRIPT_ID   "SCNRPro"
#define KEYPREFIX   "SCNRPro"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Neutralises a green or magenta cast by choosing what stays fixed: the brightness, or the signal itself. Nothing clips."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
/*
 * 0.75 IN EVERY SCRIPT, AND THE MARGIN IS NEVER THE LEVER -- rule 81.
 *
 * The rendered buffer is the canvas plus this margin on every side, so 0.75 is
 * a 6.25x pixel budget -- 2.5x the canvas in each axis -- and every one of
 * those pixels goes through the method.
 * The temptation to trim it on an expensive transform is real and it has been
 * acted on three times, in three scripts; each time the user reported the same
 * defect, because a smaller margin IS less pan travel whatever the reason for
 * it. Measured once at the other extreme: 0.75 turned a 4.9 s transform into a
 * 33 s zoom, and that is the accepted price until the script has a cache.
 *
 * When the transform costs seconds, the levers are the cost per pixel and
 * CACHING what has already been computed. This number is not one of them.
 */
#define PAN_MARGIN               0.75

/*
 * The reach of this script's method, in BUFFER pixels at the processing level.
 *
 * The preview renders the visible region PLUS this, publishes it, and fills the
 * pan margin afterwards -- so it is what makes the visible pixels correct
 * without waiting for the margin. Too small shows as a SEAM; too large only
 * costs a few pixels, so the safe direction is up.
 *
 * 64 is the conservative default, and deliberately generous. Deconvolution
 * MEASURED its own reach at 24 -- the error against an untiled result is 0.00
 * sigma there (verify_halo_sufficiency.js) -- and no other method in this suite
 * reaches as far as a twenty-iteration Richardson-Lucy. Measure it for this
 * method and lower it when there is a reason to.
 */
#define PREVIEW_METHOD_HALO          64

/*
 * How many processing levels per factor of two. ONE CONSTANT, TWO COSTS
 * (rule 72).
 *
 * The preview processes at a fixed ladder of scales and takes the coarsest rung
 * that is still at least as fine as the display, so what is shown is never
 * softer than the panel it is drawn on. This sets how far apart the rungs are:
 *
 *    1  full octaves   a zoom landing just under a rung pays up to 4x the
 *                      display pixel count, about 2.04x on average
 *    2  half octaves   at most 2x, about 1.44x on average
 *
 * 2, measured on a 9032x6028 frame: an open and two zooms processed at 1.10x,
 * 1.02x and 1.31x the display size per axis. Full octaves were tried on the
 * Deconvolution bench and cost 3.26x the AREA at a zoom just under a rung.
 */
#define PREVIEW_SCALE_OCTAVE_STEPS   2

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
/*
 * The highlight stage is a pure function of one value, so it is tabulated once and
 * read back per pixel rather than recomputed. Math.pow costs a factor of nine on
 * the whole transform: 16.5 Msamples/s computing it against 147 with the table.
 *
 * ROLLOFF_DIRECT_BELOW exists because r^H has an infinite derivative at zero, so
 * interpolation is poor near black -- a uniform table over [0,1] is out by 1.0e-4
 * there, which is 1600 times float32 resolution. Below the cut the value is
 * computed exactly instead. At 0.01 the worst error over the whole range falls to
 * 1.9e-9, and almost nothing in a stretched frame sits that low, so the speed is
 * kept.
 */

#define STATISTICS_BINS          1048576

/*
 * How close the target background must be to the image median before the
 * proportional method treats the request as "leave it alone". Measured as a
 * fraction in log ratio: 0.10 means a 10 percent move already gets about 60
 * percent of the full stretch, and a 25 percent move about 90 percent.
 */
#define STRETCH_NOOP_TOLERANCE   0.10

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
#define CURVE_PLOT_HEIGHT        200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
// RULE 62. 0.25 is right for a method whose rebuild costs a fraction of a
// second, like this Template's example. If YOUR method's rebuild costs more,
// raise this beyond hesitation length (Deconvolution runs at 0.8) and put
// commitOnRelease: true on the heavy parameters' descriptors, or the preview
// fires mid-drag, blocks the event loop, and the slider freezes under the
// user's finger. Reported once as "it detaches as soon as I pull it".
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
/*
 * THE STAR ENGINE'S CONSTANTS, the same values every script in the
 * suite gives it. shared/lib/StarDetect.js reads them, and
 * check_workspace.py fails any script that includes that file without
 * defining every name it reads (rule 49).
 */
#define STAR_WINDOW              8
#define STAR_BACKGROUND_RADIUS  20
#define STAR_NOISE_BINS          16
#define STAR_ALPHA_FACTOR        2.0
#define STAR_ALPHA_SAMPLE_MIN    50
#define STAR_SEEING_AMP_MIN      30
#define STAR_WALK_RADIUS         3
#define STAR_NOISE_SCALE         2
#define STAR_ELLIPSE_ARMS        16
#define STAR_TURN_TOLERANCE      2.0
#define STAR_SAMPLE_ROWS         400
#define STAR_NOISE_SAMPLES       50000
#define STAR_DETECT_SIGMA        20
#define STAR_FIT_MIN             8
#define STAR_FIT_MAX             150
#define STAR_CANDIDATE_SLACK     20
#define STAR_SATURATION          0.999
#define STAR_CORE_RADIUS         3
#define STAR_BLEND_FRACTION      0.30
#define STAR_PROFILE_BINS        32
#define STAR_BIN_MIN             5
#define STAR_MOMENT_SEED         2.0
#define STAR_MOMENT_ITERATIONS   12
#define STAR_MOMENT_CUTOFF       9
#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

#define MOFFAT_BETA_COARSE       0.20
#define MOFFAT_BETA_MAX          9.0
#define MOFFAT_BETA_MIN          1.2
#define MOFFAT_BETA_STEP         0.02
#define MOFFAT_FWHM_COARSE       0.10
#define MOFFAT_FWHM_MAX          12.0
#define MOFFAT_FWHM_MIN          1.2
#define MOFFAT_FWHM_STEP         0.01

#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/StarMeasurement.js"
#include "lib/StarDetect.js"
#include "lib/AutoStretch.js"
#include "lib/StretchCurve.js"
#include "lib/MethodRegistry.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamSchema.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
