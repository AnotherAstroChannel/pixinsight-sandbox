/*
 ****************************************************************************
 * Contrast Limited Adaptive Histogram Equalization
 *
 * CLAHE.js
 *
 * Local contrast enhancement by Contrast Limited Adaptive Histogram
 * Equalization. The image is divided into tiles, a clipped histogram
 * equalisation is derived for each, and the mappings are interpolated between
 * tile centres so no tile boundary is visible.
 *
 * Built on the PixInsight Script Template. The maths lives in lib/Methods.js and
 * the parameters in lib/Config.js.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.38     Slider travel can be curved, for a parameter whose useful values sit at
 *          one end of a wide range
 * 1.37     Opening with the screen stretch on showed an unstretched image beside a
 *          ticked box: setImage discarded the stretched copies and nothing
 *          rebuilt them, so only toggling the box made the two agree
 * 1.36     Temporal dead zone check now sees nested blocks. A `let` used inside an
 *          `if` above its own declaration parsed, passed the check, and threw
 * 1.35     A parameter key passed as a string was Americanised by the spelling pass,
 *          silently disabling a control. Audit now checks every key-string lookup
 * 1.34     US spelling in everything a user reads, matching PixInsight's own UI.
 *          Parameter keys keep the British spelling on purpose: renaming one
 *          would make saved instances fall back to defaults without an error
 * 1.33     Dead mask machinery removed: the ProtectionMask subsystem and the per-view
 *          mask registry, ~250 lines that could never run. The preview now honours
 *          a user's mask, which a flag that was always false had prevented
 * 1.32     Ancestor string removed from the label column; new README check
 * 1.31     Label column measured from the schema instead of a hardcoded sample
 *          string, so a long label no longer pushes its own control out of line
 * 1.30     Audit gains a check for a parameter group with no matching section
 * 1.29     Header text rewritten: the acronym is broken down first and the
 *          comparison with LocalHistogramEqualization is gone
 * 1.28     Preview size labels share one column; audit gains a check for an
 *          object used but never declared, which a clone had lost
 * 1.27     Audit gains a class-method check
 * 1.26     tools/package.py builds an update package for a repository
 * 1.25     Attribution moved to the dialog header and declared once, as a define
 * 1.24     Menu and title now Contrast (CLAHE); custom icon; header notes
 *          the difference from LocalHistogramEqualization
 * 1.23     Menu group: Another Astro Channel, out of Utilities
 * 1.22     Audit reads the #feature-* directives
 * 1.21     Feature-info corrected: it still described the script as a template
 * 1.20     Audit gains field, ALL_CAPS and placeholder-identity checks
 * 1.19     scriptWarn/suppressWarnings restored; DESCRIPTION is live again
 * 1.18     The preview publishes its state atomically, so no paint can see a
 *          half-finished rebuild
 * 1.17     The screen stretch appeared to switch itself off after a zoom
 * 1.16     The preview was one rebuild behind whenever the screen stretch
 *          was on: a stale bitmap cache
 * 1.15     A drawn bug icon for the diagnostics button, moved to the right
 * 1.14     Diagnostic maps skip the screen stretch; labelWidth restored
 * 1.13     Preview rendered before the layout had applied the new size
 * 1.12     Custom width and height sit together instead of at opposite ends
 * 1.11     The preview is rebuilt after an in-place Execute
 * 1.10     Preview size as a dropdown, custom width and height on one row
 * 1.09     Trimmed the header text to two paragraphs
 * 1.08     Header text in METHOD_INFO, with attribution; labels capitalised
 * 1.07     Carry screen stretch removed, with the engine and AutoStretch
 *          code that only it used
 * 1.06     Apply to target image is the default; Create new image is not
 * 1.0      First build, derived from the template at v1.21
 * 1.01     Interpolate between histogram bins: the nearest-bin lookup was
 *          collapsing 64 input levels onto each output
 * 1.02     Show tiles overlay
 * 1.03     Conservative defaults: 24 tiles, contrast limit 1.0, amount 0.5
 * 1.04     Trimmed the header text; Clip limit renamed Contrast limit
 * 1.05     Shed template leftovers; statistics measured only when read
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    CLAHE : Another Astro Channel > Contrast (CLAHE)
#feature-icon  @script_icons_dir/CLAHE.svg


#feature-info  Local contrast enhancement by contrast limited adaptive histogram equalization.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Contrast (CLAHE)"
#define VERSION     "1.38"
#define SCRIPT_ID   "CLAHE"
#define KEYPREFIX   "CLAHE"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
/*
 * Kept for the template contract, but the dialog no longer prints it: the
 * method's own one-line description says the same thing, in the same place,
 * without repeating itself.
 */
#define DESCRIPTION "Local contrast enhancement by contrast limited adaptive histogram equalization."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas. 0.25 costs about 2.25x the
 * preview pixels, which at roughly a megapixel is not worth economising on.
 */
#define PAN_MARGIN               0.25

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
#define STATISTICS_BINS          1048576

/*
 * Maximum chroma gain at full saturation. The soft limiter that prevents
 * clipping tapers as chroma approaches the available headroom, so the delivered
 * gain is well below this on bright pixels. 8 is the knee: 3 -> 8 buys about 45%
 * more separation, 8 -> 12 only another 12%.
 */
/*
 * Histogram resolution per tile. Astronomical data is smooth, so 256 bins band
 * visibly; 1024 costs 4 KB per tile and does not.
 */
#define CLAHE_BINS               1024

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/MainDialog.js"

/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
