/*
 ****************************************************************************
 * ZoneContrast
 *
 * ZoneContrast.js
 *
 * Adds or removes contrast within a chosen zone of brightness. The zone is
 * positioned in units of noise sigma above the measured sky level, so one setting
 * means much the same thing on different images.
 *
 * The name is deliberate: this works on a tonal zone, not a spatial one. A
 * pixel's fate depends only on how bright it is, never on what is next to it,
 * which is the opposite of what "local contrast" means in this field.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.24     Menu group: Another Astro Channel, out of Utilities
 * 1.23     Custom process icon: #feature-icon and icons/<name>.svg
 * 1.22     Audit reads the #feature-* directives
 * 1.21     Feature-info corrected: it still described the script as a template
 * 1.20     Dead __histogram cache invalidation removed; three new audit checks
 * 1.19     Audit gains a nineteenth check: members assigned but never called
 * 1.18     The preview publishes its state atomically, so no paint can see a
 *          half-finished rebuild
 * 1.17     The screen stretch appeared to switch itself off after a zoom
 * 1.16     The preview was one rebuild behind whenever the screen stretch
 *          was on: a stale bitmap cache
 * 1.15     A drawn bug icon for the diagnostics button, moved to the right
 * 1.14     Diagnostic maps skip the screen stretch; labelWidth restored
 * 1.13     Preview rendered before the layout had applied the new size
 * 1.12     Custom width and height sit together instead of at opposite ends
 * 1.11     The preview is rebuilt after an in-place Execute
 * 1.10     Preview size as a dropdown, custom width and height on one row
 * 1.09     Defaults 2.5 / 2.5 / 2.5
 * 1.08     Band Center and Band Width; header text and attribution
 * 1.07     Apply to target image is the default; Create new image is not
 * 1.0      First build, from the template at v2.01
 * 1.01     Histogram behind the curve, and the slope drawn as its own line
 * 1.02     Sky level from a quantile with a one-sided noise scale, both
 *          corrected for the quantile; the plot says why it has no curve
 * 1.03     Restored suppressWarnings; diagnostics read the schema instead of
 *          naming parameters; two new audit checks that would have caught both
 * 1.04     Show sigma map; the plot marks the quantile sky level, not the
 *          whole-image median, and captions it with the numbers
 * 1.05     Quantile fixed at 0.25 rather than exposed; carry screen stretch
 *          removed, with the engine and AutoStretch code it alone used
 * 1.06     Sigma map removed; header text moved to METHOD_INFO in Methods.js
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    ZoneContrast : Another Astro Channel > ZoneContrast
#feature-icon  @script_icons_dir/ZoneContrast.svg


#feature-info  Adds or removes contrast within a chosen zone of brightness.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "ZoneContrast"
#define VERSION     "1.24"
#define SCRIPT_ID   "ZoneContrast"
#define KEYPREFIX   "ZoneContrast"
#define DESCRIPTION "Adds or removes contrast within a chosen zone of brightness."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas. 0.25 costs about 2.25x the
 * preview pixels, which at roughly a megapixel is not worth economising on.
 */
#define PAN_MARGIN               0.25

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
/*
 * Resolution of the band curve lookup table. The curve is the normalised
 * integral of a gain function, which has no closed form, so it is integrated
 * once in prepare() and read back per pixel.
 *
 * 65536 entries is 256 KB and matches 16-bit input exactly, so nothing is lost
 * to quantisation. Entries are interpolated on read regardless: taking the
 * nearest entry of a 1024-entry table cost a related script most of its output
 * levels before it was noticed.
 */
/*
 * Which quantile of the pixel distribution is taken as the sky level.
 *
 * Not a user control. Centre and Width can reach any absolute band whatever this
 * is -- it is a reparameterisation, not extra reach -- so exposing it only asks
 * the user to tune a number with no visible effect on the frame in front of them.
 *
 * What it does buy is that a setting means the same thing on the next image, and
 * that only holds if the noise estimate is sound. 0.25 holds to within 40% of the
 * true sigma on a field half filled with nebulosity, where the median is already
 * three times out.
 */
#define BACKGROUND_QUANTILE      0.25

#define BAND_LUT_SIZE            65536

#define STATISTICS_BINS          1048576

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_LABEL_WIDTH      78
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
#define CURVE_PLOT_HEIGHT        200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * colour value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/CurvePlot.js"
#include "lib/Engine.js"
#include "lib/MainDialog.js"

/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
