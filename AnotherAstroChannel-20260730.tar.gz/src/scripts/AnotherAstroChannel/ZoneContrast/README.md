# ZoneContrast for PixInsight

Copyright (c) 2026 Bill Blanshan. Released under the GNU General Public License
version 3.

Adds contrast to a chosen band of brightness and takes it from everywhere else,
or the reverse.

Built on the PixInsight Script Template. The maths lives in `lib/Methods.js`;
everything else is the template's generic machinery.

## The black point is not the median

The median of a whole frame is only the sky level if most of the frame is sky. On
a field filled with nebulosity it is not: signal drags it upward, a background
taken from it sits inside the nebula, and the noise scale measured around it is
inflated by real structure.

So the sky level is read off a **chosen quantile**, excluding pure black and pure
white, and the noise is measured **only from pixels at or below it** so that
nebulosity cannot widen it.

The quantile is fixed at **0.25** and is not a control. Centre and Width can reach
any absolute band whatever it is set to -- it is a reparameterisation, not extra
reach -- so exposing it only asks for a number with no visible effect on the frame
in front of you. What it does buy is that a setting means the same thing on the
next image, and 0.25 holds to within 40% of the true sigma on a field half filled
with nebulosity, where the median is already three times out.

Both figures are corrected for the quantile, which matters: the 25th
percentile of Gaussian sky sits 0.6745 sigma *below* the sky level, and the
deviation measured from that point is not the MAD either. With

```
sigma = ( Q(q) - Q(q/2) ) / ( z(q) - z(q/2) )
sky   = Q(q) - z(q) * sigma
```

both are unbiased at any quantile, and at `q = 0.5` the divisor is
`z(0.5) - z(0.25) = 0.6745` — so it collapses to the familiar `1.4826 * MAD`
around the median. That the general form reduces to the known case is the check
that it is right.

Measured on a simulated field, sky 0.20000 and sigma 0.006000:

| nebulosity | q=0.50 sky / sigma | q=0.25 sky / sigma | q=0.10 sky / sigma |
|---|---|---|---|
| 0% | 0.19999 / 0.005984 | 0.20004 / 0.006058 | 0.19988 / 0.005931 |
| 25% | 0.20260 / 0.007662 | 0.20202 / 0.006800 | 0.20157 / 0.006428 |
| 50% | 0.21208 / **0.017919** | 0.20572 / 0.008490 | 0.20423 / 0.007238 |
| 70% | 0.30433 / **0.146560** | 0.21508 / 0.014242 | 0.20896 / 0.009029 |

All three agree on clean sky, which is the point of the correction. As nebulosity
fills the frame the median's noise estimate runs away — 24x too large at 70%
coverage — while a lower quantile holds. The console diagnostics print the estimate at several quantiles side by side, so
the difference between them tells you directly whether the frame is crowded. If
0.50 disagrees badly with 0.25, the median is not finding the sky.

## Why the band is measured in sigma

A hand-drawn curve puts contrast where you draw it, in absolute brightness. That
setting does not carry to another image, or even to the same image at a different
stretch, because the interesting brightness has moved.

Here the band is placed in **noise sigma above the image's own background**:

```
centre = sky + centre_sigma * sigma
width  = width_sigma * sigma
```

Faint outer nebulosity sits a few sigma above the sky whatever the image, so one
setting means the same thing on the next frame.

## Controls

| control | effect |
|---|---|
| **Boost** | extra slope at the centre of the band. 0 is an exact no-op. At 3 the curve is four times as steep there, so detail in that range is spread over four times as much output. Negative flattens the band instead, for suppressing a bright core. |
| **Band Center** | where on the histogram the enhancement sits, in noise sigma above the sky level. Faint nebulosity is typically 3 to 15. |
| **Band Width** | how wide the enhanced region is, in the same sigma units, as a Gaussian standard deviation. No hard edges, so there is no brightness at which the transform switches on. |
| **Preserve color** | derive the transform from luminance and apply it to all three channels as one gain, so pixels change brightness but not color. Ignored for mono. |

## How it is built

The curve is not shaped directly. Its **slope** is specified and then integrated:

```
gain(x) = 1 + boost * exp( -0.5 * ((x - centre)/width)^2 )
f(x)    = integral of gain from 0 to x, divided by the integral to 1
```

Three properties follow from the construction, not from a check afterwards:

- **Monotonic.** `gain(x) > 0` everywhere provided `boost > -1`, so the integral
  strictly increases. Nothing brighter can become darker at any setting.
- **Endpoints exact.** Dividing by the integral to 1 makes `f(0) = 0` and
  `f(1) = 1` by definition, so clipping is impossible rather than merely unlikely.
- **No kinks.** `gain` is smooth, so `f` is smooth. A hand-drawn curve with a
  corner leaves a contour in the sky; there is no corner here to leave one.

The integral has no closed form, so it is computed once in `prepare()` at 65536
points and interpolated per pixel. Entries are interpolated rather than taken
nearest: at 1024 entries a nearest-entry read collapses 64 adjacent 16-bit levels
onto one output, which is visible as banding. That mistake was made in a related
script before it was caught.

## Where the contrast goes

Background 0.20, sigma 0.006, band at 6 sigma, boost 3. Slope of the curve:

| input | slope |
|---|---|
| 0.100 | 0.8471 |
| 0.200 | 1.6719 |
| 0.224 | 3.0927 |
| 0.236 | **3.3885** |
| 0.260 | 2.3887 |
| 0.400 | 0.8464 |
| 0.800 | 0.8494 |

**Contrast is redistributed, not created.** The output still has to run from 0 to
1, so whatever the band gains, everything outside it gives up — here about 15% of
its slope. That is the trade the control exists to make, and it is worth judging
on the regions you are not boosting as well as the one you are.

## Defaults

`Boost 2.5, Band Center 2.5, Band Width 2.5`. On a frame with sky 0.20 and sigma
0.006 that puts the band from about -2.5 to +7.5 sigma, which in image values is
0.185 to 0.245:

| sigma above sky | input | output | slope |
|---|---|---|---|
| -3.0 | 0.18200 | 0.16756 | 1.117 |
| 0.0 | 0.20000 | 0.19645 | **2.300** |
| +2.5 | 0.21500 | 0.23949 | **3.199** |
| +7.5 | 0.24500 | 0.30792 | 1.223 |
| +30.0 | 0.38000 | 0.43327 | 0.914 |

Peak slope 3.20x, trough 0.91x.

**Worth knowing what this default does to the sky.** The band is centred only 2.5
sigma up and is 2.5 sigma wide, so a good part of it sits *in* the sky noise: the
slope at the sky level itself is 2.30, against 1.67 for a band centred at 6. That
is deliberate if what you want to lift is the faintest signal, which lives right
on top of the noise — but noise is lifted with it. Move Band Center up if the sky
starts looking grainy before the nebulosity looks better.

## Reading the panel

Three things are drawn, and the slope is the one to watch.

**Grey fill** — the image's own histogram, on a square-root scale. This answers
the question the curve cannot: *is the band where my data is?* Linear scaling
makes the background peak so tall that the faint end vanishes; logarithmic
over-flattens it.

**Black or RGB line** — the transfer curve. On a stretched frame with the band at
6 sigma its largest departure from the diagonal is about 0.107, which is 21 pixels
on a 200 pixel panel: visible, but easy to miss. On linear data the band is
thinner than one pixel and there is genuinely nothing to see.

**Teal line** — the slope, scaled so its peak fills the panel. This is where the
control is legible, because the slope is what the control actually sets:

| input | curve | slope | % of panel height |
|---|---|---|---|
| 0.0996 | 0.08438 | 0.847 | 25% |
| 0.1992 | 0.17836 | 1.634 | 48% |
| 0.2363 | 0.27747 | **3.384** | **100%** |
| 0.2793 | 0.38402 | 1.348 | 40% |
| 0.6992 | 0.74520 | 0.847 | 25% |

The caption gives the peak as a multiple, because the shape alone does not say
whether the bump is a ten percent lift or a fourfold one:

| setting | peak slope | trough |
|---|---|---|
| boost 1, centre 6, width 4 | 1.88x | 0.94x |
| boost 3, centre 6, width 4 | 3.38x | 0.85x |
| boost 8, centre 6, width 4 | 6.07x | 0.68x |
| boost -0.9, centre 6, width 4 | 1.06x | 0.11x |

The trough is the number to keep an eye on. At boost 8 everything outside the band
is running at 0.68 of its original contrast — that is the price of the 6x in the
middle, and it is what "redistributed, not created" means in practice.

**This is a post-stretch tool.** On linear data the band is a fraction of a
percent of the range wide and nothing visible happens whatever the settings.

## Verified

| check | result |
|---|---|
| `f(0)` and `f(1)`, at boost 0, 3, 20 and -0.9 | exactly 0 and 1 |
| Boost 0 is an exact no-op | output equals input |
| Monotonic, in range, no NaN — six configurations | pass |
| 16-bit levels surviving | **65536 / 65536** in every configuration |
| Color preserved, ratio change | max **8.6e-8** |
| No clipping, color, 600k samples across four settings | 0 out of range, 0 non-finite |
| Streaming: 8 rows per block vs whole image | difference **0.00e+0** |

The last one matters most: the curve is built once in `prepare()` from the source
statistics, so the result cannot depend on how the engine chose to divide the
image up. It is the property most likely to be quietly wrong in a streaming
script.

## Editing the header text

The paragraph block at the top of the dialog is `METHOD_INFO` at the top of
`lib/Methods.js`. It is HTML: `<p>` starts a paragraph, `<b>` makes text bold. Set
it to `""` for an empty panel, or delete the variable and the dialog falls back to
the method's own one-line description.

It lives beside the maths deliberately, so replacing the method and rewriting what
the dialog says about it are the same edit.

## Requirements

PixInsight 1.8.9 or later, V8 engine.

## Provenance

Built on the PixInsight Script Template. The conventions this code follows and the
PJSR traps it works around are documented in `DEVELOPMENT_RULES.md` in the
template, not duplicated here.

`tools/audit.py` and `tools/audit_selftest.py` come from the template and apply
unchanged:

```bash
python3 tools/audit.py
python3 tools/audit_selftest.py
```
