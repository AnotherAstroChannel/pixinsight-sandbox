# Saturation for PixInsight

Copyright (c) 2026 Bill Blanshan. Released under the GNU General Public License
version 3.

Increases colour saturation without clipping, without changing brightness and
without shifting hue.

Built on the PixInsight Script Template. The maths lives in `lib/Methods.js`.

**This is stage one of three.** A spatial mask and selection by hue are planned;
both are further weights on the strength computed here, so neither needs this
stage restructured.

## How it works

Chroma is scaled along the pixel's own direction in RGB:

```
Y     = luminance of the pixel
out_c = Y + t*( v_c - Y )
```

`t = 1` returns the pixel unchanged; larger `t` moves every channel further from
the luminance, which is more colour at the same brightness.

Three properties follow from that form rather than from any check afterwards:

| property | why | measured over 400k random pixels |
|---|---|---|
| **Brightness exact** | `Y(out) = Y + t*(Y - Y) = Y` algebraically | worst change 4.4e-8 |
| **Hue exact** | the direction of `v - Y` is untouched, only its length grows | worst drift 1.2e-12 |
| **Neutral stays neutral** | a grey pixel has `v_c = Y`, so every term is zero | exactly 0 |

The residual 4e-8 is float32 storage rounding, not the arithmetic.

## The gamut limit

`t` cannot grow freely: at some point a channel would leave [0,1]. The largest
admissible value is computed exactly, per pixel:

```
t_max = min over channels of   (1 - Y)/(v_c - Y)   where v_c > Y
                               (0 - Y)/(v_c - Y)   where v_c < Y
```

and the requested multiplier is soft-limited towards it:

```
want = amount * SATURATION_MAX_GAIN
t    = 1 + want/( 1 + want/(t_max - 1) )
```

As `want` grows, `t` approaches `t_max` and never reaches it. **Clipping is
impossible rather than merely unlikely** — 400k random pixels at five strengths:
nothing clipped, nothing non-finite.

### Why a multiplier and not a fraction of the available room

"Half way to the gamut boundary" sounds more principled and is much worse, because
headroom depends on brightness. A dark pixel has room for many times its chroma:

| | headroom | at "half way to the boundary" |
|---|---|---|
| dim nebulosity, stretched | 562% | 0.333 -> 0.792 |
| sky, stretched | 7317% | 0.029 -> 0.695 |
| sky, linear | 7055% | 0.033 -> 0.712 |

The background comes out violently coloured. A multiplier is scale free, so a
setting behaves the same on linear and on stretched data:

| | saturation before -> after, amount 0.5 |
|---|---|
| nebulosity, stretched | 0.3333 -> 0.5804 |
| nebulosity, linear | 0.3333 -> 0.5804 |

The boundary then intervenes only where there genuinely is no room: a wanted 4.00
becomes 2.58 on a blue reflection, but stays at 3.88 on a dark pixel that has
space.

## Background neutralization

Saturation multiplies whatever colour a pixel already has, and it cannot tell a
cast from real colour. On an uncalibrated frame a faintly blue sky becomes a
strongly blue sky. The chroma floor cannot fix that: a cast and real faint colour
are the same size, so no threshold separates them.

So each channel's background is measured at a chosen quantile of its **own**
distribution and remapped so that level lands on the mean of the three:

```
m   = mtf( reference, level )        reference = mean of the three levels
out = mtf( m, v )
```

| | result |
|---|---|
| each channel's background lands on the reference | worst error **1.5e-9** |
| black | **0.00000000** |
| white | **1.00000000** |
| monotonic | yes, so no ordering changes |

Per channel and not the median, deliberately. A cast is precisely a disagreement
between the channels about where the sky sits, so measuring them together cannot
see it; and the median of a whole frame is only the sky level if most of the frame
is sky.

The reference is the **mean** of the three levels, so neutralising changes the
balance without changing the overall level. Matching to the darkest channel would
darken the frame, to the brightest would brighten it.

### Why a transfer and not a linear rescale

The obvious form is a linear rescale in the inverted domain:

```
out = 1 - ( (1-reference)/(1-level) ) * ( 1 - v )
```

It lands the background just as exactly and anchors white. But being linear, it
drives the bottom of the range negative wherever a channel's background sits above
the reference. On a measured frame with blue at 0.1810 against a reference of
0.1672, **everything below 0.0166 in blue clipped to black** — which on a stretched
image is dark nebulae and the darkest sky.

The transfer costs a little photometric fidelity in exchange, being nonlinear. For
removing a cast from stretched data that is the better trade.

### Measured on a real pixel

| | R, G, B | chroma |
|---|---|---|
| original | 0.10043, 0.09231, 0.10949 | 0.014213 |
| neutralised | 0.10388, 0.09778, 0.10045 | **0.004609** |
| saturated without neutralising | 0.11281, 0.08518, 0.14364 | **0.048366** |
| neutralised, then saturated | 0.10388, 0.09778, 0.10045 | 0.004609 |

The cast is removed before it can be multiplied, so its chroma drops to a third.
And the last row is the point: once neutral, the pixel falls below the chroma floor
and the saturation leaves it alone entirely. That is the floor working as designed,
which it could not do while a cast was present.

**Show Background** maps the pixels at or below the level in all three channels —
white is what the estimate is measured from. If real structure shows white, the
quantile is too high.

## Controls

| control | effect |
|---|---|
| **Neutralize background** | match the three channels at the background level before saturating. |
| **Background at** | which quantile of each channel is taken as its background. 0.15 as shipped; lower on a crowded field. |
| **Show Background** | map the pixels the level is measured from. Diagnostic; Execute is blocked while on. |
| **Amount** | how much colour to add. 0 is an exact no-op. At 1.0 chroma is multiplied by up to `SATURATION_MAX_GAIN`, which is 3 as shipped, less wherever the gamut is close. |
| **Chroma Floor** | pixels with less colour than this are left alone, fading in smoothly above it. Measured in noise sigma. |
| **Restrict to a hue range** | limit the effect to one colour. |
| **Hue Center** | which colour, in degrees clockwise from red at the top. 0 red, 120 green, 240 blue. |
| **Hue Width** | how much of the wheel, as a Gaussian standard deviation in degrees. |
| **Show Selection** | map the combined hue and chroma weight. Diagnostic; Execute is blocked while on. |
| **Show Chroma Floor** | maps how much saturation each pixel receives from the floor: black is excluded, white is the full Amount. A diagnostic view; Execute refuses to run while it is on. |

Both are disabled on grayscale, where the method has nothing to do.

## The chroma floor is the part that matters on astro data

Sky is nearly grey, so most of its colour is noise. Multiplying noise turns an
even background into coloured mottling. The floor leaves it alone:

| floor (sigma) | sky, sat 0.0173 | nebulosity, sat 0.3333 |
|---|---|---|
| 0 | 0.0424 | 0.5804 |
| 0.5 | 0.0173 | 0.5804 |
| 2 (default) | 0.0173 | 0.5804 |
| 8 | 0.0173 | 0.4252 |

At 0 the sky's chroma is lifted by two and a half times. At 0.5 and above it is
untouched, while real colour — an order of magnitude stronger — is unaffected
until the floor gets high enough to bite into it.

Sigma comes from a low quantile of the image's own distribution rather than the
median, because on a field full of nebulosity the median is not the sky. The
console diagnostics report what one sigma is for the current image.

The fade above the floor is a smoothstep, so there is no chroma at which the
effect switches on. A hard threshold leaves a visible contour through the
background.

## Seeing what the floor excludes

**Show Chroma Floor** replaces the image with a map of the weight itself, so the
fade is visible rather than a hard in-or-out. With the floor at 2 sigma:

| | chroma | map | meaning |
|---|---|---|---|
| neutral grey | 0.00000 | 0.00000 | excluded |
| sky, faint noise | 0.00182 | 0.00000 | excluded |
| just under the floor | 0.00795 | 0.00000 | excluded |
| mid fade | 0.01425 | 0.09193 | in the fade |
| nebulosity | 0.06444 | 1.00000 | full amount |

Raise the floor and watch the background go black. If real structure starts going
black with it, the floor is too high:

| floor | sky | nebulosity | strong blue |
|---|---|---|---|
| 0 | 1.0000 | 1.0000 | 1.0000 |
| 1 | 0.0000 | 1.0000 | 1.0000 |
| 8 | 0.0000 | 0.2715 | 1.0000 |
| 20 | 0.0000 | 0.0000 | 0.0457 |

**It maps the floor only, from the RGB values.** It is unaffected by the hue
range, because how much colour a pixel has and which colour it is are different
questions:

| | hue range off | hue range on, centre 240 |
|---|---|---|
| blue | 1.00000 | 1.00000 |
| red | 1.00000 | 1.00000 |
| grey | 0.00000 | 0.00000 |

A pixel can read white here and still gain little colour, for two separate
reasons: the gamut boundary limits it, and a hue range may exclude it.
**Show Selection** is the combined picture:

| | floor map | selection map, centre 240 |
|---|---|---|
| blue | 1.00000 | 0.97561 |
| red | 1.00000 | **0.00034** |
| green | 1.00000 | **0.00080** |

The two diagnostic maps are mutually exclusive — ticking one clears the other,
since only one can be displayed and which would be arbitrary.

Grey from the weight on all three channels, so no hue can be read into a scalar.
Verified over 200k pixels: nothing out of range, nothing non-grey.

## Hue selection

**Restrict to a hue range** limits the effect to colours near **Hue Center**,
fading with angular distance. 0 red, 30 orange, 60 yellow, 120 green, 180 cyan,
240 blue, 300 magenta. The scale wraps, so a range centred on 350 reaches into the
reds without a discontinuity — `hueDistance(350, 10) = 20`.

Centre 240, width 30, amount 0.6:

| colour | hue | before | whole image | blue only |
|---|---|---|---|---|
| red | 0 | 0.3714 | 0.6328 | **0.3716** |
| yellow | 60 | 0.4444 | 0.7679 | **0.4444** |
| green | 128 | 0.4444 | 0.7546 | **0.4451** |
| cyan | 187 | 0.4737 | 0.7803 | 0.5912 |
| **blue** | 233 | 0.4500 | 0.6834 | **0.6807** |
| magenta | 300 | 0.4444 | 0.7197 | 0.5096 |

Only blue moves fully. Cyan and magenta get a fraction, being 46 and 60 degrees
away — the fade is a Gaussian, so neighbouring hues are partially included by
design. A hard edge would leave a visible boundary wherever a gradient of colour
crossed it.

| width | weight at 0 deg | 30 | 60 | 90 |
|---|---|---|---|---|
| 10 | 1.0000 | 0.0111 | 0.0000 | 0.0000 |
| 30 | 1.0000 | 0.6065 | 0.1353 | 0.0111 |
| 60 | 1.0000 | 0.8825 | 0.6065 | 0.3247 |
| 180 | 1.0000 | 0.9862 | 0.9460 | 0.8825 |

### The wheel

The ring shows every hue with the selected range lit, one width either side of the
centre. **Drag the white marker** to set the centre; **drag either short handle** to
set the width. Both handles move together because the width *is* the angular
distance from the centre, so symmetry is a property of the construction rather than
something kept in step.

**Red is at top dead centre and the scale increases clockwise** — 0 up, 90 right,
180 down, 270 left, with degree labels every 60. The whole orientation lives in one
pair of conversion functions, so it can be changed without hunting for sign errors
at six call sites.

**The widget has no background of its own.** A dark fill looked wrong in a light
dialog, and a light one would look equally wrong under a dark theme, so it paints
only the wheel: the ring bitmap is transparent outside the annulus and the control
is erased to its inherited background before painting. If some core does not erase,
the symptom would be smearing in the corners during a drag, and the fix is to fill
with `this.backgroundColor` — nothing else is affected, since the annulus, disc and
markers are all repainted in full every time.

**The centre disc shows the selected hue**, so the chosen colour is legible at a
glance without reading a number off a slider. The pointer runs from the edge of the
disc to just past the ring, drawn as a thin white line over a dark one so it stays
visible against both yellow and blue.

Presses inside the disc are ignored, as are presses well outside the ring: only the
ring itself and a few pixels either side of it start a drag.

Clicks outside the ring are ignored, so a stray click near a corner cannot throw
the centre across the wheel. The centre wins a tie against a handle by two degrees:
at small widths a handle sits almost on top of it, and it should not steal the drag.

Everything is drawn from `drawLine`, `fillRect`, `drawRect`, `drawBitmap` and
`drawText` — the only calls proven in this codebase. There is no `fillEllipse` among
them, so the disc is filled scanline by scanline, and no font metric call, so labels
are centred by offset as CurvePlot does. A widget that cannot be tested outside
PixInsight is the wrong place to gamble on an untried primitive.

The ring is rendered once into a bitmap and cached, which is what makes a drag
cheap:

| | drawLine calls |
|---|---|
| first paint | 856 (builds the ring) |
| every paint after | **136** |
| worst during a full sweep of the centre | **136** |
| after a resize | 800, then back to 80 |

### Pick from image

Arms an eyedropper: the next click in the preview reads the **mean of a 9 by 9 box**
and sets Hue Center to that hue.

A box rather than one pixel, because a single pixel's hue is mostly noise. Measured
over 200 trials on a patch whose true hue is 231.1 degrees:

| box | reported hue | spread |
|---|---|---|
| 1x1 | 232.9 | **± 11.4 deg** |
| 3x3 | 231.4 | ± 4.0 |
| **9x9** | 231.3 | **± 1.3** |
| 25x25 | 231.1 | ± 0.4 |

A single pixel scatters by more than a third of the default Hue Width, which would
make the reading useless. Averaging 81 brings it inside a couple of degrees.

The mean is taken from the **full resolution image**, not the preview buffer — the
buffer is cropped and resampled, so a reading from it would depend on the zoom.
That distinction has already caused one wrong diagnosis in this project.

It is an armed mode rather than a modifier because every modifier is taken: Ctrl
compares, Shift pans, the middle button pans, a plain drag zooms and a double click
fits. An armed mode is also discoverable, which a hidden modifier is not.

Sampling a neutral patch reports that it has no hue rather than setting the centre
to red.

### Working through colours in turn

Apply to target image is the default and each run is one undoable step, so:

| | red pixel | blue pixel |
|---|---|---|
| start | 0.3714 | 0.4500 |
| after centre 240 | 0.3716 | **0.6807** |
| after centre 0 | **0.6330** | 0.6808 |

Each pass moves only its own colour, and each builds on the last:

| | blue patch | red patch |
|---|---|---|
| original | 0.4500 | 0.4500 |
| after pass 1, centre 240 | **0.6807** | 0.4502 |
| after pass 2, centre 0 | 0.6808 | **0.7037** |

For this to work the preview has to be rebuilt from the image as it now is. It is:
after an in-place Execute the dialog re-reads the target, and the engine discards
the four caches keyed to it — the full-image statistics, the luminance histogram,
the background histogram and the per-channel one.

Without that the panel keeps showing the pre-Execute pixels, so the second pass is
set up against data that no longer exists. The cost is not subtle:

| | blue patch after pass 2 |
|---|---|
| preview rebuilt | **0.6808** |
| preview stale | 0.4501 — the first pass appears lost |

**Turn Neutralize background off after the first pass** — the background is already neutral by then, and re-applying a
correction each round compounds for no benefit.

### It depends on the chroma floor

The hue of a nearly grey pixel is whatever its noise happened to be. Selecting a
colour with no floor picks roughly a sixth of the background at random and
saturates it into speckle of that colour. `hueOf()` returns -1 for a neutral pixel
and callers treat that as *no hue* rather than as hue zero — which would silently
place every grey pixel in the reds.

**Show Selection** maps the hue weight and the chroma floor weight together, which
is what actually determines the result. White is fully selected, black untouched.

## The chroma fade is a factor, not a fixed amount

`Chroma Floor` is the chroma at which **half** the amount is applied, and the weight
is a smoothstep in *log* chroma centred on it — zero at about a third of the floor,
full at about three times it.

| chroma | weight |
|---|---|
| 22 sigma | 1.000 |
| 8.1 | 0.849 |
| **4.61 (the floor)** | **0.500** |
| 3.0 | 0.188 |
| 2.2 | 0.045 |
| 1.63 | 0.000 |

Two reasons it is shaped this way, and the first version had neither.

**Log, not linear.** Chroma spans four orders of magnitude on a linear frame, so a
window of fixed width in chroma covers a sliver of the range and the weight comes out
effectively binary:

| chroma | linear window | log window |
|---|---|---|
| 4.6 sigma | 0.000 | 0.000 |
| 6.0 | 0.218 | 0.095 |
| 9.2 | **1.000** | 0.500 |
| 18.4 | 1.000 | 1.000 |

**Centred on the floor, not starting at it.** A fade that reaches exactly zero *at*
the floor still has an edge there, and around a bright star chroma crosses it within a
pixel. Traced down a star's profile:

| radius | chroma | starting at the floor | centred on it |
|---|---|---|---|
| 6 | 13.80 | 0.887 | 1.000 |
| 7 | 8.12 | **0.364** | 0.868 |
| 8 | 4.40 | **0.000** | 0.467 |
| 9 | 2.20 | 0.000 | 0.056 |
| 10 | 1.01 | 0.000 | 0.000 |

One pixel from 0.364 to zero is the ring that showed around bright stars. Centred, the
same fall-off takes six pixels and has no step anywhere.

The cost is that noise a little below the floor now gets a small lift — 0.19 at 3
sigma. Set the floor about 1.5 times higher than a hard threshold would have needed.

`CHROMA_FADE_OCTAVES` sets the width, 1.5 as shipped. This is an ordinary soft-knee
threshold, the same shape an audio compressor uses and for the same reason: a hard
knee is audible, and a hard chroma threshold is visible.

## What a per-pixel threshold cannot do

The chroma floor is applied to each pixel on its own, and chroma noise has a tail.
On pure Gaussian sky with no colour whatever:

| floor | share of sky pixels that pass |
|---|---|
| 0.5 sigma | 88.0% |
| 1.0 | 60.3% |
| 2.0 | 14.7% |
| 2.7 | **3.5%** |
| 4.0 | 0.11% |
| 6.0 | 0.00% |

The median neutral pixel already reads 1.18 sigma of chroma, purely from noise. So
at 2.7 sigma roughly one sky pixel in thirty passes — millions of scattered pixels
on a large frame, which is the speckle in the map.

That is not a fault in the map: **no per-pixel threshold can separate noise from
faint colour**, because their magnitudes overlap. Raising the floor to 6 sigma
removes the speckle and also removes any real colour that faint. What actually
separates them is spatial: real colour is coherent across neighbouring pixels and
noise is not. That is what a mask is for, and it is the argument for building one.

**Diagnostic maps are shown without the screen stretch.** A map holds weights,
mostly 0 and 1, and autostretching that drives every non-zero pixel towards white —
which made a 3.5% noise tail look like a solid field of speckle and like a fault in
the tool.

## What it cannot do

**A pixel near white cannot be colourful.** The test star has 61% headroom against
562% for dim nebulosity, so an aggressively stretched core resists saturation
whatever the setting. That is the gamut, not the implementation.

**There is no transfer curve panel**, unlike the other scripts built on this
template. A colour-only method leaves neutral pixels untouched by definition, so a
curve evaluated on a grey ramp would be a straight line at every setting. It was
removed rather than left there to mislead.

## Editing the header text

The paragraph block at the top of the dialog is `METHOD_INFO` at the top of
`lib/Methods.js`. It is HTML: `<p>` starts a paragraph, `<b>` makes text bold.

## Verifying a change

```bash
python3 tools/audit.py            # fourteen static checks
python3 tools/audit_selftest.py   # proves each check can fail
for f in lib/*.js; do node --check "$f"; done
```

Run the self-test before believing a clean report. While writing these checks,
five of them reported zero on a project with the fault deliberately re-introduced.

## Requirements

PixInsight 1.8.9 or later, V8 engine.
