/*
 ****************************************************************************
 * Saturation
 *
 * Saturation.js
 *
 * Increases colour saturation without clipping, without changing luminance and
 * without shifting hue.
 *
 * Chroma is scaled along the pixel's own direction in RGB, by a multiplier that
 * is soft-limited by the exact gamut boundary. A multiplier is scale free, so the
 * same setting behaves the same on linear and on stretched data -- which a
 * boundary-relative strength would not, because a dark pixel has enormous
 * headroom and would be driven to full saturation.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.33     Attribution moved to the dialog header and declared once, as a define
 * 1.32     Menu group: Another Astro Channel, out of Utilities
 * 1.31     Custom process icon: #feature-icon and icons/<name>.svg
 * 1.30     Audit reads the #feature-* directives
 * 1.29     Feature-info corrected: it still described the script as a template
 * 1.28     Background neutralisation defaults off; amount 0.25; hue centre 0;
 *          the noise-sigma note dropped from the header panel
 * 1.27     Dead __histogram cache invalidation removed; three new audit checks
 * 1.26     Audit gains a nineteenth check: members assigned but never called
 * 1.25     The chroma fade is a log-space soft knee centred on the floor
 * 1.24     The preview publishes its state atomically, so no paint can see a
 *          half-finished rebuild
 * 1.23     The screen stretch appeared to switch itself off after a zoom
 * 1.22     The preview was one rebuild behind whenever the screen stretch
 *          was on: a stale bitmap cache
 * 1.21     TEST: render margin off, to confirm the negative draw origin
 * 1.20     Preview geometry logging, on, to find the zoom fault
 * 1.19     A drawn bug icon for the diagnostics button, moved to the right
 * 1.18     The debug button reports where the selection actually lands
 * 1.17     Diagnostic maps skip the screen stretch; labelWidth restored
 * 1.16     Preview rendered before the layout had applied the new size
 * 1.15     Custom width and height sit together instead of at opposite ends
 * 1.14     The preview is rebuilt after an in-place Execute
 * 1.13     Preview size as a dropdown, custom width and height on one row
 * 1.12     The hue block shares one left edge
 * 1.11     Black labels and outlines; wheel beside the controls, sliders gone
 * 1.10     Wheel has no background of its own; the 240 label no longer clips
 * 1.09     Wheel shows the selected hue in a centre disc, with degree labels
 * 1.08     Wheel orientation: zero at top dead centre, increasing clockwise
 * 1.07     The wheel used the PJSR __base__ idiom, which throws under V8
 * 1.06     Hue wheel with draggable centre and width, and an eyedropper
 * 1.05     Show Chroma Floor no longer includes the hue weight; the two
 *          diagnostic maps are mutually exclusive
 * 1.04     Hue Center and Hue Width were permanently greyed out
 * 1.03     Hue selection, applied after the chroma floor
 * 1.02     Background neutralization, per channel at a chosen quantile
 * 1.01     Show Chroma Floor, a diagnostic map of the floor weight
 * 1.0      Stage one: boundary limited chroma multiplier with a chroma floor
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    Saturation : Another Astro Channel > Saturation
#feature-icon  @script_icons_dir/Saturation.svg


#feature-info  Increases colour saturation without clipping or changing luminance.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Saturation"
#define VERSION     "1.33"
#define SCRIPT_ID   "Saturation"
#define KEYPREFIX   "Saturation"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Increases colour saturation without clipping or changing luminance."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas. 0.25 costs about 2.25x the
 * preview pixels, which at roughly a megapixel is not worth economising on.
 */
/*
 * How far beyond the visible selection the preview buffers are rendered, as a
 * fraction of the selection. Panning then slides real data into view instead of
 * exposing empty canvas, at the cost of resampling a slightly larger area.
 */
#define PAN_MARGIN               0.25

/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304

/*
 * Histogram resolution for median and MAD. 2^20 bins resolve to about one part
 * in a million over [0,1], far finer than the data warrants, at 4 MB.
 */
/*
 * Which quantile of the pixel distribution is taken as the sky level. Used only
 * to give the chroma floor a scale: a floor expressed as a raw number means
 * different things on linear and on stretched data, where one expressed in noise
 * sigma means the same on both.
 */
#define BACKGROUND_QUANTILE      0.25

/*
 * Luminance weights, Rec. 709. The saturation preserves this quantity exactly,
 * so these define what "unchanged brightness" means here.
 */
#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

/*
 * Largest chroma multiplier at full strength. The soft limiter pulls the
 * delivered multiplier below this wherever the gamut boundary is close, so this
 * is a ceiling on intent rather than on the result.
 */
#define SATURATION_MAX_GAIN      3.0

/*
 * Width of the chroma fade, in octaves each side of the floor.
 *
 * The weight is a smoothstep in LOG chroma, centred on the floor: zero at
 * floor/2^n, a half at the floor, one at floor*2^n.
 *
 * Log rather than linear because chroma spans four orders of magnitude on a linear
 * frame, so a window of fixed width in chroma is a sliver of the range and the
 * weight is effectively binary. Centred rather than starting at the floor because a
 * fade that reaches exactly zero AT the floor still has an edge there, and around a
 * bright star chroma crosses it within a pixel -- which showed as a ring.
 *
 * At 1.5 the transition runs from 0.35 to 2.8 times the floor. Wider is smoother and
 * lets more faint colour through; narrower approaches the hard threshold this
 * replaced.
 */
#define CHROMA_FADE_OCTAVES      1.5

/*
 * The hue wheel's side in pixels, and the box the eyedropper averages.
 *
 * A box rather than one pixel because a single pixel's hue is mostly noise: the
 * three channels differ by the sensor's noise as much as by the colour, so the
 * angle it reports is close to random. Averaging first is what makes the reading
 * repeatable. Nine is enough on a stretched frame and small enough to stay inside
 * one feature.
 */
#define HUE_WHEEL_SIZE           170
#define HUE_WHEEL_LABEL_MARGIN   24
#define HUE_WHEEL_LABEL_GAP      11
#define HUE_WHEEL_DIGIT_WIDTH    3.5

/*
 * The degree labels. Black, because the wheel sits on the dialog's own background
 * and a light grey was invisible there. Under a dark theme this wants to be
 * near-white, which is why it is a constant rather than a literal.
 */
#define HUE_WHEEL_TEXT_COLOUR    0xff000000

/*
 * Label column for the two hue numbers, which sit in a block indented past the
 * wheel. The dialog's shared column is sized for the widest label anywhere in the
 * dialog and would push their boxes out of the group entirely.
 */
#define HUE_LABEL_WIDTH          52
#define HUE_SAMPLE_SIZE          9

#define STATISTICS_BINS          1048576

/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_LABEL_WIDTH      78
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * colour value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define READOUT_HEIGHT           32
#define PREVIEW_DEBOUNCE_SECONDS 0.25

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/AutoStretch.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamControls.js"
#include "lib/PreviewControl.js"
#include "lib/HueWheel.js"
#include "lib/Engine.js"
#include "lib/MainDialog.js"

/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();

      let dialog = new MainDialog( engine );
      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
