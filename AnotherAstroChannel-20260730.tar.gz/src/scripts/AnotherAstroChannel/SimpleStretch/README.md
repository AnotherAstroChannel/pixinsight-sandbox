# Simple Stretch for PixInsight

A stretch that cannot clip. It places the image median on a chosen background
level and holds it there, whatever else is adjusted.

Installs under **Script → Another Astro Channel → Simple Stretch**.

---

## What it does

A linear astronomical image has almost all of its pixels crowded into the bottom
fraction of a percent of the range. Stretching moves that population up into
visible brightness. The difficulty is doing it without losing the two things that
matter: the sky level, and the color.

This does both by construction rather than by care.

**The median lands where you ask, and stays there.** Target background sets the
level the image median is moved to. Every other control is arranged to leave that
point alone, so adjusting the highlights or the white point does not drag the sky
brightness around underneath you.

**Nothing can clip.** The transfer is normalised so that zero maps to zero and
one maps to one by construction. There is no setting at which a value is pushed
past white or below black, and no clamp doing the work — the shape of the maths
makes it impossible.

**Color comes from the data.** The result is a blend of a linked stretch, which
computes one curve from all channels together, and an unlinked one, which
stretches each channel separately. The blend decides how much of the image's own
color survives. Out-of-gamut color is walked back towards the boundary rather
than clamped at it, so a saturated core desaturates smoothly instead of going
flat.

---

## Controls

**Target background** — the level the image median is moved to. Higher gives a
brighter, flatter result; lower keeps more contrast in the shadows at the cost of
a darker sky.

**Linked stretch** — computes one curve from the mean of all channels, preserving
the color balance already in the data. Unlinked stretches each channel on its
own, which neutralises a cast but invents color where there was none.

**Saturation** — how much of the image's own color survives the stretch.
Strictly this is color retention rather than a boost: it sets the blend between
the linked and unlinked results.

**Highlights** — brings the bright end down while leaving the median where it is.
Reducing it separates a core the stretch has driven towards white.

**White point** — stops the brightest parts of the image short of white. 1.0 is
off.

---

## Notes

**The preview computes at display resolution.** The image is cropped and
resampled before the transform runs, so a refresh costs a fraction of a
full-resolution pass. Statistics are always measured from the full target image,
never from the resampled buffer, so what the preview shows is what Execute
produces.

**The transfer curve panel** plots the actual curve for your image, derived from
its real statistics rather than from a synthetic ramp. The crosshair marks the
image median. Turn on the logarithmic input scale for linear data, where
everything of interest sits below 0.1 and a linear axis compresses it against the
left edge.

**Process instances** work normally: drag the triangle to the workspace to save a
setting and apply it to another image later. Note that PixInsight records a
checksum of the script source in every instance, so one saved against an earlier
version will refuse to run after an update. That is deliberate on PixInsight's
part — a stored instance must not quietly mean something different after a code
change.

---

## Requirements

PixInsight 1.8.9 or later, with the V8 script engine.

---

© 2026 Bill Blanshan — Another Astro Channel
