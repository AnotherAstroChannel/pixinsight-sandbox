/*
 ****************************************************************************
 * PixInsight Script Template
 *
 * Template.js
 *
 * A starting point for building PixInsight image processing scripts. Provides a
 * real-time preview with zoom, pan and pixel readout, a live transfer curve, a
 * display-only screen stretch, schema-driven parameters and full process
 * instance support.
 *
 * All transform maths lives in lib/Methods.js. All user parameters are declared
 * in lib/Config.js. Nothing else should need editing to build a new tool.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.04  THE SCHEMA AND THE PLUMBING ARE SHARED NOW. Every definition this
 *        script held in common with another has moved to ../shared/lib:
 *        the core parameter schema and its helpers (ParamSchema.js), the
 *        method registry (MethodRegistry.js), and whichever of the star
 *        engine, the edge map, the circle fill and the stretch curve this
 *        script uses.
 *        lib/Config.js is 69 lines where it was 402, and holds only what
 *        this script actually owns: its SECTIONS and its SCHEMA_OVERRIDES.
 *        MEASURED ACROSS THE WORKSPACE: 2587 duplicated lines before this
 *        work, ZERO after -- at definition level, which is the level the
 *        duplication was actually at. check_workspace.py has a check for
 *        it now, and verify_check_workspace.py proves that check can fail.
 *        NO BEHAVIOUR CHANGED. Every gate is green and unmoved: star
 *        detection still reports 220 detections, 0 false, 221 of 260 at
 *        threshold 8 in all three star scripts, and the deconvolution
 *        truth harness is bit-identical.
 * 1.03  THE STAR DETECTION IS THE SHARED ENGINE NOW, and it finds more
 *        stars. This script carried a detector 373 lines long, identical
 *        to UnsharpMaskPro's, with no matched filter, no dedupe, no
 *        roundness gate and no PSF-fit gate -- which is why its star
 *        mask looked different from StarMask's on the same frame.
 *        MEASURED ON THE SAME FIXTURE, before against after, found of
 *        260 planted stars with false detections in brackets:
 *           threshold  5    221 (0)  ->  222 (0)
 *           threshold  6    220 (0)  ->  222 (0)
 *           threshold  8    204 (0)  ->  221 (0)   <- the shipped default
 *           threshold 10    192 (0)  ->  218 (0)
 *           threshold 12    187 (0)  ->  211 (0)
 *           threshold 16    174 (0)  ->  196 (0)
 *        SEVENTEEN MORE STARS OF 260 AT THE DEFAULT, and the false count
 *        stays at zero at every setting -- so this is recall bought
 *        without precision sold. It still reports zero detections per
 *        0.39 Mpx of star-free nebulosity.
 *        THE WALK-AMPLITUDE BAR IS ABSOLUTE NOW. It was
 *        1.5*detectSigma*sigma here, so the bar a star had to clear MOVED
 *        when the Star detection slider moved -- a control feeding a
 *        measurement, which is how raising a threshold can gain
 *        detections as well as lose them (rule 48). STAR_WALK_AMP_FRACTION
 *        is deleted; the shared STAR_WALK_AMP_SIGMA of 7.5 replaces it.
 *        THE STAR MASK THIS FEEDS THEREFORE CHANGES. The deconvolution
 *        itself does not: verify_deconvolution_truth is bit-identical --
 *        rms 1.516e-3, FWHM 4.85 -> 2.74 px, gain 1.180x/0.994x, TV
 *        23.9 -> 17.6 sigma, 0.001% flux drift.
 * 1.02  THE STAR ENGINE STARTS BECOMING ONE SHARED FILE. The star
 *        geometry this script measures with -- radiusAtLevel,
 *        ellipseAtLevel and nine constants -- and the separable box
 *        blur now come from ../shared/lib/StarDetect.js and
 *        ../shared/lib/Utilities.js instead of a private copy of each.
 *        Every one was byte-identical to StarMask's already, so no
 *        number here moved: verify_deconvolution_truth reports the same
 *        rms 1.516e-3, FWHM 4.85 -> 2.74 px, noise gain 1.180x plain
 *        against 0.994x damped, TV dip 23.9 -> 17.6 sigma and 0.001%
 *        flux drift as before the move.
 *        THE DETECTOR ITSELF IS STILL THIS SCRIPT'S OWN, and it is a
 *        generation behind StarMask's: no matched filter, no dedupe,
 *        no roundness gate, no PSF-fit gate, and a walk-amplitude bar
 *        of 1.5x the DETECTION SETTING rather than an absolute 7.5
 *        sigma -- which is a control feeding a measurement, the shape
 *        rule 48 exists for. That carry-back is the next instalment
 *        and it WILL change this script's star mask.
 * 1.01  A MASK VIEW THAT TELLS THE TRUTH.
 *        THE ALL-MASKS VIEW SHOWS WHAT IS APPLIED, not the raw maps.
 *        His report: "it looks like sharpening is making it past the
 *        mask" -- the view near-black over the sky while the result was
 *        full of speckle -- and his statement of the contract it broke,
 *        "black conceals and white reveals".
 *        THE VIEW rendered  mask * edges * (1 - starMask)
 *        THE BLEND applies  mask * (1 - w + w*edges) * (1 - prot*star)
 *        Where the edge map reads zero the view was BLACK and the blend
 *        was 1 - w, which at the default edge weight of 0.30 is 0.70.
 *        MEASURED (UnsharpMaskPro/tools/measure_edge_mask_leak.py, Test_1,
 *        radius 1, amount 6.86, sky noise as the median adjacent
 *        difference with the sky defined on the INPUT):
 *           masks OFF              4.13x
 *           edge mask on, w 0.30   3.12x   <- the picture said 'nothing'
 *           edge mask on, w 1.00   1.04x
 *        AFTER, the same view at w 0.30: flat sky reads 0.700 and the
 *        brightest one per cent reads 0.000 -- so it now says truthfully
 *        that the STAR mask is holding stars back completely while the
 *        edge mask is letting 70% through everywhere else.
 *        THE DEFAULT IS NOT CHANGED, and that is deliberate. 0.30 is his
 *        tuned compromise: it is right for LUNAR work and DSO wants it
 *        higher. One value cannot serve both subjects, so the answer is a
 *        view that shows which regime you are in rather than a preset or
 *        a default that fixes one subject by breaking the other.
 *        Display only -- these views block Execute, so no output pixel
 *        changes.
 *        Carried here because the view and the blend are the same code
 *        in both sharpening scripts, and the same fault was in both.
 * 1.00  THE BENCH BECOMES THE SCRIPT, and the version starts where a
 *        shipped script starts (rule 94).
 *        His framing, and it was the right one: this was never a
 *        port. DeconvolutionTest was cloned FROM this script at
 *        0.30, so it is a descendant -- the code is replaced, not
 *        merged. Verified before doing it: Config, DialogHooks and
 *        StarMeasurement were byte-identical; every line present only
 *        in the old Deconvolution was something the bench had
 *        deliberately replaced (DECON_CACHE_MAX, the sample-count
 *        cache cap rule 85 records as a defect; the buffer-derived
 *        sky pedestal, the rule 16 violation fixed at 0.27; the old
 *        three-entry cache), and the bench's tools are a strict
 *        superset.
 *        WHAT ARRIVES, all of it measured on his 9032x6028 frame:
 *        the preview is never softer than the screen (1.10x, 1.02x
 *        and 1.31x per axis across an open and two zooms, floor of
 *        the rung ladder plus half-octave steps); the sky pedestal
 *        comes from the frame, not the buffer, so it no longer moves
 *        as he pans; the result cache is bounded in BYTES, so it
 *        finally engages on his real buffers instead of declining
 *        7% over a sample-count cap and saying nothing; the window
 *        opens before the processing starts, with a busy cross; a
 *        drag abandons the render it interrupts; the pan renders
 *        what is on screen first and the margin second; and the
 *        backdrop no longer builds its bitmap inside onPaint.
 *        WHAT DID NOT COME: the preview tiling, removed at bench
 *        0.32 on measured evidence -- the grid was defined in level
 *        pixels, so it demanded a power-of-two scale, forced
 *        full-octave rungs, and cost 3.26x the area at a zoom
 *        landing just under a rung (4608 ms of transform becoming
 *        26744 ms).
 *        STILL OWED, and it is the next job: lib/PreviewControl.js
 *        is a FORK of the shared one. Merging it region by region
 *        into ../shared/lib/PreviewControl.js is what gives every
 *        other script this preview, and it is declared as a
 *        workspace exception until it lands.
 *        The bench folder is deleted with this build.
 * ---------------------------------------------------------------------------
 * Below: the bench's own history, 0.01 to 0.32, which is the
 * development record of everything above. Under it, this script's
 * history to 0.30, from which the bench was cloned.
 * ---------------------------------------------------------------------------
 * 0.32  THE TILING IS GONE, NOT SWITCHED OFF. His instruction: he is
 *        building something clean, and a feature that lost on its own
 *        numbers does not get to sit in the two largest files in the
 *        project waiting to be half-enabled again. It already was
 *        once -- 0.18 shipped the tiled path dead while the region
 *        snapping still ran, so a pan paid every cost of the feature
 *        and collected none of its benefit, 11.2 s becoming 15.0 s.
 *        REMOVED: the four tile constants, deconPreviewTileGeometry,
 *        deconTiledPreview, the snap-outward-to-the-grid block in
 *        renderSelection, engine.isPreviewRun (one caller, which was
 *        the geometry gate), and opts.alphas/opts.onAlpha in deconRL
 *        -- a facility whose only two callers were the tiled path and
 *        its own verifier. 460 lines, 21.7 kB.
 *        KEPT, and this is the part that nearly went with it:
 *        PREVIEW_METHOD_HALO (24 px) is LIVE -- the visible-first
 *        render computes the selection plus the method's reach -- and
 *        the two tools that measured that 24 px were in the delete
 *        list before the constant was traced. measure_decon_halo.js
 *        stays, and verify_tile_agreement.js stays under the name
 *        verify_halo_sufficiency.js, because the halo question is the
 *        same question whether the sub-rectangle is a tile or the
 *        visible region. Rule 34: read the file for an explanation
 *        before deleting it.
 *        DELETED TOOLS: verify_tiled_preview.js (its subject is gone),
 *        verify_shared_step_tiling.js, measure_tile_economics.js.
 *        THE DECONVOLUTION IS UNCHANGED, and that is measured rather
 *        than asserted: verify_deconvolution_truth.js reports every
 *        figure bit-identical across the removal -- rms 1.516e-3,
 *        FWHM 4.85 -> 2.74 px, noise gain 1.180x plain against
 *        0.994x damped, TV dip 23.9 -> 17.6 sigma, flux drift 0.001%,
 *        sky shift -0.09 sigma.
 *        WHY IT IS NOT COMING BACK IN THIS FORM: the grid was defined
 *        in LEVEL pixels, so it demanded a power-of-two scale, which
 *        forced full-octave rungs. Measured on his frame, that cost
 *        3.26x the area at a zoom landing just under a rung and turned
 *        4608 ms of transform into 26744 ms. The idea that WOULD pay
 *        is the one the plan always named and nobody built: tiles
 *        pulled ON DEMAND, replacing the pan margin rather than being
 *        added to it. What shipped kept the margin AND snapped outward,
 *        so it carried both costs. If it is ever built, the grid is
 *        defined in IMAGE pixels and verify_halo_sufficiency.js is
 *        already the seam gate for it.
 *        A stale comment fixed with it: PreviewControl's note on
 *        PREVIEW_SCALE_OCTAVE_STEPS said "set to 1" for three builds
 *        after 0.28 set it to 2 -- a wrong note on the one constant
 *        that governs the whole pyramid.
 *        MEASURED ON HIS 9032x6028 FRAME AT 0.31, which is what this
 *        build preserves: open 23117 ms, of which the 40 FFT
 *        convolutions are 2170 ms (10%) and roughly 17.2 s is one-time
 *        full-resolution star detection over 54 MP; zoom rebuilds
 *        5175 ms and 7001 ms, convolutions 63% and 61% of the
 *        transform. The pyramid fits the display to 1.10x, 1.02x and
 *        1.31x per axis on those three passes and is never softer than
 *        the screen -- which is what the tiling would have undone.
 * 0.31  THE TILING LOSES ON MEASURED NUMBERS, AND IS OFF. Back to
 *        0.28's configuration, which is the fastest state anyone
 *        has measured on his frames.
 *        0.30 made the tiling run everywhere by returning to
 *        full-octave rungs -- the tile grid needs a power-of-two
 *        scale. It ran, and it cost him:
 *           0.28  half-octave, no tiling   zoom 5195 / 6869 ms
 *           0.30  full octave + tiling     zoom 27647 / 16495 ms
 *        THE CAUSE IS THE RUNGS, NOT THE TILES. His rebuild #2:
 *        source 2212x1920 for a 1224x1063 display -- 1.81x per
 *        axis, 3.26x the AREA, because the zoom landed just below
 *        a full-octave rung. The transform went from 4608 ms to
 *        26744 ms carrying pixels nothing would ever display.
 *        "0 reused" on every pass is CORRECT and not the fault: he
 *        zoomed, and every zoom is a different level with a
 *        different key. Tiles pay back on PANS. But a 27-second
 *        zoom bought to make pans cheaper is a bad trade for
 *        someone who zooms constantly, and that is the whole
 *        finding.
 *        SO THE TWO ARE INCOMPATIBLE AS BUILT, and tight scale
 *        fitting wins: half-octave rungs cost 1.13x at 1:3 against
 *        a full octave's 2.25x, and the preview is still never
 *        softer than the display either way -- that comes from the
 *        floor, not the step size.
 *        WHAT WOULD MAKE TILING VIABLE, recorded rather than
 *        attempted at the end of a session: the grid is defined in
 *        LEVEL pixels, which is why it demands a power-of-two
 *        scale. Defined in IMAGE pixels instead -- tile size
 *        T/scale rounded to an integer, fixed per level -- it
 *        would align at ANY scale, and half-octave rungs and
 *        tiling could both be had. That is a redesign of the grid,
 *        not a constant.
 *        The tiling code stays: it is correct at 0.000 sigma, its
 *        gates are green, and the only thing wrong with it is the
 *        rungs it forces.
 * 0.30  HALF-OCTAVE RUNGS KILLED THE TILING, AND HIS LOG CAUGHT
 *        IT IN ONE RUN. 0.28 set PREVIEW_SCALE_OCTAVE_STEPS to 2
 *        for a tighter fit to the display. Half-octave scales are
 *        0.7071 and 0.3536 -- NOT powers of two -- and the tile
 *        geometry requires a power of two, because on any other
 *        scale the grid cannot land on integer pixels and the same
 *        tile shifts between views.
 *        So 0.29 turned the tiling on and it ran EXACTLY ONCE, at
 *        the fitted view, where the scale happened to be 0.125.
 *        His console: "6 tiles -- 0 reused, 6 computed" on rebuild
 *        #1 and NO TILE LINE AT ALL on rebuilds #2 and #3, which
 *        went down the untiled path with forty convolutions each.
 *        RULE 89 IN THE SAME SESSION IT WAS WRITTEN: one feature
 *        broken by another, each correct alone. The tell was an
 *        ABSENCE in the log again -- a line that stopped appearing.
 *        THEY ARE MUTUALLY EXCLUSIVE, so it is a choice, and the
 *        numbers are the whole of it at 1:3:
 *           half-octave   1.13x overshoot   tiling DEAD
 *           full octave   2.25x overshoot   tiling WORKS
 *        Both are never-softer-than-the-display: that comes from
 *        the FLOOR, not from the step size. Full octaves merely
 *        overshoot further -- and tiles are exactly what pays that
 *        back, since the extra pixels are cached and reused by
 *        every pan instead of recomputed.
 *        Taking the tiling. Back to one level per octave.
 *        A SIDE EFFECT WORTH HAVING: at 1:1.5 the scale is now
 *        1.0000 -- full resolution. He reaches true 1:1 processing
 *        a zoom step earlier than before, which is what he asked
 *        for when he said the preview should stop downsampling as
 *        he zooms in.
 * 0.29  THE TILING IS ON. It was built at 0.17, proven correct at
 *        0.000 sigma, and switched off at 0.19 because it measured
 *        SLOWER -- for one reason, named at the time: the sky
 *        pedestal moved with the view and invalidated every tile.
 *        His console said it plainly: "16 tiles -- 0 reused, 16
 *        computed" on a pan that overlapped heavily.
 *        0.27 fixed the pedestal -- it comes from the frame now and
 *        does not move. That was the blocker, so the constant goes
 *        back to true.
 *        WHY IT IS ENABLED RATHER THAN LEFT FOR HIM TO FLIP: he is
 *        the one running it, the console reports the answer on
 *        every pass, and asking him to edit a constant before he
 *        can test is the passivity he called out. If it is slower
 *        it goes off again -- that is one run either way.
 *        WHAT TO READ, on a pan, in his console:
 *           Deconvolution: N tiles -- X reused, Y computed
 *        X ABOVE ZERO on a second pan means the reuse the whole
 *        design exists for is finally happening. X STILL ZERO means
 *        something else is moving the key, and that line says so
 *        rather than leaving it to be guessed.
 *        EXPECT THE FIRST LOOK AT A ZOOM TO BE SLOWER and the pans
 *        after it to be faster: a fixed grid computes WHOLE tiles,
 *        measured at 2.19x for the first view and 0.37x for the
 *        steady pan, 20 s against 32 s over a session
 *        (measure_tile_economics.js, tile 384 on his geometry).
 *        Acceleration stays off inside tiles and Execute keeps the
 *        accelerated whole-frame path -- that is settled and
 *        measured: acceleration is worth 1.1% of rms at 20
 *        iterations.
 *        Gates green: audit, dialog build, tiled preview at 0.000
 *        sigma with its poison red, tile agreement at halo 24.
 * 0.28  THE PREVIEW IS NEVER SOFTER THAN THE SCREEN IT IS DRAWN
 *        ON. His report: "look how far I have to zoom in just to
 *        get to a one to one ratio just to see the detail instead
 *        of seeing something desampled."
 *        processingScale() rounded to the NEAREST rung, so the
 *        level could land BELOW the display scale and the result
 *        was then upsampled to fill the panel. From his log:
 *        `source 806x616  display 1089x833` -- computed at 806
 *        wide, stretched to 1089. Detail the panel had room for
 *        was never computed, at every zoom, so 1:1 was the only
 *        place the sharpening could be judged honestly.
 *        The old note called that "a mild softening of a preview
 *        that is already an approximation". It was wrong about how
 *        it would FEEL: a preview exists to be judged, and one
 *        softer than the screen it is drawn on cannot be.
 *        FLOOR, NOT ROUND: the coarsest rung whose scale is still
 *        >= zoom. Plus PREVIEW_SCALE_OCTAVE_STEPS 1 -> 2, so a
 *        zoom landing between rungs overshoots by at most 1.41x
 *        per axis instead of 2x.
 *        MEASURED on his geometry, old against new:
 *           fit 1:8.8   0.1250 ok      -> 0.1250   1.21x area
 *           1:3         0.2500 SOFTER  -> 0.3536   1.13x area
 *           1:2         0.5000 ok      -> 0.5000   no change
 *           1:1.5       0.5000 SOFTER  -> 0.7071   1.13x area
 *           1:1         1.0000 ok      -> 1.0000   no change
 *        The two SOFTER rows are exactly his complaint. The cost
 *        is 13% more pixels, not the 44% projected before it was
 *        measured -- half-octave rungs land far closer than full
 *        ones.
 *        THE 1:1 FLOOR IS UNCHANGED and is the real floor: there
 *        is no data finer than the source. This changes which rung
 *        is chosen on the way there, not where it stops. An
 *        ABSOLUTE floor was considered and rejected with numbers:
 *        a fixed 1:3 would force 6.05 MP through the
 *        deconvolution at a FITTED view -- 7x today's pixels, 30
 *        to 40 s -- for detail a 1024 px panel cannot show. The
 *        never-below-display rule self-adjusts instead.
 *        The old clamp that bounded how far BELOW the display a
 *        level could fall is removed rather than left inert: by
 *        construction it can no longer fall below at all, and
 *        residue guarding an impossible case reads as
 *        load-bearing (rule 34).
 * 0.27  THE SKY PEDESTAL COMES FROM THE FRAME, NOT THE BUFFER.
 *        A rule 16 violation that predates every part of this
 *        session, and the thing standing between the tiling and
 *        being worth switching on.
 *        `sample[0]` was the darkest sampled pixel OF THE BUFFER,
 *        so b in the model K*u + b moved whenever the view moved.
 *        MEASURED on Test_5, the same frame throughout:
 *           whole frame (what Execute uses)   0.097143
 *           centre nebula view                0.099598
 *           dark corner view                  0.097818
 *           bright core view                  0.099317
 *        A SWING OF 0.002455 -- 2.5% of the floor -- caused by
 *        nothing but which way he was looking. The preview
 *        disagreed with itself, and with Execute, as he panned.
 *        NOW: backgroundEstimate( 0.001 ), the bottom tenth of a
 *        per cent of the frame's luminance, from the whole-image
 *        histogram the engine already caches per view. It reads
 *        0.097353 and does not move. That is 0.00021 from the
 *        value Execute was already using, and after the 2*sigma
 *        subtraction that follows it the pedestal lands just BELOW
 *        the frame minimum -- the safe direction, which the note
 *        in the code establishes: a b pulled down costs a little
 *        ring protection, a b pushed up pins everything under it.
 *        THE FLOOR, NOT A PERCENTILE, still. The fifth percentile
 *        was tried once and pinned a 25x25 sunspot umbra to one
 *        value; 0.001 is the lowest backgroundEstimate accepts and
 *        is steadier than a true minimum, which a single cold
 *        pixel or dead column would own.
 *        WHAT IT UNBLOCKS: b is in the tile key, correctly, so a
 *        moving b filed every tile under a key nothing would ask
 *        for again -- "16 tiles, 0 reused" on a heavily
 *        overlapping pan. That cause is gone. The tiling stays OFF
 *        until a measured run SHOWS the reuse appearing; the
 *        blocker being removed is not the same as the benefit
 *        being proven, and this project has shipped that mistake
 *        once already at 0.18.
 * 0.26  THE BACKDROP IS REPAIRED AND BACK ON. 0.22 proved it was
 *        blanking the preview by switching it off; this fixes the
 *        reason rather than living without it.
 *        THE FAULT: proxyBitmapFor() built its bitmap LAZILY,
 *        inside onPaint -- a new Image(), an applyStretchToImage()
 *        and a render. applyStretchToImage runs a
 *        HistogramTransformation and that PUMPS THE EVENT LOOP, so
 *        a paint handler pumped events with its Graphics still
 *        open and re-entered itself.
 *        THE FIX: the bitmap is built where pumping is expected --
 *        after the publish completes, on the stretch checkbox, and
 *        on the compare toggle. proxyBitmapFor is a LOOKUP now:
 *        when the bitmap it wants does not exist it draws no
 *        backdrop that pass rather than building one. A courtesy
 *        not delivered for one frame beats a blank window.
 *        AND NOT INSIDE applyPublish EITHER, which was the first
 *        attempt and was wrong for the same reason one level down:
 *        that function is the no-pumping publish block, so
 *        building there would let a paint land mid-publish -- a
 *        smaller copy of the fault being repaired. It runs in
 *        rebuildOnce's finally and after resolveHeldPublish,
 *        outside the block, before the repaint that wants it.
 *        Rule 87 was written from this and now describes what the
 *        code does: onPaint blits what exists and nothing else.
 *        GREEN: audit, dialog build, backdrop geometry with its
 *        poison red, preview abort, rect read.
 * 0.25  THE BUSY CROSS REACHES THE ONE MOMENT IT COULD NEVER
 *        REACH. His question: can it draw the lines that show it
 *        is processing, instead of a blank screen?
 *        It always drew them -- and onPaint could never get there.
 *        The paint begins `if ( vP.width < 1 || vP.height < 1 )
 *        return;`, and viewPort() is derived from imageSelection,
 *        which is EMPTY until the first render publishes. So the
 *        early return was taken at exactly the moment the user
 *        most needs telling that something is happening, and the
 *        cross below it was unreachable. 0.24 made this visible by
 *        opening the window before the render; the hole was always
 *        there, with no window to show it in.
 *        The same indicator is drawn corner to corner across the
 *        whole control instead. Not a new design: it is the cross
 *        that has always meant "this is working".
 *        AND A GATE THAT HAD QUIETLY ROTTED, caught by running it
 *        rather than by trusting it. verify_backdrop_geometry has
 *        been RED since 0.22, because that build set
 *        PREVIEW_BACKDROP false as a bisect and nothing re-ran the
 *        gate that the switch governs -- three builds with a red
 *        check nobody looked at. Rule 68 exactly: a red case rots,
 *        and this one rotted silently.
 *        It forces the switch ON for its own assertions now, the
 *        way verify_tiled_preview already does, and REPORTS what
 *        the shipped default is so a pass can never be misread as
 *        "the backdrop is enabled". The poison still takes six
 *        checks red.
 *        THE LESSON, worth a rule if it recurs: switching a
 *        feature off is a reason to RUN its gate, not a reason to
 *        skip it.
 * 0.24  THE WINDOW OPENS FIRST, THEN THE PROCESSING STARTS.
 *        His request and his reasoning, which is the whole point:
 *        a spinning icon on the PixInsight workspace reads as THE
 *        SOFTWARE HAS LOCKED UP, especially on a slower machine. A
 *        dialog already open, with a busy indicator in its own
 *        preview, reads as work in progress. The same wait carries
 *        the opposite message.
 *        dialog.execute() -- the call that SHOWS the window -- is
 *        the last thing an entry script does, and previewRefresh()
 *        ran during CONSTRUCTION. So everything the first render
 *        cost was spent before there was a window to put it in:
 *        "dialog built in 5861ms" on his 623 MB frame, all of it
 *        against a bare spinner. Rule 10 (constructors must not do
 *        expensive work) one level up from where it was written.
 *        The LAYOUT still runs synchronously and must -- the note
 *        above it records what rendering before the layout settles
 *        costs, and none of that changes. Only the RENDER is
 *        deferred, by one timer tick, which cannot elapse until
 *        the event loop runs, and the event loop does not run
 *        until execute() has put the dialog on screen.
 *        ONLY THE FIRST ONE, and that is what made it safe to do
 *        at all: line 88 is the ONLY previewRefresh during
 *        construction; every other call is an event handler with
 *        the window already open. Deferring those would put a tick
 *        between a control moving and the preview answering.
 *        A ONE-SHOT TIMER OF ITS OWN, not the debounce timer --
 *        that one carries rule 71's gesture deferral and
 *        reschedules itself, and borrowing it would tangle the
 *        first render with whatever the user is doing by then. It
 *        is stopped in onClose, and if it cannot be created the
 *        render happens inline: rendering early is the OLD
 *        behaviour, never rendering is a broken script.
 *        WHAT THIS DOES NOT DO: the open is not faster. Star
 *        detection, the statistics and the first transform are
 *        untouched. It changes where the wait is spent.
 *        SHARED CHANGE. MainDialog.js belongs to all eleven
 *        scripts; all eleven audit clean and build. Only this
 *        bench is bumped, because only this bench has been run.
 *        The sibling bump is owed at rollout (rule 65), together
 *        with 0.23's theme inversion.
 *        A GATE IS OWED TOO, and it is named rather than assumed:
 *        the dialog harness proves construction still SUCCEEDS,
 *        not that it no longer renders. Without that assertion
 *        this is rule 91's shape -- a change that ships, is
 *        described, and could quietly stop happening.
 * 0.23  THE CONTAINER TAB IS THE LIGHTER COLOUR, NOT THE BOX
 *        AROUND ITS CONTENTS. His request, drawn before it was
 *        built (rule 84) and approved from the drawing.
 *        It was inverted: the controls sat in a lighter panel
 *        while the title floated on the dialog floor between
 *        boxes, so the lighter element was the CONTENT AREA and
 *        the titles read as unattached. His words: "I would rather
 *        the container tab be the lighter color, so you can see
 *        each container visually separated with that lighter
 *        color, and then we follow on with the base colors for the
 *        items in the container."
 *        So THEME_PANEL_SHEET drops the panel to the floor shade
 *        and the new THEME_SECTIONBAR_SHEET gives the bar the
 *        lighter one. The band now says WHERE A SECTION BEGINS,
 *        which is the job it was always meant to do.
 *        THE OUTLINE GOES WITH IT: a band AND a box is the muddle
 *        being removed rather than a compromise between them.
 *        `border: none` is safe only on the CLASS selector -- in
 *        the bare `*` rule it would strip every value box and
 *        button inside the section of its own border, which is the
 *        trap already documented on that sheet.
 *        AND THE BAR ITSELF IS STYLED FOR THE FIRST TIME. The
 *        theme had only ever reached a SectionBar's collapse
 *        BUTTON; the bar was floor-coloured by inheritance. It is
 *        applied before the chip sheet so the toggle still wins.
 *        Guarded like every other sheet: a core that refuses it
 *        leaves the old look, not a broken one.
 *        SHARED CHANGE, NOT YET ROLLED OUT. Theme.js belongs to
 *        all eleven scripts and all eleven build and theme-wire
 *        with it -- but only this bench is bumped, because only
 *        this bench has been looked at. The sibling bump is owed
 *        when the rollout happens (rule 65).
 * 0.22  THE BACKDROP IS SWITCHED OFF, AS A BISECT -- AND THE
 *        BISECT CAME BACK POSITIVE: with it off the preview shows
 *        correctly. The backdrop was blanking it.
 *        THE MECHANISM, which the result now explains: proxyBitmapFor()
 *        built its bitmap LAZILY, INSIDE onPaint -- new Image(),
 *        applyStretchToImage(), renderImage(). applyStretchToImage
 *        runs a HistogramTransformation, and that PUMPS EVENTS. So a
 *        paint handler pumped the event loop while its Graphics object
 *        was still open, re-entering onPaint from inside itself.
 *        Every symptom follows from that one fact:
 *          - blank only with the screen stretch ON, because that is
 *            the only path that calls applyStretchToImage in a paint;
 *          - the repeated "Histogram transformation" blocks in his
 *            console at open, which is the re-entry showing;
 *          - toggling the stretch off and on FIXING it, because the
 *            proxy bitmap is cached afterwards and later paints do not
 *            re-stretch;
 *          - and blanking again on zoom, because the zoom invalidates
 *            that cache and the next paint stretches inside itself
 *            once more.
 *        Rule 33 already says publish atomically and never let a paint
 *        see a half-built state. This did something worse: it BUILT the
 *        state during the paint.
 *        THE FIX, not yet written: the proxy's stretched bitmap is
 *        built at PUBLISH time, where every other buffer is built and
 *        where pumping is already expected, and the paint only ever
 *        blits something that already exists. onPaint must allocate
 *        nothing and transform nothing.
 *        THE CONSTANT STAYS FALSE UNTIL THAT IS DONE. It is not to be
 *        turned back on without the build having moved. His preview
 *        opens BLANK on a 623 MB linear frame with the screen
 *        stretch on and stays blank through zooms.
 *        The backdrop (0.14) is the newest thing in the paint path
 *        and therefore the first suspect. One constant, one run:
 *        if the picture comes back it is the cause and gets
 *        repaired; if it stays blank it is innocent and the search
 *        moves on having cost nothing. Elimination rather than a
 *        fourth theory -- the screen-stretch correlation has been
 *        offered once already and a correlation is not a cause.
 *        THE CONSTANT DOES NOT STAY LIKE THIS. It goes back to
 *        true once repaired, or the backdrop comes out altogether.
 *        It is not to be left switched off and forgotten.
 *        0.21's reporting stays: it is not a fix and changes no
 *        behaviour, it only stops renderImage swallowing every
 *        exception in silence. If the panel is still blank, the
 *        console now says which of the four causes it is, and that
 *        is the whole point of it being there.
 * 0.21  THE BLANK PREVIEW GETS A VOICE. Diagnostic build.
 *        On a 623 MB linear frame with the screen stretch ON, the
 *        panel opens BLANK; toggling the stretch off and on shows
 *        it; zooming blanks it again. Four causes can produce that
 *        and the console said nothing about any of them.
 *        WHY IT SAID NOTHING: renderImage() caught EVERY exception
 *        and returned null in silence, and onPaint skips a null
 *        bitmap without a word. So a failing Image.render() or
 *        applyColorTransformation() looks exactly like a black
 *        picture. Rule 14 -- warn where the failure is silent --
 *        and rule 85: a decline that reports nothing cannot be
 *        told from a feature that is absent.
 *        Behaviour is UNCHANGED: a failure still yields null and
 *        the paint still survives it. It now says which stage
 *        failed, for which buffer size, and with the core's own
 *        message -- once per distinct fault, because a paint runs
 *        on every mouse move and an unthrottled warning is the
 *        silence it replaced.
 *        And onPaint reports having nothing to draw, listing which
 *        buffers exist: preview, original, their stretched copies,
 *        and whether the stretch is on. Those four causes are told
 *        apart by exactly that list.
 *        NO FIX HERE, deliberately. The correlation is strong --
 *        it tracks the screen stretch, and rule 33's case study
 *        records the same trigger from a dialog opening with the
 *        stretch already on -- but a strong correlation is not a
 *        cause, and one wrong theory has already been spent this
 *        session on the noise scaling. This build is the
 *        instrument, not the repair.
 * 0.20  THE PREVIEW GOES BLANK AT EVERY ZOOM ON A 623 MB FRAME,
 *        and the backdrop was doing it. His report was exact:
 *        "the only time it's not blank is when I reset the image
 *        to the starting place."
 *        The backdrop covers the WHOLE FRAME, so its destination
 *        rectangle is the frame's width times the zoom -- panel
 *        sized at a fitted view and unbounded as the zoom rises.
 *        On his 2368 px frame it stayed modest. On 9032x6028 it
 *        reaches tens of thousands of pixels from a 1129 px proxy,
 *        and asking the core for a scaled blit that size took the
 *        whole paint with it. Fit view worked because there the
 *        rectangle is roughly the panel.
 *        It is refused now beyond PREVIEW_BACKDROP_MAX_UPSCALE,
 *        and that is right whatever the core does with it: a proxy
 *        stretched more than a few times carries nothing the eye
 *        can use and nothing the sharp render is not about to show
 *        better. The backdrop exists to cover a gap, not to be
 *        looked at.
 *        A 9032x6028 case is in verify_backdrop_geometry now, in
 *        both directions -- it must still paint at the fitted view
 *        and must decline when the stretch turns absurd. One-sided
 *        would have passed a backdrop that refused everything.
 *        AND THE SPEEDS ON THAT FRAME, which is what it was opened
 *        to test: zoom rebuilds 4.5 to 6.0 s, read-rect 29 to 312
 *        ms on a 623 MB image where clone-and-crop would have been
 *        seconds, a double-click fit at 1891 ms reusing its cached
 *        result, and one pan at 1 ms with nothing recomputed.
 * 0.19  THE TILING IS SWITCHED OFF, ON ITS OWN EVIDENCE. Back to
 *        0.16's speed, which is the best measured so far.
 *        0.18 made the tiling run and it was much slower. His
 *        console gave both halves of the reason in two lines:
 *          20 tiles -- 0 reused, 20 computed
 *          16 tiles -- 0 reused, 16 computed      (this one a PAN)
 *        ZERO REUSE on a pan that overlapped the previous view
 *        heavily -- and reuse is the only thing that pays for
 *        tiling. The cause was named in the key's own comment the
 *        day it was written: the sky pedestal is the darkest pixel
 *        of the BUFFER, so it moves as the view moves and files
 *        every tile under a key nothing will ask for again. It was
 *        a stated risk, it was instrumented on purpose, and the
 *        instrument answered it in one run.
 *        The price of asking was the other half: the region has to
 *        grow outward to whole tiles, so his level buffer went
 *        from 842x644 to 1920x1536, 5.5x the pixels, with a halo
 *        per tile on top. A pan went 11.2 s to 21.3 s.
 *        SWITCHED OFF, NOT DELETED. The tiling is correct --
 *        verify_tiled_preview holds it at 0.000 sigma with no seam
 *        -- and worthless, and those are different problems. One
 *        constant governs the tiled path AND the region snapping,
 *        because 0.18's regression was exactly what happens when a
 *        feature has two switches and only one of them is off.
 *        WHAT IT NEEDS, and it is a real change: the pedestal must
 *        come from the FRAME rather than the buffer. That is
 *        arguably more correct anyway, since the sky's floor is a
 *        property of the sky and not of what is on screen -- but
 *        it changes preview output, so it gets measured and shown
 *        before it is switched on rather than slipped in.
 * 0.18  THE TILING ACTUALLY RUNS. 0.17 shipped it dead.
 *        deconPreviewTileGeometry asked for ctx.p.isPreviewRun()
 *        and NOTHING DEFINED IT -- behind a guard reading
 *        `typeof ... != "function"`, so it returned null on every
 *        call and the tiled path was never entered. Rule 83 in a
 *        new coat: a guard that can never succeed is worse than no
 *        guard, because it makes an absent feature look like a
 *        declined one.
 *        AND IT WAS WORSE THAN DOING NOTHING, which is why his log
 *        mattered. The REGION SNAPPING did engage, so every buffer
 *        grew from 842x644 to 1152x1152 to land on tile
 *        boundaries -- and then the whole enlarged buffer went
 *        through the untiled deconvolution. He paid the tiling's
 *        overhead and collected none of its benefit: a pan went
 *        from 11.2 s in 0.16 to 15.0 s. The tell was in the
 *        console and it was an ABSENCE -- no "N tiles" line
 *        anywhere, only the old whole-buffer cache message.
 *        BOTH HALVES ARE GATED NOW, because the two existing gates
 *        each proved a half and the fault lived between them.
 *        verify_tiled_preview proved the arithmetic of a function
 *        that was never called; verify_preview_abort listed the
 *        hooks but not this one. So: verify_preview_abort asserts
 *        isPreviewRun exists with the rest, and verify_tiled_
 *        preview asserts the DECISION both ways -- that a preview
 *        on a power-of-two level with an aligned origin tiles,
 *        that an Execute does not, that a non-power-of-two scale
 *        does not, that an origin off the level grid does not, and
 *        that the key moves when the sky pedestal does.
 *        WHAT HIS 0.17 LOG ALSO SHOWED, and it is worth keeping:
 *        the mask and Amount tier split from 0.13 is working
 *        exactly as intended on his frame. Rebuilds #5 to #10 are
 *        all "cached result reused", 1.1 to 4.2 s against a first
 *        pass of 15 s, with the transform down to 743 ms. That is
 *        the thing he asked for in the first place.
 * 0.17  THE DECONVOLUTION RUNS AS TILES ON A GRID FIXED TO THE
 *        FRAME, so a pan recomputes only what it exposed.
 *        His observation, and his console proved it: every pan
 *        said "computing (no matching entry of 3)". The result
 *        cache was keyed on the BUFFER -- its size and a hash of
 *        its content -- so a pan of one pixel was a total miss, by
 *        construction. A tile's identity is its place in the FRAME
 *        at a level, so panning changes which tiles are wanted and
 *        never what a tile holds.
 *        ACCELERATION IS OFF IN TILES, and that is measured rather
 *        than conceded. Biggs-Andrews takes its step from the
 *        whole buffer, so tiles diverge by 232 sigma and no halo
 *        repairs it. The repair was to share one step sequence,
 *        which verify_shared_step_tiling proves works -- but the
 *        same tool measured what acceleration is WORTH at 20
 *        iterations: 1.1% of rms. So the simple thing is the right
 *        thing. Execute keeps the accelerated whole-frame path,
 *        because Execute is the result he keeps.
 *        THE SIZE IS MEASURED. measure_tile_economics.js on his
 *        geometry: 384 is the only size that wins on the session
 *        AND the pan (first look 2.19x, steady pan 0.37x, session
 *        20s against 32s). It is not a smooth curve -- the FFT
 *        picks its transform size by cost, so 256 costs 1557 ms a
 *        tile and 384 costs 1684 ms for 2.25x the area.
 *        THE FIRST LOOK GETS WORSE AND THAT IS REAL: a fixed grid
 *        computes WHOLE tiles, so an 842x644 panel lands on nine
 *        384-tiles covering 1152x1152. Those off-screen pixels are
 *        the pan margin again, with the one difference that
 *        decides it -- they are CACHED. That is what rule 81 meant
 *        by the lever being caching rather than the margin.
 *        KNOWN AND MEASURED, NOT HIDDEN: the tile key carries
 *        sigma and the sky pedestal because both are arguments to
 *        the iteration. Sigma comes from the whole-image star
 *        profile and is stable; the pedestal is the darkest pixel
 *        of the BUFFER, so it moves with the view and will throw
 *        tiles away. The console reports reused-against-computed
 *        on every pass so the size of that is measured. If it is
 *        the pedestal, the fix is to take it from the frame, which
 *        changes preview output and so gets shown first.
 *        AND THE DOUBLE CLICK ZOOMS OUT FIRST. "It processed still
 *        on that zoomed view versus going back to the original."
 *        Right, and the log said so: rebuild #5 arrived "from ?"
 *        -- the one gesture that rebuilt without saying who it
 *        was. Every other zoom arms a stand-in so the view moves
 *        at once and sharpens later; this one did not, so the
 *        painter kept the old bitmap and the backdrop stayed
 *        zoomed with it. It now hands the whole frame to the
 *        painter, which the backdrop already holds, so a double
 *        click snaps out immediately and sharpens after.
 *        tools/verify_tiled_preview.js gates the SHIPPED function
 *        rather than the idea -- grid arithmetic, halo clamping at
 *        the frame edge, core extraction, the cache and the stitch
 *        -- at 0.000 sigma against the untiled result, with no
 *        seam on any boundary, and asserts a cached pass returns
 *        exactly what it returned before. Its poison removes the
 *        halo and lands 23.757 sigma on a tile corner.
 * 0.16  THE CROP STOPS COPYING THE WHOLE FRAME. Groundwork for
 *        the tiling, and worth having on its own.
 *        From his console, on EVERY rebuild: clone 453 ms, crop
 *        849 ms -- to obtain a 1685x1287 region of a 2368x2906
 *        frame. cloneView allocated and copied the ENTIRE image
 *        and a Crop process then threw almost all of it away, so
 *        both costs scaled with the WHOLE IMAGE rather than with
 *        the region. On the 600 MB frames this is being built for
 *        that pair is several seconds before any arithmetic runs.
 *        readRectToView (shared/lib/Utilities.js) copies only the
 *        rectangle, through the same getSamples path the engine's
 *        own block streaming already uses -- so it is the proven
 *        route rather than a new one -- and with the no-swap undo
 *        flag, which is why "Writing swap files..." no longer sits
 *        between every stage.
 *        THE REASON IT IS FIRST: tiles read their own source. A
 *        tiled pipeline built on clone-then-crop would clone the
 *        whole frame ONCE PER TILE, so this is a prerequisite and
 *        not a detour.
 *        The Crop machinery is removed rather than left switched
 *        off: residue that still configures itself reads as
 *        load-bearing (rule 34).
 *        tools/verify_rect_read.js is the gate. It drives the real
 *        function against a recording stand-in and checks the
 *        rectangle asked for against the one the OLD Crop margins
 *        described, restated independently -- agreeing with what
 *        is being replaced is the whole assertion.
 *        AND THE POISON HAD TO BE FIXED BEFORE IT COUNTED: the
 *        first one corrupted the FIXTURE, so the expected value
 *        moved with it and the red case ran GREEN. It edits the
 *        clamp out of the function now, and refuses to run at all
 *        if that edit stops matching (rule 68).
 * 0.15  A DRAG ABANDONS THE RENDER IT INTERRUPTS. His report:
 *        "when I start panning, it starts processing before I even
 *        let my finger off the mouse ... even when it starts
 *        processing, the mouse kept panning, and I was trying to
 *        click my mouse buttons just to exit out of that."
 *        NOT CAUSED BY 0.14, and the diff proves it: the backdrop
 *        touched no gesture code at all. It made the fault
 *        VISIBLE. Before it, the uncovered area was black, so a
 *        drag during a rebuild slid a black region about and
 *        looked like nothing happening. With a backdrop under it,
 *        the picture moves under his hand and behaviour that was
 *        always there is finally on screen. The tempting
 *        conclusion was that the new feature broke the mouse.
 *        WHAT IT ACTUALLY IS: deconIterationTick pumps the event
 *        loop on EVERY RL iteration -- deliberately, so fifteen
 *        seconds does not read as a frozen application. Mouse
 *        events are therefore delivered right through a rebuild,
 *        and onMousePress had no busy guard: a press mid-render
 *        starts a full gesture, every move pans, and the release
 *        then threw away a render that had completed during the
 *        drag (resolveHeldPublish( true )).
 *        THE FIX: a gesture that has MOVED abandons the render in
 *        flight. The tick already runs twenty times per
 *        deconvolution, so it is the cancellation point and costs
 *        one boolean per iteration. Requested on movement rather
 *        than on the press, so a click -- or one of the buttons he
 *        pressed trying to escape -- cannot discard a render that
 *        was about to arrive.
 *        PREVIEW ONLY, and that is the part worth the care.
 *        Execute runs the same method through the same tick, and a
 *        stray click aborting THAT would leave a half-deconvolved
 *        image and report success: a wrong result rather than a
 *        slow one. The abort is honoured only between
 *        setPreviewRun( true ) and false, which only the preview
 *        control calls.
 *        AND A TRAP FOUND BY READING RATHER THAN BY TESTING: the
 *        deconvolution's catch treats any throw from the iteration
 *        as the native convolver dying and RE-RUNS the entire
 *        deconvolution, so cancelling would have cost more than
 *        not cancelling. The error carries a TAG and Methods.js
 *        rethrows it before that retry -- a tag rather than a
 *        message, so no rewording can reconnect the two.
 *        tools/verify_preview_abort.js is the gate. Four checks;
 *        the one that matters runs a real iteration with the flag
 *        ALREADY SET and asserts an Execute finishes all twelve
 *        with every sample finite. Its poison removes the gate and
 *        takes exactly that check red.
 * 0.14  A PAN NEVER SHOWS BLACK AGAIN. His screenshot, and his
 *        words: "when panning there is no data on either side,
 *        this is an issue I want to avoid."
 *        THE CAUSE, from his log rather than from a theory: the
 *        rendered buffer is 1062x807 for a panel of about that
 *        size, so there is no data outside the panel at all and
 *        ANY drag exposes black instantly. commitPan renders the
 *        panel and nothing else, deliberately -- its own comment
 *        called the black the accepted price until tiling exists.
 *        THE MARGIN IS STILL NOT THE ANSWER, and this is the
 *        fourth time it has been asked to be: 0.75 on every side
 *        is 2.5x the panel per axis and 6.25x the pixels he can
 *        see, and one such pass was measured at thirty seconds.
 *        It cannot be scheduled into being cheap.
 *        HIS OWN PROPOSAL, and it is what Photoshop does: read a
 *        copy of the whole image while panning and recompute when
 *        the pan stops. The refinement is not to read it at full
 *        resolution -- clone and crop cost 1.2 to 1.5 s of every
 *        rebuild on an 82 MB frame, and that cost tracks the whole
 *        image rather than the region -- but to keep a coarse
 *        whole-frame proxy.
 *        THE PROXY WAS ALREADY BEING COMPUTED AND THROWN AWAY.
 *        The first rebuild after opening renders the ENTIRE frame:
 *        his log shows no Crop line and a 592x726 level buffer for
 *        a 2368x2906 image. The first zoom discarded it. Keeping
 *        it costs one copy of a panel-sized buffer, about 6 MB,
 *        and nothing is computed for it.
 *        TWO PROXIES, because one can go stale and the other
 *        cannot: the transformed one matches what the sharp render
 *        will show and stops matching the moment a deconvolution
 *        parameter moves; the untransformed one is only ever wrong
 *        about sharpness. Fresh transformed when there is one,
 *        untransformed otherwise, black never.
 *        WHAT IT DOES NOT DO, said plainly: it does not make a pan
 *        fast. 84% of his 13.6 s pan is the forty convolutions,
 *        and only tiling touches that. This makes the wait show
 *        the picture instead of a hole.
 *        tools/verify_backdrop_geometry.js is the gate, and it is
 *        the check that matters: the backdrop and the sharp render
 *        reach the screen through DIFFERENT code -- bitmapOrigin
 *        anchors on the rendered region, drawBackdrop on the whole
 *        frame -- so a disagreement would show as the picture
 *        sliding against its own background. It drives both, on
 *        five geometries including a margin pass and a wheel zoom
 *        in flight, and measures 0.000 px on every one. Its poison
 *        shifts the backdrop a quarter panel and takes six checks
 *        red.
 * 0.13  A MASK CHANGE STOPS REDOING THE DECONVOLUTION, WHICH IT
 *        WAS NEVER SUPPOSED TO DO AND HAD ALWAYS DONE.
 *        His instruction: "if we make a change to the mask, then
 *        that's the only thing that needs to get updated and not
 *        the whole routine." That reuse was already written -- the
 *        engine keeps a small LRU of deconvolved buffers keyed on
 *        the parameters that feed the iteration, and Amount and
 *        every mask control are deliberately absent from that key.
 *        It had never once run on his data.
 *        DECON_CACHE_MAX refused any buffer over 4,194,304 samples
 *        and his ordinary zoomed preview is 4,497,061 -- seven per
 *        cent over. Above the cap no key was even built, so there
 *        was not so much as a log line to say the reuse had
 *        declined. The measurement everyone trusted was taken on an
 *        800x600 fixture that fitted.
 *        The fault is rule 40's: a per-buffer sample count is a
 *        PROXY. What the constant was protecting is MEMORY -- its
 *        own comment said so -- so the limit is stated in bytes now
 *        and summed over the entries actually held
 *        (DECON_CACHE_BYTES, 128 MB). A full-resolution Execute
 *        result is still declined, which is the case it existed
 *        for.
 *        MEASURED on Test_5 at 6.88 MP, which is above the old cap:
 *        a mask control cost 9469 ms before and 3300 ms after,
 *        against a deconvolution control's 13607 ms -- a ratio of
 *        1.08 before, 0.24 after. Returning to a decon setting
 *        already computed went from 9490 ms to 3271 ms. The cached
 *        result is BITWISE identical to a fresh one over all
 *        20,644,224 samples.
 *        tools/verify_tier_split.js is the gate, and it needs no
 *        poison switch: alternating a DECONVOLUTION parameter must
 *        stay expensive, that run is measured every time, and it
 *        fails the file if over-eager caching ever makes it cheap.
 *        WHAT IS LEFT, measured rather than assumed: of the 3300 ms
 *        a mask change still costs, 1911 ms is the analyse stream
 *        rebuilding the edge map -- which no mask control affects
 *        -- and 1382 ms is the composition, which they genuinely
 *        do. The edge map is the next thing to cache.
 *        Also: 0.10's history entry appeared TWICE, an older draft
 *        above 0.12 and the final one below 0.11, because two
 *        commits shipped as 0.10 without a bump. The stray draft is
 *        removed. Rule 65 is not only about the number.
 * 0.12  THE DRAG FOLLOWS THE MOUSE. "It stops me a few pixels and
 *        starts reprocessing again." Clamping the painted drag to
 *        the rendered buffer stops the picture while the gesture
 *        continues, which is the fault rule 81 exists for -- it does
 *        not help that the pan lands where he asked, because what he
 *        feels is the picture refusing to move under his hand. The
 *        drag is limited by the IMAGE now and nothing else. The
 *        blank at the leading edge is the honest cost of not having
 *        computed those pixels, and the way to make it brief is to
 *        make the REBUILD brief -- fewer iterations to a first
 *        result -- not to hobble the gesture.
 * 0.11  THE DRAG PAINTS WHAT IT HAS AND COMMITS WHAT HE ASKED
 *        FOR, and that ends an argument that cost four builds.
 *        0.10 made a pan render the surround. At his zoom the
 *        surround is 2368x2380 against a 1317x1000 panel, so his
 *        first pan took THIRTY SECONDS and locked him out while it
 *        ran. "This shit is so fucked up." Correct: it made a pan
 *        the most expensive action in the program.
 *        THE LESSON, written down because it has now cost three
 *        attempts: the margin is 2.5x the panel per axis, so ANY
 *        scheme that renders it in one go costs six panels --
 *        pre-rendered after a zoom, deferred on a timer, or
 *        triggered by a pan. It cannot be scheduled into being
 *        cheap. Only computing the newly exposed strip can do that,
 *        and that is the tiling.
 *        So no margin is rendered at all, and the pan is solved a
 *        different way: TWO OFFSETS. What the drag PAINTS is
 *        clamped to the rendered buffer, so it can never pull the
 *        picture off the panel and leave black -- he photographed
 *        that in 0.09, two thirds of the view empty under a busy
 *        cross. What the release COMMITS is the whole gesture,
 *        unclamped, so the view goes exactly where he dragged.
 *        Measured: painted 24 px, committed 1000. The pan cannot
 *        stop dead (rule 81) and cannot uncover the panel; the only
 *        cost is that the drag feedback runs out before the gesture
 *        does, and the rebuild lands where he asked.
 *        A pan is one panel of work now -- the same as a zoom, the
 *        same as a slider. Nothing in the preview costs more than
 *        one panel any more.
 * 0.10  THE MARGIN IS PAID FOR WHEN HE PANS, AND ONLY THEN.
 *        0.09 removed it entirely, and that traded one complaint
 *        for two: the first drag after a zoom had nowhere to go
 *        ("it does not allow me to pan now") and once the drag was
 *        freed it uncovered black where nothing had been rendered
 *        ("and leaves a bar").
 *        The margin was never the problem. Rendering it after every
 *        ZOOM and every SLIDER was -- 17.3 s of surround after a
 *        14.6 s picture, for travel he had not asked for. Rendered
 *        when he actually pans it is evidence rather than
 *        speculation: he is panning, so he will pan again, and
 *        every pan after the first is free.
 *        So: a zoom renders the panel and stops. A slider renders
 *        the panel and stops. A PAN renders the panel plus the
 *        margin, once, and the drags that follow cost nothing.
 *        The drag still reaches anywhere in the frame in one
 *        gesture (700 px measured where the buffer ends after 24),
 *        so the pan cannot stop dead the way rule 81 was written
 *        for. What remains is a moment of un-rendered area at the
 *        leading edge of the FIRST drag after a zoom, which the
 *        rebuild fills. Removing that needs the tiling: compute the
 *        newly exposed strip and stitch it, which
 *        verify_tile_agreement already proves is safe at a 24 px
 *        halo.
 * 0.09  THE PAN MARGIN IS NOT RENDERED AT ALL. His numbers, one
 *        zoom: 14.6 s for the picture, then 17.3 s for the margin
 *        -- 54% of the wait on travel he had not asked for, and the
 *        second pass recomputed the visible region on its way
 *        there. "It's faster just to stay unzoomed." It was, and
 *        that is an indictment of the design, not of the zoom.
 *        A zoom is ONE computation now. So is a parameter change.
 *        THE PAN CONTRACT IS MET A BETTER WAY, and this is why it
 *        is not rule 81 broken a fourth time. That rule exists
 *        because the pan kept STOPPING DEAD -- the drag was clamped
 *        at the edge of the rendered buffer, so a margin had to be
 *        pre-rendered to give it room. clampPanOffset no longer
 *        consults the buffer at all: a single drag now reaches
 *        anywhere in the frame (measured in the harness: 700 px of
 *        travel where the buffer ends after 24), and whatever lies
 *        beyond it paints as background until the rebuild on
 *        release fills it. More reach than the rule asks for, not
 *        less. The cost is that a pan is a rebuild rather than
 *        free, which at one panel-sized pass is the trade he asked
 *        for.
 *        The margin timer, its constant and the fill methods are
 *        deleted rather than disabled (rule 37), and both verifiers
 *        were rewritten to assert the new contract -- including the
 *        drag reach, which is now the thing protecting rule 81.
 * 0.08  NO SECOND PASS WHEN THERE IS NO MARGIN TO FILL. From his
 *        console with NO zoom at all: the visible pass rendered
 *        592x726 and the margin pass rendered 592x726 -- the same
 *        region, re-cropped, re-resampled and re-published for two
 *        and a half seconds, on every parameter change. Both
 *        regions clamp at the image bounds, so at a fit view (and
 *        at any zoom where the frame is fully on screen) they are
 *        identical and the second pass is pure waste.
 *        The mode records what the buffers ACTUALLY cover now
 *        rather than what was requested: equal regions means the
 *        margin is already delivered, no fill is armed, and the
 *        second pass never happens.
 * 0.07  A PARAMETER CHANGE NO LONGER INHERITS THE MARGIN, which
 *        is most of what he still felt as double processing. From
 *        his console: "rebuild #5 from refreshTransform 12899ms
 *        source 1184x1388 [visible]". A transform-only rebuild
 *        reuses the cached level buffer, and once the margin fill
 *        has run that buffer covers the margin -- so every slider
 *        move re-transformed 1.64 megapixels to show 0.54, three
 *        times the work, and kept doing it for as long as he kept
 *        adjusting. It even said [visible] while doing it, which is
 *        how it stayed invisible.
 *        Such a pass now rebuilds its source at panel size: a crop
 *        and a resample, about 1.3 s, against some eight seconds of
 *        transform saved. The margin refills two seconds after he
 *        stops, exactly as after a zoom.
 * 0.06  THE SUNSPOTS COME BACK, and the margin stops being paid
 *        for twice.
 *        THE DARK-FEATURE BUG. His solar frame: deconvolution
 *        turned the sunspots grey and no setting helped, which was
 *        exact -- the background b is not a control, it is computed
 *        internally, and Noise control scales TV and damping and
 *        never touches it. b was the FIFTH PERCENTILE minus 2
 *        sigma. On Solar-1 that is 0.3466 while the darkest pixels
 *        are 0.1352, so 3.24% of the frame had estimate u = obs - b
 *        <= 0; Richardson-Lucy is multiplicative, so those stayed
 *        zero for all twenty iterations and returned as exactly b.
 *        Measured: a 25x25 patch on the umbra came back as one
 *        value, contrast 0.1242 -> 0.0000, 100% pinned. His words,
 *        which name it better than mine: "it's like the bottom half
 *        of the highpass filter is being ignored."
 *        b is the FLOOR of the data now. The fifth percentile was
 *        never load-bearing: on the astro frames it was designed
 *        for the sky IS the floor, so on Test_1 this moves b by
 *        0.00054 -- three sigma -- and the truth harness still
 *        reports the ring held at 4.9 sigma against 63.2 with no
 *        pedestal. On Solar-1 it moves to 0.1276, below every
 *        pixel, and keeps 97.6% of the umbra's detail -- better
 *        than dropping the term entirely (92.4%), which is what
 *        PixInsight's own Deconvolution effectively does: its panel
 *        has no background term at all and handles ringing with a
 *        separate Deringing control.
 *        tools/measure_dark_feature_flattening.js compares all
 *        three rules on a real frame. It first restated only the
 *        old rule and so went on reporting the old behaviour after
 *        the code was fixed -- rule 39 from the inside.
 *        AND THE MARGIN IS SCHEDULED, NOT RUN. His report on 0.05:
 *        "when zoomed in it's like it's calculating double". It
 *        was: the margin pass followed every visible pass, so a
 *        zoom cost 13.5 s to a picture and 31 s more for pan travel
 *        he had not asked for -- 45 s against 29 s before. The
 *        margin region CLAMPS at the image edges on his frame, so
 *        it is only 2-4x the visible region rather than the 6.25x a
 *        large frame gives: the saving shrinks and the extra work
 *        does not. It is armed on a timer now
 *        (PREVIEW_MARGIN_DELAY_SECONDS 2.0) and cancelled by the
 *        next request, so a run of zooms costs one visible pass
 *        each and the margin arrives only once he settles.
 * 0.05  THE FIRST PASS COVERS THE PANEL, not just the selection.
 *        His report on 0.04: "I zoomed in, then it cropped itself,
 *        reprocessed, then undid the crop." Exactly what it did.
 *        viewPort() CENTRES the selection in the control, so on a
 *        frame whose aspect does not match the panel the selection
 *        fills one axis and is inset on the other -- his portrait
 *        frame put a 626-wide viewport in a 1024-wide control. The
 *        painter draws the WHOLE rendered buffer, so the pan margin
 *        has always spilled over and filled that inset without
 *        anyone noticing. Sizing the first pass from the SELECTION
 *        stopped covering it: 688x830 for a 1024x768 panel, so the
 *        image appeared narrower until the margin pass arrived and
 *        put it back. marginSelection has this right and says so at
 *        length; visibleRegion now uses the same geometry with a
 *        margin of zero. The saving comes from not rendering the
 *        MARGIN, never from rendering less than the panel.
 * 0.04  WHAT IS ON SCREEN IS RENDERED FIRST. His console, zoomed:
 *        a 2324x1921 buffer transformed to fill a 1024x768 canvas
 *        -- forty native convolutions at 435 ms, twenty-seven
 *        seconds, and FIVE SIXTHS OF IT on pixels off screen. The
 *        pan margin was computed before anything appeared at all.
 *        THE MARGIN IS NOT REDUCED -- rule 81, broken three times
 *        already, and a smaller margin IS less pan travel whatever
 *        the excuse. It is rendered SECOND. The first pass covers
 *        the selection plus this method's measured reach
 *        (PREVIEW_METHOD_HALO 24 px, from verify_tile_agreement:
 *        0.00 sigma against an untiled result, stars on the
 *        boundary included), publishes, and he is looking at a
 *        correct picture while the margin fills behind it. Measured
 *        in the harness: first pixels 5.46x sooner, total work
 *        1.18x, and the full 2.50x-per-axis margin still arrives.
 *        The margin pass is SKIPPED when a newer request is already
 *        queued or a gesture is open -- spending twenty seconds
 *        filling a margin for a view he has left is the exact waste
 *        this is about.
 *        And a pan will not take the free path while only the
 *        visible region exists, because there is nothing outside it
 *        to pan into; showing stale canvas is not "fast".
 *        verify_visible_first.js asserts both directions -- the
 *        first pass is genuinely small AND the margin genuinely
 *        arrives. VISIBLE_POISON=1 renders the margin first, which
 *        is the old behaviour, and it goes red.
 *        Two older verifiers asserted one method call per rebuild
 *        and now legitimately see two; updated with the reason
 *        rather than relaxed.
 * 0.03  THE LEVEL ROUNDS TO NEAREST, from his console. 0.02 chose
 *        the finest level AT OR ABOVE the display scale, so the
 *        processed pixels were never coarser than the screen -- and
 *        that cost up to 4x the pixels the display needed, 2.04x on
 *        average. His fit-to-window zoom of 0.264 landed on level
 *        0.5 and put 3.58x through the deconvolution: source
 *        1184x1453 for a 626x768 display, and a nineteen-second
 *        open where the old display-scale path would have taken
 *        about five. A regression I handed him before the cache
 *        that repays it existed.
 *        Nearest instead: 1.13x on average, 2x at worst, and 0.89x
 *        at that same fit zoom -- CHEAPER than processing at the
 *        display scale at all. The price is that the level may sit
 *        below the display scale, so the result is upsampled by at
 *        most sqrt(2) per axis. The preview is already an
 *        approximation (rule 18) and his bar is that it be CLOSE;
 *        a factor of two in wait is not worth sub-pixel sharpness
 *        that has to be judged at 1:1 anyway.
 *        The verifier asserts the COST BOUND now rather than the
 *        no-upsample property -- what he feels is the wait.
 * 0.02  THE PREVIEW STOPS RECOMPUTING WHAT IT ALREADY HAS.
 *        Two changes, and the first is the one to feel.
 *        A PAN INSIDE THE RENDERED REGION NOW COSTS NOTHING. The
 *        preview renders the selection plus PAN_MARGIN on every
 *        side -- 2.5x the canvas per axis, measured here at 5.74x
 *        the visible pixels -- and that margin exists so a pan has
 *        real data to reveal. It was never once used for it:
 *        commitPan rebuilt the source, so every pan cloned,
 *        cropped, resampled and re-transformed the whole margin to
 *        show pixels already sitting in the buffers. The margin has
 *        been paid for on every rebuild since it was introduced and
 *        bought only the absence of empty canvas during the drag.
 *        Now: same size, still inside what was rendered, nothing
 *        making the transform stale -- move the selection and
 *        repaint. Zero method calls, zero crops of the frame, the
 *        same buffers and the same bitmaps.
 *        What makes it safe is BEING TOLD rather than guessing.
 *        rebuild() takes transformDirty; a gesture says false, a
 *        parameter change says true, coalesced requests OR it, and
 *        the default is true so a caller that says nothing gets the
 *        full transform. verify_pan_reuse.js asserts both halves --
 *        a pan inside runs no method, and a pan carrying a
 *        parameter change still does. PAN_POISON=1 makes every
 *        gesture declare itself stale, which is the old behaviour,
 *        and four assertions go red.
 *        AND THE PROCESSING SCALE IS QUANTISED (see the Template's
 *        history for the argument): the method runs at the finest
 *        level at or above the display scale rather than at the
 *        display scale itself, so two zooms inside one level
 *        produce the identical processed buffer. That is what makes
 *        a cache possible at all; the cache itself is the next step.
 *        Also fixed: the nine tools that read the entry script by
 *        NAME, all of which broke at once when the clone renamed it.
 * 0.01  TEST BENCH, cloned from Deconvolution 0.30 at his
 *        instruction so the shipping script cannot be broken
 *        while the preview pipeline is rebuilt. Identical maths;
 *        its own SCRIPT_ID and KEYPREFIX so saved settings and
 *        process instances never touch the real script's. No
 *        icon, deliberately -- build_repository.py only publishes
 *        a folder that has one, so this cannot ship by accident.
 *        The history below belongs to the script it was cloned
 *        from and is kept because the maths came with it.
 * 0.30  THE SWAP FILES, and it is rule 83 for the second time in a
 *        day. The native convolver asked for the no-swap undo flag
 *        by NAME -- UndoFlag_NoSwapFile -- which PJSR declares as a
 *        preprocessor define in pjsr/UndoFlag.jsh, a header this
 *        script does not include. The identifier therefore did not
 *        exist at runtime, beginProcess() threw on EVERY call, and
 *        the guard fell back to DEFAULT undo flags -- so the core
 *        wrote a swap file for every one of the forty setSamples in
 *        a rebuild. His console showed it plainly: "Writing swap
 *        files..." between every convolution, one at 0.271 MiB/s.
 *        The comment above the code claimed this was guarded and
 *        avoided; a guard that fires every time is not a fallback,
 *        it is the code path.
 *        Now passed BY VALUE from the platform's header (0xFFFFFFFF,
 *        as the signed -1 PJSR wants, with the unsigned spelling
 *        tried second), and if a core refuses both it says so ONCE
 *        instead of silently paying forty times. This is the ~15 s
 *        of wrapper overhead measured in 0.29's note.
 * 0.29  RL BOOKKEEPING: the TV divergence is consumed where it is
 *        computed instead of being written to a Float32Array and
 *        read back by the next pass -- one full pass over the buffer
 *        and one buffer of it gone per iteration (18 MB at his
 *        zoomed preview size). NOT bitwise identical, and the reason
 *        is worth recording: storing the divergence rounded it to
 *        single precision, so computing it inline is the MORE
 *        accurate of the two -- 92 of 12513 fixture pixels differ,
 *        by at most 2.3e-7 relative, one or two float32 ULPs. Every
 *        truth-harness gate passes unchanged.
 *        MEASURED, from his console and a matching bench at his
 *        buffer size (2341x1921, 20 iterations): of a 48 s
 *        transform, ~29 s is the forty native FFT convolutions,
 *        ~3.8 s is all of the JS arithmetic, and ~15 s is the native
 *        wrapper's per-call overhead -- padding, setSamples,
 *        endProcess and getSamples moving 18 MB in and out forty
 *        times. The JS side was never the problem; that wrapper
 *        overhead is the next real target.
 * 0.28  THE PAN CONTRACT IS RESTORED, and the attempt that broke it is
 *        withdrawn. Rule 81 says the margin is 0.75 in every script and is
 *        NEVER the lever for speed; the previous build shrank it for
 *        transforms measured as expensive, and the pan clamp was reported
 *        within the hour -- the fourth report of that one bug. A smaller
 *        margin IS less pan travel, whatever the justification, and no
 *        measurement makes that acceptable. marginSelection no longer even
 *        ACCEPTS an override, and verify_wheel_standin.js now enforces the
 *        rule: no override, no cost test at the render-region choice, and
 *        PAN_MARGIN 0.75 asserted in all ten entry scripts. A rule that
 *        lives only in a document gets broken.
 *        WHAT SURVIVES, because it costs the user nothing: the wheel waits
 *        longer before committing when the transform is expensive (his
 *        report -- one accidental notch, reaching for a pan, used to commit
 *        before it could be scrolled back, and half a minute went with it).
 *        0.3 s for a cheap transform, 1.5 s for an expensive one, decided by
 *        what the last pass measured per visible megapixel. That number
 *        sizes the delay and nothing else.
 *        THE ZOOM FLASH stays fixed (the stand-in now ends at applyPublish,
 *        not when the rebuild starts), and EXECUTE and the STATISTICS are
 *        untouched as always: Execute runs over the target view itself, and
 *        median/MAD come from the full target view cached per view, never
 *        per zoom -- so a stretch places the whole image's median however
 *        far in you are looking. Both are asserted now.
 *        DECONVOLUTION'S ZOOM COST IS THEREFORE STILL OPEN: 540 ms per
 *        megapixel per RL iteration, 6.25x of it for the pan margin. The
 *        honest levers are caching and the cost per pixel, not the margin.
 *        THE DRAWN ZOOM BOX NOW BEHAVES LIKE THE WHEEL (his report: "it
 *        processes first before it actually zooms in, which is
 *        backwards"). Both gestures queue a selection and both wait on the
 *        same rebuild, but only the wheel armed the scaled stand-in, so a
 *        boxed zoom drew the OLD un-zoomed view under the busy cross for
 *        the whole transform and arrived at the new view last. One line;
 *        the checks now assert both paths arm it.
 * 0.27  THE ZOOM FLASH, fixed at the right moment this time (his
 *        report, from video, twice: wheel to zoom, stop, and the
 *        preview SNAPS BACK to where it was, waits out the
 *        transform, then arrives at the zoomed view).
 *        A wheel notch only queues a selection -- the rebuild waits
 *        for wheel-quiet -- so between notch and render the painter
 *        draws the current bitmap SCALED to the queued zoom. That
 *        stand-in is the entire gesture's feedback, and it was being
 *        cancelled at the START of a transform that then runs for
 *        seconds, repainting a busy indicator over whatever the
 *        painter could draw: the old buffer, at the old zoom. The
 *        earlier fix moved that cancellation from the wheel commit
 *        to where rebuildOnce consumes the queued selection -- still
 *        the start of the transform, so the flash survived and was
 *        reported again. The painter now reads standInSelection, a
 *        field of its own that no rebuild touches, and applyPublish
 *        clears it: the one moment the render that replaces it
 *        actually exists. Dropped too when the target changes or a
 *        queued zoom is abandoned, so a stand-in cannot outlive its
 *        image. New check, shared/tools/verify_wheel_standin.js,
 *        asserts the ORDER on the shipped source and goes red on the
 *        exact form that shipped twice.
 * 0.26  NO MORE BOXES AROUND THE LABELS (his report: "all of these
 *        text boxes, whether they're blank or not, have outlines
 *        around them"). The section panel's sheet is set on the box
 *        with BARE declarations -- the form that reliably reaches a
 *        PCL control -- but Qt matches those declarations against
 *        every DESCENDANT too, so `border: 1px solid` was drawing a
 *        rounded rectangle around every label and every empty cell
 *        in the section. The fill still reaches the children, which
 *        was always right; the border is confined to a class
 *        selector, and no border is declared for the rest, since
 *        saying `border: none` there would strip the value boxes and
 *        buttons of the borders the dialog sheet gives them.
 *        US SPELLING THROUGHOUT THE INTERFACE (his report, raised
 *        before): color, not colour, and the same for neutralize,
 *        normalize, center, gray and their relatives. TEXT ONLY --
 *        `colourProtection` and `colour` are PERSISTED SETTINGS KEYS
 *        and keep their spelling, because renaming one orphans every
 *        saved setting and process icon; "centre" is also a drag
 *        state and a property name in the hue wheel.
 * 0.25  THE GLOBAL RESET BUTTON, the one button in the dialog still
 *        wearing the stock look (his screenshot). It is
 *        dialog.resetButton -- one letter from dialog.resetButtons,
 *        the per-row list declared beside it -- and a hand-written
 *        list of the dialog's buttons simply skipped it.
 *        verify_theme_wiring.js now DERIVES that list from
 *        MainDialog's own source, matching every
 *        `this.<name>Button = new ToolButton`, so a button added
 *        there and not styled fails a check instead of a
 *        screenshot; poisoned, it names the missing button.
 * 0.24  THE ICON BUTTONS GET A LIGHT FACE -- the point behind every
 *        "I can barely see the reset buttons" report, finally heard.
 *        PixInsight's icons are drawn DARK, for its light stock
 *        theme; on a dark chip a dark glyph is an EMPTY SQUARE, and
 *        outlining that square in white changes nothing, because the
 *        glyph inside is still dark on dark. His words: stop
 *        outlining things in white, make the thing itself contrast.
 *        So every icon button now has a light face and a quiet grey
 *        edge -- the per-row reset buttons, the dialog's own row
 *        (new instance, execute, cancel, real-time, documentation,
 *        diagnostics), the preview's zoom trio, and THE SECTION BAR
 *        COLLAPSE TOGGLES, which had never been styled at all: PJSR
 *        builds that button inside SectionBar, so nothing in this
 *        codebase held a reference to one until it was reached
 *        through bar.button.
 *        Also: 0.23's drop-down arrow was a CSS border-triangle,
 *        chosen to force it white. On the web that draws a triangle;
 *        Qt fills ::down-arrow as a BOX, so every dropdown showed a
 *        solid white SQUARE -- a regression on an arrow that had
 *        rendered correctly since 0.21. The platform's light arrow
 *        image is back, the compartment's divider is quiet grey
 *        again, and the verifier FAILS if the triangle form returns.
 * 0.23  WHITE ARROWS AND WHITE-EDGED ICON BUTTONS -- his call, asked
 *        for three times while grey after grey was offered instead,
 *        and approved from a drawing before this was built. The
 *        drop-down arrow is drawn as a CSS triangle in #ffffff
 *        rather than loaded from a resource, so there is no asset
 *        path left to fail; the platform's own arrow art is dark,
 *        for light panels. The per-row reset buttons and the
 *        dialog's own icon buttons -- new instance, execute,
 *        cancel, real-time, documentation, diagnostics and the
 *        preview's zoom trio -- carry a white edge on a dark chip.
 *        The chip stays dark deliberately: the glyphs are light,
 *        and a white FILL would erase them. The diagnostic build's
 *        magenta and orange are gone; its counting line is gone
 *        too, but a refusal still warns to the console, because
 *        four silent try/catch blocks are how a fix shipped four
 *        times and changed nothing.
 * 0.22  DIAGNOSTIC BUILD -- THE COLOURS ARE DELIBERATELY WRONG, and
 *        the next build takes them out again. Four attempts to shade
 *        the icon buttons have come back from PixInsight looking
 *        identical, and the pixels cannot say WHY: refused,
 *        ignored, or applied and invisible all look the same. So
 *        the reset buttons are screaming magenta, the dialog's own
 *        icon buttons orange, and themePolish now COUNTS what it
 *        did and prints it -- four silent try/catch blocks in a row
 *        is how a fix ships four times and changes nothing. Three
 *        outcomes, each pointing somewhere different: solid colour
 *        means the sheet reaches the control and only the colour
 *        was ever wrong; a thin coloured RING around the icon means
 *        the icon is drawn over the whole button and no fill can
 *        ever show (the borders have always rendered -- that is the
 *        clue); no colour at all means no style sheet reaches a PCL
 *        ToolButton and the answer is a different mechanism. The
 *        console line reports the counts independently of the
 *        pixels. Rule 82's method, which ended the confetti in one
 *        screenshot after six plausible fixes had failed.
 * 0.21  THE ICON BUTTONS, ON THE ONE FORM PROVEN TO REACH A PCL
 *        CONTROL. Three builds tried to shade the per-row reset
 *        buttons and each left them sunk into the panel in his
 *        screenshots: a dialog-level QToolButton rule, the same
 *        rule with the background shorthand, then a widget-local
 *        sheet wrapped in `*`. Meanwhile the section panels have
 *        been correctly shaded since the pilot -- by a widget-local
 *        sheet of BARE DECLARATIONS. That form is now copied
 *        exactly instead of a fourth variation being invented, and
 *        the verifier asserts the chip sheet carries no selector so
 *        the failing form cannot come back. Accepted cost: bare
 *        declarations cannot express :hover, so these buttons lose
 *        their hover lift -- a button that can be SEEN beats one
 *        that lights up once the pointer is already on it.
 *        THE DIALOG'S OWN ICON BUTTONS get the same chip (his
 *        second report: the row along the bottom "blending into
 *        the dark background") -- new instance, execute, cancel,
 *        real-time, documentation, diagnostics and the preview's
 *        three zoom buttons. The platform paints them transparent,
 *        so on this floor they were icons floating on nothing.
 * 0.20  THE RESET BUTTONS AND THE DROP-DOWN ARROW, ON THE ROUTE THAT
 *        ACTUALLY REACHES THEM (his report on the last build: "I
 *        dont see any of the changes" -- the package carried them,
 *        the controls ignored them). Both were styled by
 *        DIALOG-LEVEL class rules, QToolButton and
 *        QComboBox::drop-down, and those do not reach PCL's
 *        controls -- the same lesson this theme learned twice
 *        before, for the section panels and the popup lists, and
 *        the reason both of those are set WIDGET-LOCALLY. They are
 *        now set the same way: themePolish puts a chip sheet on
 *        every reset button it finds on the dialog, and the arrow
 *        compartment sheet on every picker AND every schema-built
 *        combo (recognised by what it can do, since the method and
 *        Show dropdowns are declared in Config and appear in no
 *        script's picker list). The lift shade goes from one step
 *        above the panel to clearly above it -- the previous value
 *        would have been near-invisible even had it applied.
 *        verify_theme_wiring.js now asserts the sheets ON THE
 *        OBJECTS, not merely that the rules exist: a rule assigned
 *        to nothing is exactly what shipped last time.
 * 0.19  THE BLUE GRID, AND TWO CONTRAST FIXES HE ASKED FOR. The grid
 *        in a value box was never our focus handling: PixInsight's
 *        OWN style sheet (rsc/qss/core-standard.qss) paints these
 *        controls with TILED 9-slice images -- QLineEdit:focus gets
 *        border-image: url(:/qss/border-focus.png) 33% repeat -- and
 *        a light-theme frame repeated across a 20-pixel box renders
 *        as a blue checkerboard over the value. border-image is a
 *        separate property from border, so setting a border never
 *        displaced it. Now turned off by name on every state the
 *        platform sets it on, for line edits, spin boxes, combos,
 *        push buttons and tool buttons; a focused edit takes a plain
 *        accent outline instead. This also retires the "hatched
 *        button" seen in the earliest theme screenshots.
 *        THE DROP-DOWN NOW LOOKS LIKE ONE (his report): the arrow's
 *        compartment is a step lighter than the field with a divider
 *        down its left edge, and the arrow is the platform's LIGHT
 *        glyph -- its own combobox arrow art is drawn dark, for light
 *        panels, and was invisible here. THE RESET BUTTONS (his
 *        report) sit on a chip above the panel with a defined edge:
 *        the platform paints QToolButton transparent, which put them
 *        into the panel. verify_theme_wiring.js asserts all of it.
 * 0.18  THE FOCUS GRID IN A VALUE BOX, root cause found in the
 *        platform's own header (his UnsharpMaskPro screenshot: the
 *        Star detection value box filled with a blue dither).
 *        Shared Compat.js resolved FOCUS_CLICK to 0x01 -- and
 *        pjsr/FocusStyle.jsh says 0x01 is FocusStyle_Tab; Click is
 *        0x02. PJSR declares these as preprocessor defines, so the
 *        runtime probes never resolve and the fallback IS the
 *        value. Every value edit the theme made "click-only" was
 *        therefore made the dialog's FIRST TAB STOP, so the
 *        opening focus landed on one and painted its focus marks
 *        over the number -- the artifact rule 82 part 3 exists to
 *        prevent, delivered inverted. The constant now comes from
 *        the header, with FOCUS_NONE and FOCUS_WHEEL checked
 *        against it too, and verify_theme_wiring.js asserts all
 *        three so the value cannot drift back. The preview's
 *        FOCUS_CLICK|FOCUS_WHEEL becomes click+wheel as intended
 *        (it was tab+wheel), which also takes it out of the tab
 *        chain.
 * 0.17  THE DARK THEME, suite-wide (rule 82; StarMask 0.39-0.53
 *        piloted it): Theme.js is included, applyTheme skins the
 *        dialog before any control constructs, and the themePolish
 *        one-shot names this script's hand-built controls
 *        (the star mask source picker, its reset button and Auto PSF). The shared Target view picker is now the
 *        themed combo -- ViewList's closed face is core-painted past
 *        any style sheet (Template 2.59). Also inherited from
 *        Part-2, recorded here per rule 65: the wheel-zoom stand-in
 *        holds through the rebuild instead of snapping back to the
 *        stale view (shared PreviewControl, Template 2.58).
 *        Shared ParamControls now lists every per-row reset button
 *        on the dialog as it creates them, so the polish reaches
 *        controls no script names -- they were the one focusable
 *        class the recipe could not see.
 * 0.16  Shared PreviewControl: a rebuild finishing during an open drag
 *        parks its result and publishes at gesture end -- the in-flight
 *        rebuild can no longer eat the zoom box (his report, on THIS
 *        script: seconds-long transforms made it near-certain here).
 *        Template 2.57.
 * 0.15  Shared PreviewControl: the wheel-zoom feedback anchors on the
 *        rendered selection (the 0.14 anchor jumped the view by the pan
 *        margin), and the gesture guard moved into rebuild() itself --
 *        no caller can steal a drag. Template 2.56.
 * 0.14  Shared PreviewControl: wheel zoom commits on wheel-quiet --
 *        notches accumulate with live scaled feedback, one rebuild 0.3 s
 *        after the last notch, mouse press commits first. With 0.13's
 *        pan contract this is what makes 0.75 affordable to scroll:
 *        one rebuild per gesture, not per notch. Template 2.55.
 * 0.13  PAN_MARGIN 0.08 -> 0.75, THE SUITE'S PAN CONTRACT (rule 81,
 *        written from the user's report: the third script to clamp his
 *        pan for rebuild cost, experienced as the same defect over and
 *        over). The margin is never the lever again; the cost lever is
 *        caching the transform result, and until this script's cache
 *        covers pans the slower zoom is the accepted price.
 * 0.12  THE STAR MASK SOURCE ROW MOVES INSIDE MASKS, right after Star
 *        protection (the user's placement); layout composed through the
 *        shared layoutGeneratedControls (Template 2.54), mechanism
 *        identical to UnsharpMaskPro 2.00. Behaviour unchanged.
 * 0.11  STAR MASK SOURCE (the user's feature, mock approved): a new
 *        section picks any open view -- a StarMask result, typically --
 *        whose pixels become the star protection mask DIRECTLY: read
 *        once at full resolution (color via luminance), cached per view
 *        and target, sampled per block, values as-is. Detection is
 *        bypassed while one is selected, so Star detection, Star mask
 *        size and Show star circles grey out (Star protection still
 *        applies -- it weights whatever mask is in use); the edge-map
 *        cleaning and every mask view read the same buffer unchanged. A
 *        missing or size-mismatched view warns and falls back to
 *        detection. Session-fresh per the StarMask precedent; saved
 *        instances replay it. Mechanism identical to UnsharpMaskPro
 *        1.99 -- the two carried copies must stay in step.
 * 0.10  THE ICON REDRAWN TO THE SUITE CONVENTION the user caught 0.09
 *        breaking: two-letter initials on the rounded tile -- "DE",
 *        traced at the suite's letterform metrics, pink tile. Rule 79.
 * 0.09  SHIPS IN THE REPOSITORY (his call, for testing): an icon (a PSF
 *        converging to a point on the suite's rounded tile) and
 *        #feature-icon added. No behaviour change.
 * 0.08  Shared Engine: Execute writes any displayed view -- the guard
 *        that blocked executing a diagnostic view is removed (the run is
 *        one undoable process step; the console notes a diagnostic
 *        output). Template 2.52 carries the mechanism.
 * 0.07  Shared AutoStretch: computeAutoStretch reads the native
 *        median/MAD first, keeping the JS histogram as the fallback --
 *        the derivation cost twelve full-frame JS passes on a color
 *        frame, most of a 49-second stars-only mask build (StarMask
 *        0.24). The screen stretch pays milliseconds now.
 * 0.06  Shared PreviewControl: the screen stretch always applies to the
 *        untransformed picture; only a diagnostic-map TRANSFORM skips its
 *        stretched copy. The old guard nulled the stretch for the whole
 *        preview, so a map view with Show transformed off displayed the
 *        plain image unstretched beside a ticked box (reported on
 *        StarMask 0.23; structural everywhere). Template 2.50 carries the
 *        mechanism.
 * 0.05  Shared MainDialog: the preview debounce defers while a zoom or
 *        pan drag is active, so a queued refresh can no longer eat
 *        the drag (reported on StarMask; structural everywhere).
 *        The mechanism is the Template 2.48 changelog entry.
 * 0.04  Per-parameter reset button at the end of every slider row (shared
 *        ParamControls), matching PixInsight's own convention: click
 *        restores the schema default and refreshes the preview.
 * 0.03  Zoom cost fixed at its real cause, measured in the user's console: the
 *        preview rendered canvas x (1+2*PAN_MARGIN)^2 pixels -- 0.75 margin
 *        is a 5.2x budget, turning the 4.9 s transform into a 33 s zoom.
 *        PAN_MARGIN 0.08 bounds the buffer near 1.4x the canvas. Native
 *        mode constant coerced to a plain integer (the prototype constant
 *        drew "signed integer value expected" assigned raw); iteration tick
 *        uses CoreApplication.processEvents. Three-entry LRU result cache
 *        and per-iteration event pumping, which shipped unversioned in the
 *        previous build against the project's own discipline, are hereby
 *        recorded: zoom-return measured 0.2-0.4 s against 4.6 s cold.
 * 0.02  Native convolution at both preview and Execute inside PixInsight:
 *        Convolution (mode Image, probe-resolved prototype constant 2) with
 *        our Moffat kernel rendered to a view. Interior agreement vs direct
 *        measured 5.96e-8 on the user's machine; the scratch is padded with our
 *        own reflection so the native edge policy is neutralised (plumbing
 *        verified against a hostile zero-edge mock: matches the JS reference
 *        to 7.45e-9 everywhere, unpadded shows 6.67e-2 at the border). Swap
 *        files refused on all scratch work. Falls back to the JS path with a
 *        console warning on any refusal; the console says which engine ran.
 *        Timings from the probe: 117 ms per convolution at preview size,
 *        ~49 ms/MP per channel at full frame, multithreaded.
 * 0.01     Cloned from Unsharp Mask Pro 1.92, whose version history is the
 *          record for everything inherited here: the preview and engine, the
 *          star catalogue and Moffat PSF measurement, and the edge, star and
 *          background masks. The unsharp sharpening operator is to be
 *          replaced by regularized deconvolution; until that lands this
 *          script still sharpens, and it is not for release.
 *
 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8

#feature-id    Deconvolution : Another Astro Channel > Deconvolution


#feature-icon  @script_icons_dir/Deconvolution.svg




#feature-info  Deconvolution using the image's own measured star profile, with regularization that keeps noise and ringing down. For linear data.

/*
 * -----------------------------------------------------------------------------
 * VERSION CHECK
 * -----------------------------------------------------------------------------
 * Deliberately NOT CoreApplication.ensureMinimumVersion(). That call aborts the
 * script outright, and its behaviour varies enough between core builds that it
 * can refuse to run on a version that is perfectly capable. What actually
 * matters here is whether the V8 runtime and ES6 classes are available, and the
 * only reliable way to establish that is to try it.
 *
 * So: report the version, warn if it looks old, and let it run.
 * -----------------------------------------------------------------------------
 */
#define MIN_MAJOR    1
#define MIN_MINOR    8
#define MIN_RELEASE  9

function coreVersionText()
{
   try
   {
      return CoreApplication.versionMajor + "." +
             CoreApplication.versionMinor + "." +
             CoreApplication.versionRelease;
   }
   catch ( x )
   {
      return "unknown";
   }
}

function coreVersionIsBelowMinimum()
{
   try
   {
      let major = CoreApplication.versionMajor;
      let minor = CoreApplication.versionMinor;
      let release = CoreApplication.versionRelease;

      if ( major === undefined || major === null )
         return false;              // cannot tell; assume fine

      if ( major != MIN_MAJOR )
         return major < MIN_MAJOR;
      if ( minor != MIN_MINOR )
         return minor < MIN_MINOR;
      return release < MIN_RELEASE;
   }
   catch ( x )
   {
      return false;                 // cannot tell; assume fine
   }
}

/*
 * -----------------------------------------------------------------------------
 * IDENTITY  --  edit these when you clone the template
 * -----------------------------------------------------------------------------
 * These six values are the whole of a script's identity. Nothing else in the
 * codebase names the script.
 *
 * SCRIPT_ID must match the #feature-id above and the documentation id, or the
 * documentation button will not resolve.
 *
 * KEYPREFIX namespaces stored settings. Two scripts sharing it will overwrite
 * each other's saved state, so it must be unique per script.
 *
 * ATTRIBUTION is rendered at the top of the header panel by METHOD_INFO in
 * lib/Methods.js. It is a placeholder, and it is the author's to decide:
 *
 *    ASSISTANTS -- ASK, DO NOT ASSUME. The person you are building for owns
 *    this line. Ask them what name and year they want, or whether they want no
 *    attribution at all, in which case set it to "" and the panel simply starts
 *    with the description. Do not copy a name out of an example, another
 *    script, or this file's history. Guessing here puts someone else's name on
 *    the user's work.
 * -----------------------------------------------------------------------------
 */
#define TITLE       "Deconvolution"
#define VERSION     "1.04"
#define SCRIPT_ID   "Deconvolution"
#define KEYPREFIX   "Deconvolution"
#define ATTRIBUTION "&copy; 2026 Bill Blanshan &mdash; Another Astro Channel"
#define DESCRIPTION "Deconvolution using the image's own measured star profile, with regularization that keeps noise and ringing down. For linear data."

/*
 * -----------------------------------------------------------------------------
 * FRAMEWORK CONSTANTS
 * -----------------------------------------------------------------------------
 */
#define AUTO_ID                  "<Auto>"
#define DEFAULT_RESULT_ID        "Result"
#define MAX_PREVIEW_ZOOM         4

/*
 * Selection scale factor per wheel notch. 1.25 gives about three notches per
 * doubling, which tracks the pointer without feeling coarse.
 */
#define WHEEL_ZOOM_STEP          1.25

/*
 * Fraction of the visible selection rendered beyond each edge, so panning
 * reveals real data rather than empty canvas.
 *
 * This is also how far a single drag can travel: the pan is clamped to the
 * rendered margin, because beyond it there is nothing to show.
 *
 * A drag cannot be longer than the viewport, so the margin that would remove the
 * clamp entirely is 1.0 -- but that is 2.25x the rendered pixels, and those
 * pixels are re-transformed on every parameter change, not merely stored. Where
 * the drag STARTS decides how far it can go: from the centre 0.50 already covers
 * every possible drag, from a third of the way in 0.67 does. 0.75 covers normal
 * panning and clamps only on a deliberate edge-to-edge sweep, at 1.56x rather
 * than 2.25x.
 */
/*
 * 0.75 IS THE SUITE'S PAN CONTRACT (rule 81, set by the user after this
 * script clamped his pan at 8% of the view -- the third script to trade
 * his pan reach away for rebuild cost). The margin is never the lever
 * again: the rendered buffer is 3.06x the canvas at 0.75 and a parameter
 * change re-transforms all of it, so the cost lever is CACHING the
 * transform result (the LRU here; StarMask's full-resolution result
 * caches are the model) -- a pan then samples, it does not recompute.
 */
#define PAN_MARGIN               0.75

/*
 * HOW MANY PROCESSING LEVELS PER FACTOR OF TWO.
 *
 * The preview used to process at the DISPLAY scale, which is continuous: every
 * zoom produced a uniquely sized buffer, so no two zooms could share a single
 * computed pixel and caching was impossible in principle. It now processes at
 * a quantised LEVEL at or above the display scale and resamples that to the
 * canvas, which is what Photoshop, Lightroom, Capture One, darktable and GEGL
 * all do, and for the same reason.
 *
 * ONE CONSTANT, TWO COSTS (rule 72):
 *
 *   1 -- powers of two (1, 1/2, 1/4, 1/8). What the other tools use. One
 *        level covers a 2x zoom range, so reuse is widest; a zoom sitting
 *        just under a level pays up to 4x the pixels the display strictly
 *        needs, about 2.1x on average.
 *   2 -- half-octave steps (1, 1/1.41, 1/2, ...). One level covers 1.41x, so
 *        reuse is narrower; the worst case falls to 2x and the average to
 *        about 1.44x.
 *
 * 1 because the instruction was to copy what the other tools do rather than
 * invent, and because reuse across a wide zoom range is the point. The trade
 * is entirely in this number and it is measurable, not a matter of taste.
 */
#define PREVIEW_SCALE_OCTAVE_STEPS   2

/*
 * HOW FAR THIS METHOD'S RESULT TRAVELS, in buffer pixels at the processing
 * level. The preview renders what is on screen plus this, publishes it, and
 * fills the pan margin afterwards -- so the wait to a correct picture is set
 * by this number rather than by the margin.
 *
 * MEASURED, not assumed. tools/measure_decon_halo.js and
 * tools/verify_tile_agreement.js both put it at 24 px: a region computed with
 * that overlap agrees with the untiled result to 0.00 sigma, stars on the
 * boundary included. Richardson-Lucy's WORST case is twice the kernel radius
 * per iteration -- 720 px at 20 iterations -- and the practical reach is
 * nothing like it, because damping and the TV term kill the far field. That
 * gap is the whole reason this design is possible.
 *
 * TOO SMALL shows as a wrong edge around the visible area that changes when
 * the margin lands. TOO LARGE merely costs a little; on a 1024x768 canvas 24
 * px of halo is 1.13x the visible pixels, against 6.25x for the margin. Re-run
 * the two tools if the iteration count or the regularization changes a lot.
 */
#define PREVIEW_METHOD_HALO          24


/*
 * Minimum gap between wheel notches. A physical notch produces one step; a
 * duplicate delivery of the same event arrives within a millisecond or two and
 * is discarded. Well below the interval a hand can produce.
 */
#define WHEEL_MIN_INTERVAL_MS    40

/*
 * Log every preview rebuild: what it was asked for, what it produced, and how
 * long it took. Set false once the preview behaves.
 */
#define PREVIEW_DIAGNOSTICS      false

/*
 * Report the first wheel event to the console, with the arguments as received.
 * A handler that never fires and one that fires with an unexpected signature
 * are otherwise indistinguishable. Set false once wheel zoom is confirmed.
 */
#define WHEEL_DIAGNOSTICS        false

/*
 * Samples read, transformed and written back per block. Whole-image arrays for
 * a large frame run to hundreds of megabytes; a block keeps the working set
 * small and cache friendly. Roughly 4 megapixels.
 */
#define PIXEL_BLOCK_SAMPLES      4194304


#define STATISTICS_BINS          1048576


/*
 * Label columns for the preview dimension row. The two custom numbers share a row,
 * so the second one's label is just an "x" between them and neither can borrow the
 * dialog's shared column without pushing the boxes off the group.
 */
#define PREVIEW_X_WIDTH          8

#define SLIDER_WIDTH             200
/*
 * The blur radius, in image pixels, that separates detail from base.
 *
 * This is the one number that decides what the script IS. At a small radius the
 * detail layer is edges and grain, and scaling it sharpens; at a large one it is
 * structure several tens of pixels across, and scaling it is what other software
 * calls clarity. Same filter, same control.
 */
/*
 * The smallest radius, in BUFFER pixels, the preview can honestly draw. Three
 * box passes are a running sum over 2r+1 pixels, so there is no window below
 * one. Under this the preview leaves the image alone and says the radius is
 * not visible at that zoom, rather than drawing a coarser operation than
 * Execute will apply.
 */
#define DETAIL_MIN_BUFFER_RADIUS 1.0

/*
 * How far Rescale keeps the result from black and white, as a fraction.
 *
 * Rescaling to exactly 0 and 1 leaves nothing at either end: the darkest pixel
 * is then unrecoverably black and the brightest unrecoverably white, and any
 * later curve has nothing to pull back. 0.2% of the range costs nothing
 * visible and leaves both ends intact.
 *
 * Hardcoded rather than exposed. It is not a creative decision and a control
 * for it would be one more thing to explain.
 */

/*
 * How far short of black and white the headroom limiter stops, as an ABSOLUTE
 * value.
 *
 * The limiter approaches the boundary asymptotically, but float32 has a step of
 * 1.19e-7 next to 1.0, so anything closer than that rounds onto it. A margin
 * proportional to the headroom shrinks below the representable step exactly
 * where it matters -- at pixels already near white -- and the guarantee fails
 * silently. 1e-6 is representable at both ends and invisible.
 */
#define HEADROOM_EPSILON         1e-6



/*
 * Rows per streamed band, and the halo each band reads beyond its own rows.
 *
 * The blur is three box passes, so it reaches three times the radius, and and a
 * fractional radius applies it twice, once at each of the two integer radii
 * either side. Six times the radius is what makes a band self-contained. Measured: 512 rows with a 120 pixel halo is
 * 235 MB resident for a 24 megapixel colour frame, against 1960 MB for the whole
 * image, and that figure does not grow with the image.
 */
#define DETAIL_HALO_FACTOR       6


/*
 * Rec. 709 luminance, the same weights the saturation mask uses. Consistency
 * matters more than the choice: two masks disagreeing about what brightness
 * means would select differently on the same pixel.
 */
/*
 * STAR DETECTION AND PSF MEASUREMENT
 *
 * STAR_DETECT_SIGMA is above the SKY in units of the noise. The measured PSF is
 * insensitive to it: on a real frame the median FWHM moved 3% across thresholds
 * from 10 to 40 sigma, so it is set high enough that faint candidates do not
 * dominate the sort rather than tuned.
 *
 * STAR_FIT_MAX is 150 because 50 stars already give the median FWHM to within
 * 0.3% of what 487 give. Beyond that it is cost with no accuracy.
 *
 * STAR_SAMPLE_ROWS bounds the statistics pass. 400 rows spread over the frame
 * gives the noise to well within 1% and does not grow with the image.
 *
 * STAR_BLEND_FRACTION is applied to a genuine second MAXIMUM, never to a bright
 * pixel. A star of sigma 1.9 has 28% of its peak at radius 3, so testing bright
 * pixels at 30% rejects stars for their own wings -- 93% of them, measured.
 */
#define STAR_WINDOW              8

/*
 * The radius of the local background window used for star DETECTION, in pixels.
 *
 * A star must stand above its own surroundings, not above the frame's median.
 * Measured: thresholding against the global sky found 6070 candidates on a real
 * frame against 2499 with a local background, and the extra ones were nebula
 * texture -- a mask painted from them covered the nebula in a solid blob.
 *
 * 20 is comfortably wider than any star and far narrower than the nebulosity it
 * has to follow. It sets the halo the detection pass reads, so raising it costs
 * memory as well as time.
 */
#define STAR_BACKGROUND_RADIUS  20
#define STAR_NOISE_BINS          16

/*
 * The width cap, as a multiple of the frame's own median core width. A star's
 * width is the seeing and every star shares it; anything much wider is not one.
 */
#define STAR_ALPHA_FACTOR        2.0

/* Below this many detections the median is not worth trusting, so no cap. */
#define STAR_ALPHA_SAMPLE_MIN    50

/*
 * The seeing median is taken over detections at least this bright, in local
 * sigma. Above it a detection is almost always a real star at any threshold,
 * so the cap cannot be poisoned by a low detection setting.
 */
#define STAR_SEEING_AMP_MIN      30

/*
 * The walk level's narrow reference, a box radius in pixels. Wide enough to sit
 * under a star, narrow enough to follow a nebula ridge.
 */
#define STAR_WALK_RADIUS         3

/*
 * How much of the detection threshold the narrow amplitude must also clear.
 * A half, because the narrow reference sits partly on a real star's own wings.
 */
/*
 * The radius of the reference the noise is measured against. Small enough that
 * an object's structure survives it and only pixel-to-pixel scatter is left.
 */
#define STAR_NOISE_SCALE         2
#define STAR_ELLIPSE_ARMS        16

/*
 * How far the profile may rise above its lowest point before the walk decides
 * the star has ended, in units of the local noise. Grain alone must not end it.
 */
#define STAR_TURN_TOLERANCE      2.0

#define STAR_SAMPLE_ROWS         400
#define STAR_NOISE_SAMPLES       50000
#define STAR_DETECT_SIGMA        20
#define STAR_FIT_MIN             8
#define STAR_FIT_MAX             150
#define STAR_CANDIDATE_SLACK     20
#define STAR_SATURATION          0.999
#define STAR_CORE_RADIUS         3
#define STAR_BLEND_FRACTION      0.30
#define STAR_PROFILE_BINS        32
#define STAR_BIN_MIN             5

/*
 * The adaptive moment weight. STAR_MOMENT_CUTOFF is in squared Mahalanobis
 * radius, so 9 is three sigma of the current estimate -- past that the weight
 * is under 0.011 and the pixel is noise.
 */
#define STAR_MOMENT_SEED         2.0
#define STAR_MOMENT_ITERATIONS   12
#define STAR_MOMENT_CUTOFF       9

/*
 * The Moffat grid. beta is the wing weight: 4.765 is pure Kolmogorov seeing and
 * real data sits lower. Measured 3.1 to 3.5 on a real frame, so the range is
 * wide enough to be a measurement rather than a confirmation of the default.
 */
#define MOFFAT_BETA_MIN          1.2
#define MOFFAT_BETA_MAX          9.0
#define MOFFAT_BETA_STEP         0.02
#define MOFFAT_BETA_COARSE       0.20
#define MOFFAT_FWHM_MIN          1.2
#define MOFFAT_FWHM_MAX          12.0
#define MOFFAT_FWHM_STEP         0.01
#define MOFFAT_FWHM_COARSE       0.10

#define LUMINANCE_R              0.2126
#define LUMINANCE_G              0.7152
#define LUMINANCE_B              0.0722

/*
 * The two lines under the preview: a permanent gesture reminder, and the pixel
 * values under the pointer. Both are fixed height so nothing shifts as the
 * pointer moves on and off the image, and the readout gets two rows so a
 * color value wraps instead of widening the dialog past the image.
 */
#define HINT_HEIGHT              18
#define CURVE_PLOT_HEIGHT        200
#define READOUT_HEIGHT           32
// 0.25 was right when a rebuild cost a fraction of a second. This method's
// rebuild costs seconds and BLOCKS the event loop, so a quarter-second
// hesitation mid-drag froze the slider under the finger. 0.8 only fires on a
// deliberate hold.
#define PREVIEW_DEBOUNCE_SECONDS 0.8

/*
 * Which view a saved instance opens on.
 *
 * PJSR does not tell a script which view an instance was dropped onto, so the
 * instance has to fall back to something.
 *
 *    true   the active window wins. If dropping an icon on a window activates
 *           that window, this is what makes drag-to-image work.
 *    false  the identifier stored in the instance wins. Predictable, but it
 *           ignores where the icon was dropped.
 *
 * The console reports which was used on every launch.
 */
#define INSTANCE_PREFERS_ACTIVE_VIEW true

/*
 * -----------------------------------------------------------------------------
 * Includes. Order matters: Utilities and Methods must precede Config, because
 * Config's schema is evaluated as it loads.
 * -----------------------------------------------------------------------------
 */
#include "lib/Compat.js"
#include "lib/Utilities.js"
#include "lib/StarMeasurement.js"
#include "lib/StarDetect.js"
#include "lib/AutoStretch.js"
#include "lib/EdgeMap.js"
#include "lib/MethodRegistry.js"
#include "lib/Methods.js"

/*
 * Optional method modules go here. A module registers its own methods and may
 * bring its own parameters, so it must be included before Config.js assembles
 * the schema:
 *
 *    #include "modules/MyMethods.js"
 */

#include "lib/Config.js"
#include "lib/ParamSchema.js"
#include "lib/Theme.js"
#include "lib/ParamControls.js"
/*
 * A DELIBERATE, TEMPORARY FORK -- and it carries an obligation.
 *
 * THE PREVIEW IS SHARED, and that was the whole point of the bench.
 *
 * This script was developed as DeconvolutionTest so the shipping suite could
 * not be broken on every intermediate step, and it carried its own copy of
 * PreviewControl.js while that work was in progress. The copy went back into
 * shared/lib on 2026-08-11 and all ten scripts run it: the level is never
 * coarser than the display, the visible region publishes before the pan
 * margin, the drag is bounded by the frame rather than the buffer, and a
 * gesture can abandon a render in flight.
 *
 * The obligation that comment used to record is discharged. A fork that is
 * forgotten becomes the drift the shared library exists to prevent, and this
 * project has paid for that once already -- eight copies of one library, with
 * CLAHE's applyMethod 92 lines behind and nobody aware. check_workspace.py
 * now fails on a duplicate that carries no declared reason, so the next fork
 * cannot be forgotten quietly.
 */
#include "lib/PreviewControl.js"
#include "lib/Engine.js"
#include "lib/EngineHooks.js"
#include "lib/DialogHooks.js"
#include "lib/MainDialog.js"
/*
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * *****************************************************************************
 */
/*
 * PJSR can throw values that are not Error objects, and a bare x.message on one
 * of those prints "undefined", which says nothing at all. Describe whatever was
 * actually thrown.
 */
function describeError( x )
{
   try
   {
      if ( x === null )
         return "null was thrown";
      if ( x === undefined )
         return "undefined was thrown";
      if ( typeof x == "string" )
         return x;
      if ( x.message !== undefined && x.message !== null && x.message !== "" )
         return x.message;
      if ( x.toString !== undefined )
      {
         let text = x.toString();
         if ( text != "" && text != "[object Object]" )
            return text;
      }
      return "an object of type " + ( typeof x ) + " was thrown with no message";
   }
   catch ( y )
   {
      return "an unreportable error";
   }
}

function main()
{
   if ( MethodRegistry.count() == 0 )
   {
      ( new MessageBox( "<p>No transform methods are registered.</p>" +
                        "<p>Add at least one MethodRegistry.register() block in " +
                        "lib/Methods.js.</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
      return;
   }

   if ( coreVersionIsBelowMinimum() )
   {
      console.show();
      console.warningln( "<end><cbr>** " + TITLE + ": core version " + coreVersionText() +
                         " is older than the " + MIN_MAJOR + "." + MIN_MINOR + "." + MIN_RELEASE +
                         " this script was written against." );
      console.warningln( "** Continuing anyway. If it fails, the V8 runtime is the likely cause." );
   }
   else
      console.noteln( "<end><cbr>" + TITLE + " " + VERSION +
                      " on core version " + coreVersionText() );

   console.hide();

   let engine = new Engine();
   let dialogWasShown = false;

   try
   {
      engine.loadSettings();

      let runningInstance = ( Parameters.isViewTarget || Parameters.isGlobalTarget );

      if ( runningInstance )
      {
         // Executing a saved instance. Parameters override stored settings.
         engine.loadParameters();
      }

      // Open on the image selected in the workspace. See the policy constant
      // above for how a saved instance resolves its target.
      /*
       * TIMED. Opening this script took thirty seconds against three for one
       * that does not transform at full resolution, and three separate guesses
       * at the cause were wrong. The stages report themselves so the fourth
       * does not have to be a guess.
       */
      let t0 = Date.now();
      engine.resolveInitialTarget( runningInstance );
      engine.reportInitialTarget();
      let tTarget = Date.now();

      let dialog = new MainDialog( engine );
      let tDialog = Date.now();

      console.noteln( "<end><cbr>open: target " + ( tTarget - t0 ) + "ms" +
                      "   dialog built in " + ( tDialog - tTarget ) + "ms" );

      dialogWasShown = true;
      dialog.execute();
   }
   catch ( x )
   {
      console.show();
      let description = describeError( x );
      console.criticalln( "<end><cbr>" + TITLE + " failed: " + description );
      if ( x !== null && x !== undefined && x.stack !== undefined )
         console.noteln( x.stack );
      ( new MessageBox( "<p>" + TITLE + " encountered an error:</p><p>" + description + "</p>",
                        TITLE, ICON_ERROR, BTN_OK ) ).execute();
   }
   finally
   {
      // Persist state and clean up scratch images on every exit path, including
      // an exception during dialog construction.
      try
      {
         if ( !Parameters.isViewTarget && !Parameters.isGlobalTarget )
            engine.saveSettings();
      }
      catch ( x )
      {
         // Not worth surfacing at teardown.
      }

      try
      {
         engine.deleteAllMasks();
      }
      catch ( x )
      {
         // Ditto.
      }

      if ( !dialogWasShown )
         console.show();
   }
}

main();
