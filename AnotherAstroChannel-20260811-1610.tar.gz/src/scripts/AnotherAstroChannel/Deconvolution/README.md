# Deconvolution

Deconvolution using the image's own measured star profile, with regularization
that keeps noise and ringing down. For linear data.

## What it does

It measures the frame's point spread function from its own stars -- a Moffat
profile fitted to about 150 unsaturated, unblended ones -- and runs a damped,
regularized Richardson-Lucy deconvolution against it. Nothing is guessed: the
PSF, the noise and the sky level all come from the image in front of you.

Three things keep it honest on real data:

- **Damping.** Below one damping sigma the update is exactly zero, so a pixel the
  model already explains to within the noise never moves again. Measured on a
  synthetic truth scene, sky noise gain is 1.001x at 100 iterations while a
  bright star still tightens from 4.85 to 2.74 pixels.
- **Total-variation regularization**, which shrinks the ringing beside bright
  stars (measured: a 23.9 sigma dip becomes 17.6).
- **A sky pedestal in the model.** Richardson-Lucy assumes the data is object
  flux and nothing else; a linear frame carries a sky level, and modelling it as
  object digs the rings into it. Measured with the pedestal as object, the ring
  went 63.2 sigma deep; in the model, 4.9.

## The preview

The preview is the point of the tool, and it is built to be judged rather than
merely looked at. It processes at a fixed ladder of scales and always picks one
at least as fine as the screen, so what you see is never softer than the panel
it is drawn on. The header line reports the scale it used.

Judge sharpening at 1:1 or 1:2. Zoomed further out the PSF is only a pixel or
two wide and the console will say so -- the effect is genuinely small there, and
that is the physics rather than a shortcut.

Every statistic -- the PSF, the noise, the sky level -- is measured from the
whole original frame and cached, never from the zoomed preview buffer. Pan and
zoom change what you are looking at and nothing about what is computed.

## Controls

**PSF width (FWHM)** and **Moffat beta** describe the blur being removed; **Auto
PSF** measures both from the frame. **Iterations** is how many refinement passes
run. **Noise control** sets the damping. **Amount** blends the result back.

The masks decide *where* it acts: an **edge mask** keeps it out of flat sky, a
**star mask** holds back the cores that need it least, and a **background mask**
protects the faint end. Each has a view that shows exactly what it selects.

## Requirements

PixInsight 1.8.9 or later. Tested on 1.9.4.
