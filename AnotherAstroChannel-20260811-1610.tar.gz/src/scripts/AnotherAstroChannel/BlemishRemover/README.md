# Blemish Remover for PixInsight

Removes small blemishes by cloning a nearby patch of background over them, with
no seam and no loss of grain.

Installs under **Script → Another Astro Channel → Blemish Remover**.

---

## What it does

Place a circle over a blemish and it is replaced with real pixels taken from
somewhere else in the same image — not with a synthetic fill.

A donor region of the same size is chosen from twenty-four candidates a few radii
away, scored by how well its surroundings match. The two are then joined by
solving for a smooth correction that equals the difference between them exactly
at the edge of the circle. At the boundary the result is therefore identical to
what was already there, so there is no seam anywhere; inside, the donor's own
texture is carried across at the right level, following whatever gradient runs
through.

This is what a healing brush does, and it matters because the obvious
alternatives do not work on astronomical data:

- **A flat fill** leaves a visible disc wherever there is a gradient.
- **A smooth interpolation** looks like a smear, because real sky is not smooth.
- **Interpolation plus synthetic noise** still looks smooth. That noise is white
  — independent per pixel — while real background has correlated mottling and
  clumped grain. Matching the amplitude does not help; amplitude was never what
  was missing.

Measured on a mottled test frame, the fill carries the same structure as the sky
around it to within 5%, at the pixel scale and at the mottle scale alike, and the
step across the circle edge is no larger than the local grain.

---

## Controls

**Radius** — the size of the next circle, in image pixels, up to 800. It is read
at the moment you click, so each circle keeps the size it was placed at: change
it between clicks to mix sizes. Changing it does not disturb circles already
placed.

**Show circles** — draws the placed circles over the preview. Turn it off to
judge the result without the rings in the way. They are drawn over the image and
never reach the output.

**Place circles** — arms placement, and stays armed so a row of circles goes down
without pressing it between each.

- **Left click** places a circle at the current radius.
- **Right click** removes the circle under the cursor. Where circles overlap, the
  smallest one containing the point goes first, so a small circle placed on top
  of a large one can still be taken off.
- **Middle-drag** still pans while armed.

**Remove last** unwinds in order. **Clear all** empties the list.

Nothing is written to the image until **Execute**, and every circle is applied in
one pass, so the whole edit is a single undo step.

---

## What it is for, and what it is not

**Linear or stretched, either way.** The donor is taken as it is, so the fill
matches the image in the state you are working on — and the fill itself is a
harmonic function matched to the values around the circle, which is scale free
and does not care how the data is stretched.

**It works on background** — dust motes, satellite trails, a stray star in empty
sky, a small residual after star removal.

**It does not reconstruct structure.** The donor is background too, so a circle
placed over detailed nebulosity will be covered with sky rather than repaired.
Reconstructing texture that continues surrounding structure is a different
technique entirely; this one is honest about being a patch.

**Make the circle a little larger than the blemish.** The fill is joined to a
ring just outside the circle, so the edge of the blemish must not reach into
that ring.

---

## Notes

**Circles are stored in the process instance.** Drag the triangle to the
workspace and the placed circles go with it, so the same set can be applied to
another image — useful for a stack of frames sharing a dust mote.

**A large circle costs little more than a small one.** The smooth part of the
fill is solved on a decimated grid, which is accurate because that part has no
fine detail by construction. Patches are cached by circle, so placing the fifth
does not recompute the first four.

**Near an image edge** the sampling ring is smaller and the donor has fewer
places to come from. If no usable donor exists at all — a circle in the corner of
a small image — the fill falls back to a smooth interpolation, which is worse
looking but never a hard edge.

**Process instances carry a source checksum**, so an instance saved against one
version refuses to run after the script is updated. That is deliberate on
PixInsight's part: a stored instance must not quietly mean something different
after a code change.

---

## Requirements

PixInsight 1.8.9 or later, with the V8 script engine.

---

© 2026 Bill Blanshan — Another Astro Channel
